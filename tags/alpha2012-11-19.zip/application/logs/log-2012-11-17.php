<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-11-17 13:33:11 --> Config Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Hooks Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Utf8 Class Initialized
DEBUG - 2012-11-17 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 13:33:11 --> URI Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Router Class Initialized
DEBUG - 2012-11-17 13:33:11 --> No URI present. Default controller set.
DEBUG - 2012-11-17 13:33:11 --> Output Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Security Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Input Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 13:33:11 --> Language Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Loader Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Helper loaded: date_helper
DEBUG - 2012-11-17 13:33:11 --> Helper loaded: form_helper
DEBUG - 2012-11-17 13:33:11 --> Helper loaded: language_helper
DEBUG - 2012-11-17 13:33:11 --> Helper loaded: url_helper
DEBUG - 2012-11-17 13:33:11 --> Helper loaded: html_helper
DEBUG - 2012-11-17 13:33:11 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 13:33:11 --> Session Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Helper loaded: string_helper
DEBUG - 2012-11-17 13:33:11 --> Encrypt Class Initialized
DEBUG - 2012-11-17 13:33:11 --> A session cookie was not found.
DEBUG - 2012-11-17 13:33:11 --> Session routines successfully run
DEBUG - 2012-11-17 13:33:11 --> Form Validation Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Controller Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Helper loaded: file_helper
DEBUG - 2012-11-17 13:33:11 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Database Forge Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Database Forge Class Initialized
DEBUG - 2012-11-17 13:33:11 --> Database Utility Class Initialized
DEBUG - 2012-11-17 13:33:11 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 13:33:11 --> File loaded: application/views/content/login_view.php
DEBUG - 2012-11-17 13:33:11 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 13:33:11 --> Final output sent to browser
DEBUG - 2012-11-17 13:33:11 --> Total execution time: 0.5760
DEBUG - 2012-11-17 13:33:19 --> Config Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Hooks Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Utf8 Class Initialized
DEBUG - 2012-11-17 13:33:19 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 13:33:19 --> URI Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Router Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Output Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Security Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Input Class Initialized
DEBUG - 2012-11-17 13:33:19 --> XSS Filtering completed
DEBUG - 2012-11-17 13:33:19 --> XSS Filtering completed
DEBUG - 2012-11-17 13:33:19 --> XSS Filtering completed
DEBUG - 2012-11-17 13:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 13:33:19 --> Language Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Loader Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Helper loaded: date_helper
DEBUG - 2012-11-17 13:33:19 --> Helper loaded: form_helper
DEBUG - 2012-11-17 13:33:19 --> Helper loaded: language_helper
DEBUG - 2012-11-17 13:33:19 --> Helper loaded: url_helper
DEBUG - 2012-11-17 13:33:19 --> Helper loaded: html_helper
DEBUG - 2012-11-17 13:33:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 13:33:19 --> Session Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Helper loaded: string_helper
DEBUG - 2012-11-17 13:33:19 --> Encrypt Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Session routines successfully run
DEBUG - 2012-11-17 13:33:19 --> Form Validation Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Controller Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Helper loaded: file_helper
DEBUG - 2012-11-17 13:33:19 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Model Class Initialized
DEBUG - 2012-11-17 13:33:19 --> Model Class Initialized
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined property: stdClass::$analisis_id /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 42
ERROR - 2012-11-17 13:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 44
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined variable: adate /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 52
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined variable: awiki /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 52
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined variable: acolor /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 52
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined variable: arangea /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 52
ERROR - 2012-11-17 13:33:19 --> Severity: Notice  --> Undefined variable: arangeb /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/login_form.php 52
DEBUG - 2012-11-17 13:33:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 13:33:19 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 13:33:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 13:33:19 --> Final output sent to browser
DEBUG - 2012-11-17 13:33:19 --> Total execution time: 0.2273
DEBUG - 2012-11-17 13:37:34 --> Config Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Hooks Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Utf8 Class Initialized
DEBUG - 2012-11-17 13:37:34 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 13:37:34 --> URI Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Router Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Output Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Security Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Input Class Initialized
DEBUG - 2012-11-17 13:37:34 --> XSS Filtering completed
DEBUG - 2012-11-17 13:37:34 --> XSS Filtering completed
DEBUG - 2012-11-17 13:37:34 --> XSS Filtering completed
DEBUG - 2012-11-17 13:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 13:37:34 --> Language Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Loader Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Helper loaded: date_helper
DEBUG - 2012-11-17 13:37:34 --> Helper loaded: form_helper
DEBUG - 2012-11-17 13:37:34 --> Helper loaded: language_helper
DEBUG - 2012-11-17 13:37:34 --> Helper loaded: url_helper
DEBUG - 2012-11-17 13:37:34 --> Helper loaded: html_helper
DEBUG - 2012-11-17 13:37:34 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 13:37:34 --> Session Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Helper loaded: string_helper
DEBUG - 2012-11-17 13:37:34 --> Encrypt Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Session routines successfully run
DEBUG - 2012-11-17 13:37:34 --> Form Validation Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Controller Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Model Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Model Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Model Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Helper loaded: file_helper
DEBUG - 2012-11-17 13:37:34 --> Model Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Model Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Model Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Model Class Initialized
DEBUG - 2012-11-17 13:37:34 --> Model Class Initialized
DEBUG - 2012-11-17 13:37:34 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 13:37:34 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 13:37:34 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 13:37:34 --> Final output sent to browser
DEBUG - 2012-11-17 13:37:34 --> Total execution time: 0.1133
DEBUG - 2012-11-17 13:38:03 --> Config Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Hooks Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Utf8 Class Initialized
DEBUG - 2012-11-17 13:38:03 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 13:38:03 --> URI Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Router Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Output Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Security Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Input Class Initialized
DEBUG - 2012-11-17 13:38:03 --> XSS Filtering completed
DEBUG - 2012-11-17 13:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 13:38:03 --> Language Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Loader Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Helper loaded: date_helper
DEBUG - 2012-11-17 13:38:03 --> Helper loaded: form_helper
DEBUG - 2012-11-17 13:38:03 --> Helper loaded: language_helper
DEBUG - 2012-11-17 13:38:03 --> Helper loaded: url_helper
DEBUG - 2012-11-17 13:38:03 --> Helper loaded: html_helper
DEBUG - 2012-11-17 13:38:03 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 13:38:03 --> Session Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Helper loaded: string_helper
DEBUG - 2012-11-17 13:38:03 --> Encrypt Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Session routines successfully run
DEBUG - 2012-11-17 13:38:03 --> Form Validation Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Controller Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:03 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:03 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 13:38:03 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 13:38:03 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 13:38:03 --> Final output sent to browser
DEBUG - 2012-11-17 13:38:03 --> Total execution time: 0.1553
DEBUG - 2012-11-17 13:38:14 --> Config Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Hooks Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Utf8 Class Initialized
DEBUG - 2012-11-17 13:38:14 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 13:38:14 --> URI Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Router Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Output Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Security Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Input Class Initialized
DEBUG - 2012-11-17 13:38:14 --> XSS Filtering completed
DEBUG - 2012-11-17 13:38:14 --> XSS Filtering completed
DEBUG - 2012-11-17 13:38:14 --> XSS Filtering completed
DEBUG - 2012-11-17 13:38:14 --> XSS Filtering completed
DEBUG - 2012-11-17 13:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 13:38:14 --> Language Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Loader Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Helper loaded: date_helper
DEBUG - 2012-11-17 13:38:14 --> Helper loaded: form_helper
DEBUG - 2012-11-17 13:38:14 --> Helper loaded: language_helper
DEBUG - 2012-11-17 13:38:14 --> Helper loaded: url_helper
DEBUG - 2012-11-17 13:38:14 --> Helper loaded: html_helper
DEBUG - 2012-11-17 13:38:14 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 13:38:14 --> Session Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Helper loaded: string_helper
DEBUG - 2012-11-17 13:38:14 --> Encrypt Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Session routines successfully run
DEBUG - 2012-11-17 13:38:14 --> Form Validation Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Controller Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Helper loaded: file_helper
DEBUG - 2012-11-17 13:38:14 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:14 --> Model Class Initialized
DEBUG - 2012-11-17 13:38:14 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 13:38:14 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 13:38:14 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:38:21 --> Database Driver Class Initialized
ERROR - 2012-11-17 13:38:21 --> Severity: Warning  --> include(application/libraries/Chart.php): failed to open stream: No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 19
ERROR - 2012-11-17 13:38:21 --> Severity: Warning  --> include(): Failed opening 'application/libraries/Chart.php' for inclusion (include_path='.:/opt/lampp/lib/php') /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 19
DEBUG - 2012-11-17 13:38:21 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 13:38:21 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 13:38:21 --> Final output sent to browser
DEBUG - 2012-11-17 13:38:21 --> Total execution time: 6.9896
DEBUG - 2012-11-17 13:42:21 --> Config Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Hooks Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Utf8 Class Initialized
DEBUG - 2012-11-17 13:42:21 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 13:42:21 --> URI Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Router Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Output Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Security Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Input Class Initialized
DEBUG - 2012-11-17 13:42:21 --> XSS Filtering completed
DEBUG - 2012-11-17 13:42:21 --> XSS Filtering completed
DEBUG - 2012-11-17 13:42:21 --> XSS Filtering completed
DEBUG - 2012-11-17 13:42:21 --> XSS Filtering completed
DEBUG - 2012-11-17 13:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 13:42:21 --> Language Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Loader Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Helper loaded: date_helper
DEBUG - 2012-11-17 13:42:21 --> Helper loaded: form_helper
DEBUG - 2012-11-17 13:42:21 --> Helper loaded: language_helper
DEBUG - 2012-11-17 13:42:21 --> Helper loaded: url_helper
DEBUG - 2012-11-17 13:42:21 --> Helper loaded: html_helper
DEBUG - 2012-11-17 13:42:21 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 13:42:21 --> Session Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Helper loaded: string_helper
DEBUG - 2012-11-17 13:42:21 --> Encrypt Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Session routines successfully run
DEBUG - 2012-11-17 13:42:21 --> Form Validation Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Controller Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Model Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Model Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Model Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Model Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Model Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Model Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Helper loaded: file_helper
DEBUG - 2012-11-17 13:42:21 --> Model Class Initialized
DEBUG - 2012-11-17 13:42:21 --> Model Class Initialized
DEBUG - 2012-11-17 13:42:21 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 13:42:21 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 13:42:21 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:42:28 --> Database Driver Class Initialized
ERROR - 2012-11-17 13:42:28 --> Severity: Warning  --> include(../application/libraries/Chart.php): failed to open stream: No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 19
ERROR - 2012-11-17 13:42:28 --> Severity: Warning  --> include(): Failed opening '../application/libraries/Chart.php' for inclusion (include_path='.:/opt/lampp/lib/php') /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 19
DEBUG - 2012-11-17 13:42:28 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 13:42:28 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 13:42:28 --> Final output sent to browser
DEBUG - 2012-11-17 13:42:28 --> Total execution time: 6.5708
DEBUG - 2012-11-17 13:46:48 --> Config Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Hooks Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Utf8 Class Initialized
DEBUG - 2012-11-17 13:46:48 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 13:46:48 --> URI Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Router Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Output Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Security Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Input Class Initialized
DEBUG - 2012-11-17 13:46:48 --> XSS Filtering completed
DEBUG - 2012-11-17 13:46:48 --> XSS Filtering completed
DEBUG - 2012-11-17 13:46:48 --> XSS Filtering completed
DEBUG - 2012-11-17 13:46:48 --> XSS Filtering completed
DEBUG - 2012-11-17 13:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 13:46:48 --> Language Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Loader Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Helper loaded: date_helper
DEBUG - 2012-11-17 13:46:48 --> Helper loaded: form_helper
DEBUG - 2012-11-17 13:46:48 --> Helper loaded: language_helper
DEBUG - 2012-11-17 13:46:48 --> Helper loaded: url_helper
DEBUG - 2012-11-17 13:46:48 --> Helper loaded: html_helper
DEBUG - 2012-11-17 13:46:48 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 13:46:48 --> Session Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Helper loaded: string_helper
DEBUG - 2012-11-17 13:46:48 --> Encrypt Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Session routines successfully run
DEBUG - 2012-11-17 13:46:48 --> Form Validation Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Controller Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Model Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Model Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Model Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Model Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Model Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Model Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Helper loaded: file_helper
DEBUG - 2012-11-17 13:46:48 --> Model Class Initialized
DEBUG - 2012-11-17 13:46:48 --> Model Class Initialized
DEBUG - 2012-11-17 13:46:48 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 13:46:48 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 13:46:48 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:46:55 --> Database Driver Class Initialized
DEBUG - 2012-11-17 13:46:55 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 13:46:55 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 13:46:55 --> Final output sent to browser
DEBUG - 2012-11-17 13:46:55 --> Total execution time: 6.6232
DEBUG - 2012-11-17 15:38:05 --> Config Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:38:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:38:05 --> URI Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Router Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Output Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Security Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Input Class Initialized
DEBUG - 2012-11-17 15:38:05 --> XSS Filtering completed
DEBUG - 2012-11-17 15:38:05 --> XSS Filtering completed
DEBUG - 2012-11-17 15:38:05 --> XSS Filtering completed
DEBUG - 2012-11-17 15:38:05 --> XSS Filtering completed
DEBUG - 2012-11-17 15:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:38:05 --> Language Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Loader Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:38:05 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:38:05 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:38:05 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:38:05 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:38:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:38:05 --> Session Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:38:05 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Session routines successfully run
DEBUG - 2012-11-17 15:38:05 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Controller Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Model Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Model Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Model Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Model Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Model Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Model Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:38:05 --> Model Class Initialized
DEBUG - 2012-11-17 15:38:05 --> Model Class Initialized
DEBUG - 2012-11-17 15:38:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:38:05 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:38:05 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:38:12 --> Database Driver Class Initialized
ERROR - 2012-11-17 15:38:12 --> Severity: Notice  --> Undefined index: totalpage /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 64
ERROR - 2012-11-17 15:38:12 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 64
ERROR - 2012-11-17 15:38:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 64
DEBUG - 2012-11-17 15:38:12 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:38:12 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:38:12 --> Final output sent to browser
DEBUG - 2012-11-17 15:38:12 --> Total execution time: 6.5601
DEBUG - 2012-11-17 15:40:00 --> Config Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:40:00 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:40:00 --> URI Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Router Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Output Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Security Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Input Class Initialized
DEBUG - 2012-11-17 15:40:00 --> XSS Filtering completed
DEBUG - 2012-11-17 15:40:00 --> XSS Filtering completed
DEBUG - 2012-11-17 15:40:00 --> XSS Filtering completed
DEBUG - 2012-11-17 15:40:00 --> XSS Filtering completed
DEBUG - 2012-11-17 15:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:40:00 --> Language Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Loader Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:40:00 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:40:00 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:40:00 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:40:00 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:40:00 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:40:00 --> Session Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:40:00 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Session routines successfully run
DEBUG - 2012-11-17 15:40:00 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Controller Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:40:00 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:00 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:00 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:40:00 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:40:00 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:40:07 --> Database Driver Class Initialized
ERROR - 2012-11-17 15:40:07 --> Severity: Notice  --> Undefined index: totalpage /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 64
ERROR - 2012-11-17 15:40:07 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 64
ERROR - 2012-11-17 15:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 64
DEBUG - 2012-11-17 15:40:07 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:40:07 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:40:07 --> Final output sent to browser
DEBUG - 2012-11-17 15:40:07 --> Total execution time: 6.5843
DEBUG - 2012-11-17 15:40:42 --> Config Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:40:42 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:40:42 --> URI Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Router Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Output Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Security Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Input Class Initialized
DEBUG - 2012-11-17 15:40:42 --> XSS Filtering completed
DEBUG - 2012-11-17 15:40:42 --> XSS Filtering completed
DEBUG - 2012-11-17 15:40:42 --> XSS Filtering completed
DEBUG - 2012-11-17 15:40:42 --> XSS Filtering completed
DEBUG - 2012-11-17 15:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:40:42 --> Language Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Loader Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:40:42 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:40:42 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:40:42 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:40:42 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:40:42 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:40:42 --> Session Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:40:42 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Session routines successfully run
DEBUG - 2012-11-17 15:40:42 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Controller Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:40:42 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:42 --> Model Class Initialized
DEBUG - 2012-11-17 15:40:42 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:40:42 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:40:42 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:40:48 --> Database Driver Class Initialized
ERROR - 2012-11-17 15:40:48 --> Severity: Notice  --> Undefined index: totalpage /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 64
ERROR - 2012-11-17 15:40:48 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 64
ERROR - 2012-11-17 15:40:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 64
DEBUG - 2012-11-17 15:40:48 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:40:48 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:40:48 --> Final output sent to browser
DEBUG - 2012-11-17 15:40:48 --> Total execution time: 6.5787
DEBUG - 2012-11-17 15:41:28 --> Config Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:41:28 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:41:28 --> URI Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Router Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Output Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Security Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Input Class Initialized
DEBUG - 2012-11-17 15:41:28 --> XSS Filtering completed
DEBUG - 2012-11-17 15:41:28 --> XSS Filtering completed
DEBUG - 2012-11-17 15:41:28 --> XSS Filtering completed
DEBUG - 2012-11-17 15:41:28 --> XSS Filtering completed
DEBUG - 2012-11-17 15:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:41:28 --> Language Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Loader Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:41:28 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:41:28 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:41:28 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:41:28 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:41:28 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:41:28 --> Session Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:41:28 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Session routines successfully run
DEBUG - 2012-11-17 15:41:28 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Controller Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Model Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Model Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Model Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Model Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Model Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Model Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:41:28 --> Model Class Initialized
DEBUG - 2012-11-17 15:41:28 --> Model Class Initialized
DEBUG - 2012-11-17 15:41:28 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:41:28 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:41:28 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:41:34 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:41:34 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:41:34 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:41:34 --> Final output sent to browser
DEBUG - 2012-11-17 15:41:34 --> Total execution time: 6.6688
DEBUG - 2012-11-17 15:46:55 --> Config Class Initialized
DEBUG - 2012-11-17 15:46:55 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:46:55 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:46:55 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:46:55 --> URI Class Initialized
DEBUG - 2012-11-17 15:46:55 --> Router Class Initialized
DEBUG - 2012-11-17 15:46:55 --> Output Class Initialized
DEBUG - 2012-11-17 15:46:55 --> Security Class Initialized
DEBUG - 2012-11-17 15:46:55 --> Input Class Initialized
DEBUG - 2012-11-17 15:46:55 --> XSS Filtering completed
DEBUG - 2012-11-17 15:46:55 --> XSS Filtering completed
DEBUG - 2012-11-17 15:46:55 --> XSS Filtering completed
DEBUG - 2012-11-17 15:46:55 --> XSS Filtering completed
DEBUG - 2012-11-17 15:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:46:55 --> Language Class Initialized
DEBUG - 2012-11-17 15:46:55 --> Loader Class Initialized
DEBUG - 2012-11-17 15:46:55 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:46:55 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:46:55 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:46:55 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:46:56 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:46:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:46:56 --> Session Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:46:56 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Session routines successfully run
DEBUG - 2012-11-17 15:46:56 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Controller Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Model Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Model Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Model Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Model Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Model Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Model Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:46:56 --> Model Class Initialized
DEBUG - 2012-11-17 15:46:56 --> Model Class Initialized
DEBUG - 2012-11-17 15:46:56 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:46:56 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:46:56 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:47:02 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:47:02 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:47:02 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:47:02 --> Final output sent to browser
DEBUG - 2012-11-17 15:47:02 --> Total execution time: 6.6488
DEBUG - 2012-11-17 15:47:25 --> Config Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:47:25 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:47:25 --> URI Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Router Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Output Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Security Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Input Class Initialized
DEBUG - 2012-11-17 15:47:25 --> XSS Filtering completed
DEBUG - 2012-11-17 15:47:25 --> XSS Filtering completed
DEBUG - 2012-11-17 15:47:25 --> XSS Filtering completed
DEBUG - 2012-11-17 15:47:25 --> XSS Filtering completed
DEBUG - 2012-11-17 15:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:47:25 --> Language Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Loader Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:47:25 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:47:25 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:47:25 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:47:25 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:47:25 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:47:25 --> Session Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:47:25 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Session routines successfully run
DEBUG - 2012-11-17 15:47:25 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Controller Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Model Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Model Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Model Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Model Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Model Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Model Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:47:25 --> Model Class Initialized
DEBUG - 2012-11-17 15:47:25 --> Model Class Initialized
DEBUG - 2012-11-17 15:47:25 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:47:25 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:47:25 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:47:32 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:47:32 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:47:32 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:47:32 --> Final output sent to browser
DEBUG - 2012-11-17 15:47:32 --> Total execution time: 6.6919
DEBUG - 2012-11-17 15:48:01 --> Config Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:48:01 --> URI Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Router Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Output Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Security Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Input Class Initialized
DEBUG - 2012-11-17 15:48:01 --> XSS Filtering completed
DEBUG - 2012-11-17 15:48:01 --> XSS Filtering completed
DEBUG - 2012-11-17 15:48:01 --> XSS Filtering completed
DEBUG - 2012-11-17 15:48:01 --> XSS Filtering completed
DEBUG - 2012-11-17 15:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:48:01 --> Language Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Loader Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:48:01 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:48:01 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:48:01 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:48:01 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:48:01 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:48:01 --> Session Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:48:01 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Session routines successfully run
DEBUG - 2012-11-17 15:48:01 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Controller Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Model Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Model Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Model Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Model Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Model Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Model Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:48:01 --> Model Class Initialized
DEBUG - 2012-11-17 15:48:01 --> Model Class Initialized
DEBUG - 2012-11-17 15:48:01 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:48:01 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:48:01 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:48:08 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:48:08 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:48:08 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:48:08 --> Final output sent to browser
DEBUG - 2012-11-17 15:48:08 --> Total execution time: 6.8096
DEBUG - 2012-11-17 15:49:31 --> Config Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:49:31 --> URI Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Router Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Output Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Security Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Input Class Initialized
DEBUG - 2012-11-17 15:49:31 --> XSS Filtering completed
DEBUG - 2012-11-17 15:49:31 --> XSS Filtering completed
DEBUG - 2012-11-17 15:49:31 --> XSS Filtering completed
DEBUG - 2012-11-17 15:49:31 --> XSS Filtering completed
DEBUG - 2012-11-17 15:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:49:31 --> Language Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Loader Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:49:31 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:49:31 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:49:31 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:49:31 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:49:31 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:49:31 --> Session Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:49:31 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Session routines successfully run
DEBUG - 2012-11-17 15:49:31 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Controller Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:49:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:49:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:49:31 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:49:31 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:49:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:49:38 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:49:38 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:49:38 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:49:38 --> Final output sent to browser
DEBUG - 2012-11-17 15:49:38 --> Total execution time: 6.7581
DEBUG - 2012-11-17 15:55:31 --> Config Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:55:31 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:55:31 --> URI Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Router Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Output Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Security Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Input Class Initialized
DEBUG - 2012-11-17 15:55:31 --> XSS Filtering completed
DEBUG - 2012-11-17 15:55:31 --> XSS Filtering completed
DEBUG - 2012-11-17 15:55:31 --> XSS Filtering completed
DEBUG - 2012-11-17 15:55:31 --> XSS Filtering completed
DEBUG - 2012-11-17 15:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:55:31 --> Language Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Loader Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:55:31 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:55:31 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:55:31 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:55:31 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:55:31 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:55:31 --> Session Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:55:31 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Session routines successfully run
DEBUG - 2012-11-17 15:55:31 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Controller Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:55:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:55:31 --> Model Class Initialized
DEBUG - 2012-11-17 15:55:31 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:55:31 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:55:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:55:38 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:55:38 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:55:38 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:55:38 --> Final output sent to browser
DEBUG - 2012-11-17 15:55:38 --> Total execution time: 6.5874
DEBUG - 2012-11-17 15:56:22 --> Config Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:56:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:56:22 --> URI Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Router Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Output Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Security Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Input Class Initialized
DEBUG - 2012-11-17 15:56:22 --> XSS Filtering completed
DEBUG - 2012-11-17 15:56:22 --> XSS Filtering completed
DEBUG - 2012-11-17 15:56:22 --> XSS Filtering completed
DEBUG - 2012-11-17 15:56:22 --> XSS Filtering completed
DEBUG - 2012-11-17 15:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:56:22 --> Language Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Loader Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:56:22 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:56:22 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:56:22 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:56:22 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:56:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:56:22 --> Session Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:56:22 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Session routines successfully run
DEBUG - 2012-11-17 15:56:22 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Controller Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Model Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Model Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Model Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Model Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Model Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Model Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:56:22 --> Model Class Initialized
DEBUG - 2012-11-17 15:56:22 --> Model Class Initialized
DEBUG - 2012-11-17 15:56:22 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:56:22 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:56:22 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:56:28 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:56:29 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:56:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:56:29 --> Final output sent to browser
DEBUG - 2012-11-17 15:56:29 --> Total execution time: 6.5841
DEBUG - 2012-11-17 15:57:55 --> Config Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:57:55 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:57:55 --> URI Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Router Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Output Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Security Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Input Class Initialized
DEBUG - 2012-11-17 15:57:55 --> XSS Filtering completed
DEBUG - 2012-11-17 15:57:55 --> XSS Filtering completed
DEBUG - 2012-11-17 15:57:55 --> XSS Filtering completed
DEBUG - 2012-11-17 15:57:55 --> XSS Filtering completed
DEBUG - 2012-11-17 15:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:57:55 --> Language Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Loader Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:57:55 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:57:55 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:57:55 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:57:55 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:57:55 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:57:55 --> Session Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:57:55 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Session routines successfully run
DEBUG - 2012-11-17 15:57:55 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Controller Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Model Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Model Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Model Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Model Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Model Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Model Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:57:55 --> Model Class Initialized
DEBUG - 2012-11-17 15:57:55 --> Model Class Initialized
DEBUG - 2012-11-17 15:57:55 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:57:55 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:57:55 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:58:01 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:58:01 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:58:01 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:58:01 --> Final output sent to browser
DEBUG - 2012-11-17 15:58:01 --> Total execution time: 6.5904
DEBUG - 2012-11-17 15:59:46 --> Config Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Hooks Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Utf8 Class Initialized
DEBUG - 2012-11-17 15:59:46 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 15:59:46 --> URI Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Router Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Output Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Security Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Input Class Initialized
DEBUG - 2012-11-17 15:59:46 --> XSS Filtering completed
DEBUG - 2012-11-17 15:59:46 --> XSS Filtering completed
DEBUG - 2012-11-17 15:59:46 --> XSS Filtering completed
DEBUG - 2012-11-17 15:59:46 --> XSS Filtering completed
DEBUG - 2012-11-17 15:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 15:59:46 --> Language Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Loader Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Helper loaded: date_helper
DEBUG - 2012-11-17 15:59:46 --> Helper loaded: form_helper
DEBUG - 2012-11-17 15:59:46 --> Helper loaded: language_helper
DEBUG - 2012-11-17 15:59:46 --> Helper loaded: url_helper
DEBUG - 2012-11-17 15:59:46 --> Helper loaded: html_helper
DEBUG - 2012-11-17 15:59:46 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 15:59:46 --> Session Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Helper loaded: string_helper
DEBUG - 2012-11-17 15:59:46 --> Encrypt Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Session routines successfully run
DEBUG - 2012-11-17 15:59:46 --> Form Validation Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Controller Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Model Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Model Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Model Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Model Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Model Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Model Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Helper loaded: file_helper
DEBUG - 2012-11-17 15:59:46 --> Model Class Initialized
DEBUG - 2012-11-17 15:59:46 --> Model Class Initialized
DEBUG - 2012-11-17 15:59:46 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 15:59:46 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 15:59:46 --> Database Driver Class Initialized
DEBUG - 2012-11-17 15:59:52 --> Database Driver Class Initialized
ERROR - 2012-11-17 15:59:52 --> Severity: Notice  --> Undefined variable: totalpages /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 22
DEBUG - 2012-11-17 15:59:52 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 15:59:52 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 15:59:52 --> Final output sent to browser
DEBUG - 2012-11-17 15:59:52 --> Total execution time: 6.7985
DEBUG - 2012-11-17 16:01:42 --> Config Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Hooks Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Utf8 Class Initialized
DEBUG - 2012-11-17 16:01:42 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 16:01:42 --> URI Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Router Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Output Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Security Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Input Class Initialized
DEBUG - 2012-11-17 16:01:42 --> XSS Filtering completed
DEBUG - 2012-11-17 16:01:42 --> XSS Filtering completed
DEBUG - 2012-11-17 16:01:42 --> XSS Filtering completed
DEBUG - 2012-11-17 16:01:42 --> XSS Filtering completed
DEBUG - 2012-11-17 16:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 16:01:42 --> Language Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Loader Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Helper loaded: date_helper
DEBUG - 2012-11-17 16:01:42 --> Helper loaded: form_helper
DEBUG - 2012-11-17 16:01:42 --> Helper loaded: language_helper
DEBUG - 2012-11-17 16:01:42 --> Helper loaded: url_helper
DEBUG - 2012-11-17 16:01:42 --> Helper loaded: html_helper
DEBUG - 2012-11-17 16:01:42 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 16:01:42 --> Session Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Helper loaded: string_helper
DEBUG - 2012-11-17 16:01:42 --> Encrypt Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Session routines successfully run
DEBUG - 2012-11-17 16:01:42 --> Form Validation Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Controller Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Model Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Model Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Model Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Model Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Model Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Model Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Helper loaded: file_helper
DEBUG - 2012-11-17 16:01:42 --> Model Class Initialized
DEBUG - 2012-11-17 16:01:42 --> Model Class Initialized
DEBUG - 2012-11-17 16:01:42 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 16:01:42 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 16:01:42 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:01:49 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:01:49 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 16:01:49 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 16:01:49 --> Final output sent to browser
DEBUG - 2012-11-17 16:01:49 --> Total execution time: 6.9119
DEBUG - 2012-11-17 16:03:06 --> Config Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Hooks Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Utf8 Class Initialized
DEBUG - 2012-11-17 16:03:06 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 16:03:06 --> URI Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Router Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Output Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Security Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Input Class Initialized
DEBUG - 2012-11-17 16:03:06 --> XSS Filtering completed
DEBUG - 2012-11-17 16:03:06 --> XSS Filtering completed
DEBUG - 2012-11-17 16:03:06 --> XSS Filtering completed
DEBUG - 2012-11-17 16:03:06 --> XSS Filtering completed
DEBUG - 2012-11-17 16:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 16:03:06 --> Language Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Loader Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Helper loaded: date_helper
DEBUG - 2012-11-17 16:03:06 --> Helper loaded: form_helper
DEBUG - 2012-11-17 16:03:06 --> Helper loaded: language_helper
DEBUG - 2012-11-17 16:03:06 --> Helper loaded: url_helper
DEBUG - 2012-11-17 16:03:06 --> Helper loaded: html_helper
DEBUG - 2012-11-17 16:03:06 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 16:03:06 --> Session Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Helper loaded: string_helper
DEBUG - 2012-11-17 16:03:06 --> Encrypt Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Session routines successfully run
DEBUG - 2012-11-17 16:03:06 --> Form Validation Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Controller Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Model Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Model Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Model Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Model Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Model Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Model Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Helper loaded: file_helper
DEBUG - 2012-11-17 16:03:06 --> Model Class Initialized
DEBUG - 2012-11-17 16:03:06 --> Model Class Initialized
DEBUG - 2012-11-17 16:03:06 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 16:03:06 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 16:03:06 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:03:12 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:03:12 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 16:03:12 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 16:03:12 --> Final output sent to browser
DEBUG - 2012-11-17 16:03:12 --> Total execution time: 6.7406
DEBUG - 2012-11-17 16:04:16 --> Config Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Hooks Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Utf8 Class Initialized
DEBUG - 2012-11-17 16:04:16 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 16:04:16 --> URI Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Router Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Output Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Security Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Input Class Initialized
DEBUG - 2012-11-17 16:04:16 --> XSS Filtering completed
DEBUG - 2012-11-17 16:04:16 --> XSS Filtering completed
DEBUG - 2012-11-17 16:04:16 --> XSS Filtering completed
DEBUG - 2012-11-17 16:04:16 --> XSS Filtering completed
DEBUG - 2012-11-17 16:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 16:04:16 --> Language Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Loader Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Helper loaded: date_helper
DEBUG - 2012-11-17 16:04:16 --> Helper loaded: form_helper
DEBUG - 2012-11-17 16:04:16 --> Helper loaded: language_helper
DEBUG - 2012-11-17 16:04:16 --> Helper loaded: url_helper
DEBUG - 2012-11-17 16:04:16 --> Helper loaded: html_helper
DEBUG - 2012-11-17 16:04:16 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 16:04:16 --> Session Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Helper loaded: string_helper
DEBUG - 2012-11-17 16:04:16 --> Encrypt Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Session routines successfully run
DEBUG - 2012-11-17 16:04:16 --> Form Validation Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Controller Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Model Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Model Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Model Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Model Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Model Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Model Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Helper loaded: file_helper
DEBUG - 2012-11-17 16:04:16 --> Model Class Initialized
DEBUG - 2012-11-17 16:04:16 --> Model Class Initialized
DEBUG - 2012-11-17 16:04:16 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 16:04:16 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 16:04:16 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:04:23 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:04:23 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 16:04:23 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 16:04:23 --> Final output sent to browser
DEBUG - 2012-11-17 16:04:23 --> Total execution time: 6.7428
DEBUG - 2012-11-17 16:43:31 --> Config Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Hooks Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Utf8 Class Initialized
DEBUG - 2012-11-17 16:43:31 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 16:43:31 --> URI Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Router Class Initialized
DEBUG - 2012-11-17 16:43:31 --> No URI present. Default controller set.
DEBUG - 2012-11-17 16:43:31 --> Output Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Security Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Input Class Initialized
DEBUG - 2012-11-17 16:43:31 --> XSS Filtering completed
DEBUG - 2012-11-17 16:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 16:43:31 --> Language Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Loader Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Helper loaded: date_helper
DEBUG - 2012-11-17 16:43:31 --> Helper loaded: form_helper
DEBUG - 2012-11-17 16:43:31 --> Helper loaded: language_helper
DEBUG - 2012-11-17 16:43:31 --> Helper loaded: url_helper
DEBUG - 2012-11-17 16:43:31 --> Helper loaded: html_helper
DEBUG - 2012-11-17 16:43:31 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 16:43:31 --> Session Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Helper loaded: string_helper
DEBUG - 2012-11-17 16:43:31 --> Encrypt Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Session routines successfully run
DEBUG - 2012-11-17 16:43:31 --> Form Validation Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Controller Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Model Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Model Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Helper loaded: file_helper
DEBUG - 2012-11-17 16:43:31 --> Model Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Model Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Model Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Model Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Model Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Model Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Model Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Database Forge Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Database Forge Class Initialized
DEBUG - 2012-11-17 16:43:31 --> Database Utility Class Initialized
ERROR - 2012-11-17 16:43:31 --> Severity: Notice  --> Undefined property: Index_controller::$analisis /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/index_controller.php 61
DEBUG - 2012-11-17 16:46:14 --> Config Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Hooks Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Utf8 Class Initialized
DEBUG - 2012-11-17 16:46:14 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 16:46:14 --> URI Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Router Class Initialized
DEBUG - 2012-11-17 16:46:14 --> No URI present. Default controller set.
DEBUG - 2012-11-17 16:46:14 --> Output Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Security Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Input Class Initialized
DEBUG - 2012-11-17 16:46:14 --> XSS Filtering completed
DEBUG - 2012-11-17 16:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 16:46:14 --> Language Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Loader Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Helper loaded: date_helper
DEBUG - 2012-11-17 16:46:14 --> Helper loaded: form_helper
DEBUG - 2012-11-17 16:46:14 --> Helper loaded: language_helper
DEBUG - 2012-11-17 16:46:14 --> Helper loaded: url_helper
DEBUG - 2012-11-17 16:46:14 --> Helper loaded: html_helper
DEBUG - 2012-11-17 16:46:14 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 16:46:14 --> Session Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Helper loaded: string_helper
DEBUG - 2012-11-17 16:46:14 --> Encrypt Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Session routines successfully run
DEBUG - 2012-11-17 16:46:14 --> Form Validation Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Controller Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Helper loaded: file_helper
DEBUG - 2012-11-17 16:46:14 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Database Forge Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Database Forge Class Initialized
DEBUG - 2012-11-17 16:46:14 --> Database Utility Class Initialized
ERROR - 2012-11-17 16:46:14 --> Severity: Notice  --> Undefined property: Index_controller::$user_model /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/index_controller.php 59
DEBUG - 2012-11-17 16:46:18 --> Config Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Hooks Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Utf8 Class Initialized
DEBUG - 2012-11-17 16:46:18 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 16:46:18 --> URI Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Router Class Initialized
DEBUG - 2012-11-17 16:46:18 --> No URI present. Default controller set.
DEBUG - 2012-11-17 16:46:18 --> Output Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Security Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Input Class Initialized
DEBUG - 2012-11-17 16:46:18 --> XSS Filtering completed
DEBUG - 2012-11-17 16:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 16:46:18 --> Language Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Loader Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Helper loaded: date_helper
DEBUG - 2012-11-17 16:46:18 --> Helper loaded: form_helper
DEBUG - 2012-11-17 16:46:18 --> Helper loaded: language_helper
DEBUG - 2012-11-17 16:46:18 --> Helper loaded: url_helper
DEBUG - 2012-11-17 16:46:18 --> Helper loaded: html_helper
DEBUG - 2012-11-17 16:46:18 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 16:46:18 --> Session Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Helper loaded: string_helper
DEBUG - 2012-11-17 16:46:18 --> Encrypt Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Session routines successfully run
DEBUG - 2012-11-17 16:46:18 --> Form Validation Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Controller Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Helper loaded: file_helper
DEBUG - 2012-11-17 16:46:18 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Database Forge Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Database Forge Class Initialized
DEBUG - 2012-11-17 16:46:18 --> Database Utility Class Initialized
ERROR - 2012-11-17 16:46:18 --> Severity: Notice  --> Undefined property: Index_controller::$user_model /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/index_controller.php 59
DEBUG - 2012-11-17 16:46:59 --> Config Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Hooks Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Utf8 Class Initialized
DEBUG - 2012-11-17 16:46:59 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 16:46:59 --> URI Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Router Class Initialized
DEBUG - 2012-11-17 16:46:59 --> No URI present. Default controller set.
DEBUG - 2012-11-17 16:46:59 --> Output Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Security Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Input Class Initialized
DEBUG - 2012-11-17 16:46:59 --> XSS Filtering completed
DEBUG - 2012-11-17 16:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 16:46:59 --> Language Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Loader Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Helper loaded: date_helper
DEBUG - 2012-11-17 16:46:59 --> Helper loaded: form_helper
DEBUG - 2012-11-17 16:46:59 --> Helper loaded: language_helper
DEBUG - 2012-11-17 16:46:59 --> Helper loaded: url_helper
DEBUG - 2012-11-17 16:46:59 --> Helper loaded: html_helper
DEBUG - 2012-11-17 16:46:59 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 16:46:59 --> Session Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Helper loaded: string_helper
DEBUG - 2012-11-17 16:46:59 --> Encrypt Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Session routines successfully run
DEBUG - 2012-11-17 16:46:59 --> Form Validation Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Controller Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Helper loaded: file_helper
DEBUG - 2012-11-17 16:46:59 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Model Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Database Forge Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Database Forge Class Initialized
DEBUG - 2012-11-17 16:46:59 --> Database Utility Class Initialized
ERROR - 2012-11-17 16:46:59 --> Severity: Notice  --> Undefined property: Index_controller::$user_model /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/index_controller.php 58
DEBUG - 2012-11-17 16:47:35 --> Config Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Hooks Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Utf8 Class Initialized
DEBUG - 2012-11-17 16:47:35 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 16:47:35 --> URI Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Router Class Initialized
DEBUG - 2012-11-17 16:47:35 --> No URI present. Default controller set.
DEBUG - 2012-11-17 16:47:35 --> Output Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Security Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Input Class Initialized
DEBUG - 2012-11-17 16:47:35 --> XSS Filtering completed
DEBUG - 2012-11-17 16:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 16:47:35 --> Language Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Loader Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Helper loaded: date_helper
DEBUG - 2012-11-17 16:47:35 --> Helper loaded: form_helper
DEBUG - 2012-11-17 16:47:35 --> Helper loaded: language_helper
DEBUG - 2012-11-17 16:47:35 --> Helper loaded: url_helper
DEBUG - 2012-11-17 16:47:35 --> Helper loaded: html_helper
DEBUG - 2012-11-17 16:47:35 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 16:47:35 --> Session Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Helper loaded: string_helper
DEBUG - 2012-11-17 16:47:35 --> Encrypt Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Session routines successfully run
DEBUG - 2012-11-17 16:47:35 --> Form Validation Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Controller Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Helper loaded: file_helper
DEBUG - 2012-11-17 16:47:35 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Database Forge Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Database Forge Class Initialized
DEBUG - 2012-11-17 16:47:35 --> Database Utility Class Initialized
DEBUG - 2012-11-17 16:47:35 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 16:47:35 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 16:47:35 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 16:47:35 --> Final output sent to browser
DEBUG - 2012-11-17 16:47:35 --> Total execution time: 0.0641
DEBUG - 2012-11-17 16:47:45 --> Config Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Hooks Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Utf8 Class Initialized
DEBUG - 2012-11-17 16:47:45 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 16:47:45 --> URI Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Router Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Output Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Security Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Input Class Initialized
DEBUG - 2012-11-17 16:47:45 --> XSS Filtering completed
DEBUG - 2012-11-17 16:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 16:47:45 --> Language Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Loader Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Helper loaded: date_helper
DEBUG - 2012-11-17 16:47:45 --> Helper loaded: form_helper
DEBUG - 2012-11-17 16:47:45 --> Helper loaded: language_helper
DEBUG - 2012-11-17 16:47:45 --> Helper loaded: url_helper
DEBUG - 2012-11-17 16:47:45 --> Helper loaded: html_helper
DEBUG - 2012-11-17 16:47:45 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 16:47:45 --> Session Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Helper loaded: string_helper
DEBUG - 2012-11-17 16:47:45 --> Encrypt Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Session routines successfully run
DEBUG - 2012-11-17 16:47:45 --> Form Validation Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Controller Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:45 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:45 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 16:47:45 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 16:47:45 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 16:47:45 --> Final output sent to browser
DEBUG - 2012-11-17 16:47:45 --> Total execution time: 0.0349
DEBUG - 2012-11-17 16:47:52 --> Config Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Hooks Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Utf8 Class Initialized
DEBUG - 2012-11-17 16:47:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 16:47:52 --> URI Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Router Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Output Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Security Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Input Class Initialized
DEBUG - 2012-11-17 16:47:52 --> XSS Filtering completed
DEBUG - 2012-11-17 16:47:52 --> XSS Filtering completed
DEBUG - 2012-11-17 16:47:52 --> XSS Filtering completed
DEBUG - 2012-11-17 16:47:52 --> XSS Filtering completed
DEBUG - 2012-11-17 16:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 16:47:52 --> Language Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Loader Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Helper loaded: date_helper
DEBUG - 2012-11-17 16:47:52 --> Helper loaded: form_helper
DEBUG - 2012-11-17 16:47:52 --> Helper loaded: language_helper
DEBUG - 2012-11-17 16:47:52 --> Helper loaded: url_helper
DEBUG - 2012-11-17 16:47:52 --> Helper loaded: html_helper
DEBUG - 2012-11-17 16:47:52 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 16:47:52 --> Session Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Helper loaded: string_helper
DEBUG - 2012-11-17 16:47:52 --> Encrypt Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Session routines successfully run
DEBUG - 2012-11-17 16:47:52 --> Form Validation Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Controller Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Helper loaded: file_helper
DEBUG - 2012-11-17 16:47:52 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:52 --> Model Class Initialized
DEBUG - 2012-11-17 16:47:52 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 16:47:52 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 16:47:52 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:47:58 --> Database Driver Class Initialized
DEBUG - 2012-11-17 16:47:59 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 16:47:59 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 16:47:59 --> Final output sent to browser
DEBUG - 2012-11-17 16:47:59 --> Total execution time: 6.7294
DEBUG - 2012-11-17 17:01:22 --> Config Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Hooks Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Utf8 Class Initialized
DEBUG - 2012-11-17 17:01:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 17:01:22 --> URI Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Router Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Output Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Security Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Input Class Initialized
DEBUG - 2012-11-17 17:01:22 --> XSS Filtering completed
DEBUG - 2012-11-17 17:01:22 --> XSS Filtering completed
DEBUG - 2012-11-17 17:01:22 --> XSS Filtering completed
DEBUG - 2012-11-17 17:01:22 --> XSS Filtering completed
DEBUG - 2012-11-17 17:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 17:01:22 --> Language Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Loader Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Helper loaded: date_helper
DEBUG - 2012-11-17 17:01:22 --> Helper loaded: form_helper
DEBUG - 2012-11-17 17:01:22 --> Helper loaded: language_helper
DEBUG - 2012-11-17 17:01:22 --> Helper loaded: url_helper
DEBUG - 2012-11-17 17:01:22 --> Helper loaded: html_helper
DEBUG - 2012-11-17 17:01:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 17:01:22 --> Session Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Helper loaded: string_helper
DEBUG - 2012-11-17 17:01:22 --> Encrypt Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Session routines successfully run
DEBUG - 2012-11-17 17:01:22 --> Form Validation Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Controller Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Model Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Model Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Model Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Model Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Model Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Model Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Helper loaded: file_helper
DEBUG - 2012-11-17 17:01:22 --> Model Class Initialized
DEBUG - 2012-11-17 17:01:22 --> Model Class Initialized
DEBUG - 2012-11-17 17:01:22 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 17:01:22 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 17:01:22 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:01:28 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:01:28 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 17:01:28 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 17:01:28 --> Final output sent to browser
DEBUG - 2012-11-17 17:01:28 --> Total execution time: 6.6384
DEBUG - 2012-11-17 17:04:56 --> Config Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Hooks Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Utf8 Class Initialized
DEBUG - 2012-11-17 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 17:04:56 --> URI Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Router Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Output Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Security Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Input Class Initialized
DEBUG - 2012-11-17 17:04:56 --> XSS Filtering completed
DEBUG - 2012-11-17 17:04:56 --> XSS Filtering completed
DEBUG - 2012-11-17 17:04:56 --> XSS Filtering completed
DEBUG - 2012-11-17 17:04:56 --> XSS Filtering completed
DEBUG - 2012-11-17 17:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 17:04:56 --> Language Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Loader Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Helper loaded: date_helper
DEBUG - 2012-11-17 17:04:56 --> Helper loaded: form_helper
DEBUG - 2012-11-17 17:04:56 --> Helper loaded: language_helper
DEBUG - 2012-11-17 17:04:56 --> Helper loaded: url_helper
DEBUG - 2012-11-17 17:04:56 --> Helper loaded: html_helper
DEBUG - 2012-11-17 17:04:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 17:04:56 --> Session Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Helper loaded: string_helper
DEBUG - 2012-11-17 17:04:56 --> Encrypt Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Session routines successfully run
DEBUG - 2012-11-17 17:04:56 --> Form Validation Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Controller Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Model Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Model Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Model Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Model Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Model Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Model Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Helper loaded: file_helper
DEBUG - 2012-11-17 17:04:56 --> Model Class Initialized
DEBUG - 2012-11-17 17:04:56 --> Model Class Initialized
DEBUG - 2012-11-17 17:04:56 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 17:04:56 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 17:04:56 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:05:02 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Config Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Hooks Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Utf8 Class Initialized
DEBUG - 2012-11-17 17:05:20 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 17:05:20 --> URI Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Router Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Output Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Security Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Input Class Initialized
DEBUG - 2012-11-17 17:05:20 --> XSS Filtering completed
DEBUG - 2012-11-17 17:05:20 --> XSS Filtering completed
DEBUG - 2012-11-17 17:05:20 --> XSS Filtering completed
DEBUG - 2012-11-17 17:05:20 --> XSS Filtering completed
DEBUG - 2012-11-17 17:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 17:05:20 --> Language Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Loader Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Helper loaded: date_helper
DEBUG - 2012-11-17 17:05:20 --> Helper loaded: form_helper
DEBUG - 2012-11-17 17:05:20 --> Helper loaded: language_helper
DEBUG - 2012-11-17 17:05:20 --> Helper loaded: url_helper
DEBUG - 2012-11-17 17:05:20 --> Helper loaded: html_helper
DEBUG - 2012-11-17 17:05:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 17:05:20 --> Session Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Helper loaded: string_helper
DEBUG - 2012-11-17 17:05:20 --> Encrypt Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Session routines successfully run
DEBUG - 2012-11-17 17:05:20 --> Form Validation Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Controller Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Model Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Model Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Model Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Model Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Model Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Model Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Helper loaded: file_helper
DEBUG - 2012-11-17 17:05:20 --> Model Class Initialized
DEBUG - 2012-11-17 17:05:20 --> Model Class Initialized
DEBUG - 2012-11-17 17:05:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 17:05:20 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 17:05:20 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:05:27 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:05:28 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 17:05:28 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 17:05:28 --> Final output sent to browser
DEBUG - 2012-11-17 17:05:28 --> Total execution time: 8.3114
DEBUG - 2012-11-17 17:06:04 --> Config Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Hooks Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Utf8 Class Initialized
DEBUG - 2012-11-17 17:06:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 17:06:04 --> URI Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Router Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Output Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Security Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Input Class Initialized
DEBUG - 2012-11-17 17:06:04 --> XSS Filtering completed
DEBUG - 2012-11-17 17:06:04 --> XSS Filtering completed
DEBUG - 2012-11-17 17:06:04 --> XSS Filtering completed
DEBUG - 2012-11-17 17:06:04 --> XSS Filtering completed
DEBUG - 2012-11-17 17:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 17:06:04 --> Language Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Loader Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Helper loaded: date_helper
DEBUG - 2012-11-17 17:06:04 --> Helper loaded: form_helper
DEBUG - 2012-11-17 17:06:04 --> Helper loaded: language_helper
DEBUG - 2012-11-17 17:06:04 --> Helper loaded: url_helper
DEBUG - 2012-11-17 17:06:04 --> Helper loaded: html_helper
DEBUG - 2012-11-17 17:06:04 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 17:06:04 --> Session Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Helper loaded: string_helper
DEBUG - 2012-11-17 17:06:04 --> Encrypt Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Session routines successfully run
DEBUG - 2012-11-17 17:06:04 --> Form Validation Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Controller Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Model Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Model Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Model Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Model Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Model Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Model Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Helper loaded: file_helper
DEBUG - 2012-11-17 17:06:04 --> Model Class Initialized
DEBUG - 2012-11-17 17:06:04 --> Model Class Initialized
DEBUG - 2012-11-17 17:06:04 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 17:06:04 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 17:06:04 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:06:11 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:06:15 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 17:06:15 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 17:06:15 --> Final output sent to browser
DEBUG - 2012-11-17 17:06:15 --> Total execution time: 11.3314
DEBUG - 2012-11-17 17:08:51 --> Config Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Hooks Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Utf8 Class Initialized
DEBUG - 2012-11-17 17:08:51 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 17:08:51 --> URI Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Router Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Output Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Security Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Input Class Initialized
DEBUG - 2012-11-17 17:08:51 --> XSS Filtering completed
DEBUG - 2012-11-17 17:08:51 --> XSS Filtering completed
DEBUG - 2012-11-17 17:08:51 --> XSS Filtering completed
DEBUG - 2012-11-17 17:08:51 --> XSS Filtering completed
DEBUG - 2012-11-17 17:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 17:08:51 --> Language Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Loader Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Helper loaded: date_helper
DEBUG - 2012-11-17 17:08:51 --> Helper loaded: form_helper
DEBUG - 2012-11-17 17:08:51 --> Helper loaded: language_helper
DEBUG - 2012-11-17 17:08:51 --> Helper loaded: url_helper
DEBUG - 2012-11-17 17:08:51 --> Helper loaded: html_helper
DEBUG - 2012-11-17 17:08:51 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 17:08:51 --> Session Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Helper loaded: string_helper
DEBUG - 2012-11-17 17:08:51 --> Encrypt Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Session routines successfully run
DEBUG - 2012-11-17 17:08:51 --> Form Validation Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Controller Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Model Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Model Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Model Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Model Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Model Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Model Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Helper loaded: file_helper
DEBUG - 2012-11-17 17:08:51 --> Model Class Initialized
DEBUG - 2012-11-17 17:08:51 --> Model Class Initialized
DEBUG - 2012-11-17 17:08:51 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 17:08:51 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 17:08:51 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:08:58 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:09:04 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 17:09:04 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 17:09:04 --> Final output sent to browser
DEBUG - 2012-11-17 17:09:04 --> Total execution time: 12.8507
DEBUG - 2012-11-17 17:16:02 --> Config Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Hooks Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Utf8 Class Initialized
DEBUG - 2012-11-17 17:16:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 17:16:02 --> URI Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Router Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Output Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Security Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Input Class Initialized
DEBUG - 2012-11-17 17:16:02 --> XSS Filtering completed
DEBUG - 2012-11-17 17:16:02 --> XSS Filtering completed
DEBUG - 2012-11-17 17:16:02 --> XSS Filtering completed
DEBUG - 2012-11-17 17:16:02 --> XSS Filtering completed
DEBUG - 2012-11-17 17:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 17:16:02 --> Language Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Loader Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Helper loaded: date_helper
DEBUG - 2012-11-17 17:16:02 --> Helper loaded: form_helper
DEBUG - 2012-11-17 17:16:02 --> Helper loaded: language_helper
DEBUG - 2012-11-17 17:16:02 --> Helper loaded: url_helper
DEBUG - 2012-11-17 17:16:02 --> Helper loaded: html_helper
DEBUG - 2012-11-17 17:16:02 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 17:16:02 --> Session Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Helper loaded: string_helper
DEBUG - 2012-11-17 17:16:02 --> Encrypt Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Session routines successfully run
DEBUG - 2012-11-17 17:16:02 --> Form Validation Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Controller Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Model Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Model Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Model Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Model Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Model Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Model Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Helper loaded: file_helper
DEBUG - 2012-11-17 17:16:02 --> Model Class Initialized
DEBUG - 2012-11-17 17:16:02 --> Model Class Initialized
DEBUG - 2012-11-17 17:16:02 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 17:16:02 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 17:16:02 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:16:09 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:16:15 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 17:16:15 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 17:16:15 --> Final output sent to browser
DEBUG - 2012-11-17 17:16:15 --> Total execution time: 12.8788
DEBUG - 2012-11-17 17:33:27 --> Config Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Hooks Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Utf8 Class Initialized
DEBUG - 2012-11-17 17:33:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 17:33:27 --> URI Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Router Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Output Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Security Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Input Class Initialized
DEBUG - 2012-11-17 17:33:27 --> XSS Filtering completed
DEBUG - 2012-11-17 17:33:27 --> XSS Filtering completed
DEBUG - 2012-11-17 17:33:27 --> XSS Filtering completed
DEBUG - 2012-11-17 17:33:27 --> XSS Filtering completed
DEBUG - 2012-11-17 17:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 17:33:27 --> Language Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Loader Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Helper loaded: date_helper
DEBUG - 2012-11-17 17:33:27 --> Helper loaded: form_helper
DEBUG - 2012-11-17 17:33:27 --> Helper loaded: language_helper
DEBUG - 2012-11-17 17:33:27 --> Helper loaded: url_helper
DEBUG - 2012-11-17 17:33:27 --> Helper loaded: html_helper
DEBUG - 2012-11-17 17:33:27 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 17:33:27 --> Session Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Helper loaded: string_helper
DEBUG - 2012-11-17 17:33:27 --> Encrypt Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Session routines successfully run
DEBUG - 2012-11-17 17:33:27 --> Form Validation Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Controller Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Model Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Model Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Model Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Model Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Model Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Model Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Helper loaded: file_helper
DEBUG - 2012-11-17 17:33:27 --> Model Class Initialized
DEBUG - 2012-11-17 17:33:27 --> Model Class Initialized
DEBUG - 2012-11-17 17:33:27 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 17:33:27 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 17:33:27 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:33:34 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:33:40 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 17:33:40 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 17:33:40 --> Final output sent to browser
DEBUG - 2012-11-17 17:33:40 --> Total execution time: 12.9703
DEBUG - 2012-11-17 17:36:26 --> Config Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Hooks Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Utf8 Class Initialized
DEBUG - 2012-11-17 17:36:26 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 17:36:26 --> URI Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Router Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Output Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Security Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Input Class Initialized
DEBUG - 2012-11-17 17:36:26 --> XSS Filtering completed
DEBUG - 2012-11-17 17:36:26 --> XSS Filtering completed
DEBUG - 2012-11-17 17:36:26 --> XSS Filtering completed
DEBUG - 2012-11-17 17:36:26 --> XSS Filtering completed
DEBUG - 2012-11-17 17:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 17:36:26 --> Language Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Loader Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Helper loaded: date_helper
DEBUG - 2012-11-17 17:36:26 --> Helper loaded: form_helper
DEBUG - 2012-11-17 17:36:26 --> Helper loaded: language_helper
DEBUG - 2012-11-17 17:36:26 --> Helper loaded: url_helper
DEBUG - 2012-11-17 17:36:26 --> Helper loaded: html_helper
DEBUG - 2012-11-17 17:36:26 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 17:36:26 --> Session Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Helper loaded: string_helper
DEBUG - 2012-11-17 17:36:26 --> Encrypt Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Session routines successfully run
DEBUG - 2012-11-17 17:36:26 --> Form Validation Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Controller Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Model Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Model Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Model Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Model Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Model Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Model Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Helper loaded: file_helper
DEBUG - 2012-11-17 17:36:26 --> Model Class Initialized
DEBUG - 2012-11-17 17:36:26 --> Model Class Initialized
DEBUG - 2012-11-17 17:36:26 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 17:36:26 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 17:36:26 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:36:33 --> Database Driver Class Initialized
DEBUG - 2012-11-17 17:36:39 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 17:36:39 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 17:36:39 --> Final output sent to browser
DEBUG - 2012-11-17 17:36:39 --> Total execution time: 12.7574
DEBUG - 2012-11-17 18:08:25 --> Config Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:08:25 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:08:25 --> URI Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Router Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Output Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Security Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Input Class Initialized
DEBUG - 2012-11-17 18:08:25 --> XSS Filtering completed
DEBUG - 2012-11-17 18:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:08:25 --> Language Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Loader Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:08:25 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:08:25 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:08:25 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:08:25 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:08:25 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:08:25 --> Session Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:08:25 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Session routines successfully run
DEBUG - 2012-11-17 18:08:25 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Controller Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:25 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:08:25 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:08:25 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:08:25 --> Final output sent to browser
DEBUG - 2012-11-17 18:08:25 --> Total execution time: 0.0787
DEBUG - 2012-11-17 18:08:27 --> Config Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:08:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:08:27 --> URI Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Router Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Output Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Security Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Input Class Initialized
DEBUG - 2012-11-17 18:08:27 --> XSS Filtering completed
DEBUG - 2012-11-17 18:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:08:27 --> Language Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Loader Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:08:27 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:08:27 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:08:27 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:08:27 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:08:27 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:08:27 --> Session Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:08:27 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Session routines successfully run
DEBUG - 2012-11-17 18:08:27 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Controller Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:27 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:08:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:08:27 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:08:27 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:08:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:08:27 --> Final output sent to browser
DEBUG - 2012-11-17 18:08:27 --> Total execution time: 0.0604
DEBUG - 2012-11-17 18:09:33 --> Config Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:09:33 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:09:33 --> URI Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Router Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Output Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Security Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Input Class Initialized
DEBUG - 2012-11-17 18:09:33 --> XSS Filtering completed
DEBUG - 2012-11-17 18:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:09:33 --> Language Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Loader Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:09:33 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:09:33 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:09:33 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:09:33 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:09:33 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:09:33 --> Session Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:09:33 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Session routines successfully run
DEBUG - 2012-11-17 18:09:33 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Controller Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:33 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:09:33 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:33 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:09:33 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:09:33 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:09:33 --> Final output sent to browser
DEBUG - 2012-11-17 18:09:33 --> Total execution time: 0.0544
DEBUG - 2012-11-17 18:09:51 --> Config Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:09:51 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:09:51 --> URI Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Router Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Output Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Security Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Input Class Initialized
DEBUG - 2012-11-17 18:09:51 --> XSS Filtering completed
DEBUG - 2012-11-17 18:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:09:51 --> Language Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Loader Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:09:51 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:09:51 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:09:51 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:09:51 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:09:51 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:09:51 --> Session Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:09:51 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Session routines successfully run
DEBUG - 2012-11-17 18:09:51 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Controller Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:51 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:09:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:51 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:09:51 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:09:51 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:09:51 --> Final output sent to browser
DEBUG - 2012-11-17 18:09:51 --> Total execution time: 0.0523
DEBUG - 2012-11-17 18:09:56 --> Config Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:09:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:09:56 --> URI Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Router Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Output Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Security Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Input Class Initialized
DEBUG - 2012-11-17 18:09:56 --> XSS Filtering completed
DEBUG - 2012-11-17 18:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:09:56 --> Language Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Loader Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:09:56 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:09:56 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:09:56 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:09:56 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:09:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:09:56 --> Session Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:09:56 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Session routines successfully run
DEBUG - 2012-11-17 18:09:56 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Controller Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:56 --> Model Class Initialized
DEBUG - 2012-11-17 18:09:56 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:09:56 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 18:09:56 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:09:56 --> Final output sent to browser
DEBUG - 2012-11-17 18:09:56 --> Total execution time: 0.0346
DEBUG - 2012-11-17 18:10:11 --> Config Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:10:11 --> URI Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Router Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Output Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Security Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Input Class Initialized
DEBUG - 2012-11-17 18:10:11 --> XSS Filtering completed
DEBUG - 2012-11-17 18:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:10:11 --> Language Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Loader Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:10:11 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:10:11 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:10:11 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:10:11 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:10:11 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:10:11 --> Session Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:10:11 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Session routines successfully run
DEBUG - 2012-11-17 18:10:11 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Controller Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:11 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:11 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:10:11 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 18:10:11 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:10:11 --> Final output sent to browser
DEBUG - 2012-11-17 18:10:11 --> Total execution time: 0.0380
DEBUG - 2012-11-17 18:10:14 --> Config Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:10:14 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:10:14 --> URI Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Router Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Output Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Security Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Input Class Initialized
DEBUG - 2012-11-17 18:10:14 --> XSS Filtering completed
DEBUG - 2012-11-17 18:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:10:14 --> Language Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Loader Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:10:14 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:10:14 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:10:14 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:10:14 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:10:14 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:10:14 --> Session Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:10:14 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Session routines successfully run
DEBUG - 2012-11-17 18:10:14 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Controller Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:14 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:14 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:10:14 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 18:10:14 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:10:14 --> Final output sent to browser
DEBUG - 2012-11-17 18:10:14 --> Total execution time: 0.0322
DEBUG - 2012-11-17 18:10:19 --> Config Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:10:19 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:10:19 --> URI Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Router Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Output Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Security Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Input Class Initialized
DEBUG - 2012-11-17 18:10:19 --> XSS Filtering completed
DEBUG - 2012-11-17 18:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:10:19 --> Language Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Loader Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:10:19 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:10:19 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:10:19 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:10:19 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:10:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:10:19 --> Session Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:10:19 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Session routines successfully run
DEBUG - 2012-11-17 18:10:19 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Controller Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:10:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:10:19 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:10:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:10:19 --> Final output sent to browser
DEBUG - 2012-11-17 18:10:19 --> Total execution time: 0.0344
DEBUG - 2012-11-17 18:16:07 --> Config Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:16:07 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:16:07 --> URI Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Router Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Output Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Security Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Input Class Initialized
DEBUG - 2012-11-17 18:16:07 --> XSS Filtering completed
DEBUG - 2012-11-17 18:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:16:07 --> Language Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Loader Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:16:07 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:16:07 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:16:07 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:16:07 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:16:07 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:16:07 --> Session Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:16:07 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Session routines successfully run
DEBUG - 2012-11-17 18:16:07 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Controller Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:07 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:16:07 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:16:07 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:16:07 --> Final output sent to browser
DEBUG - 2012-11-17 18:16:07 --> Total execution time: 0.0402
DEBUG - 2012-11-17 18:16:10 --> Config Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:16:10 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:16:10 --> URI Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Router Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Output Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Security Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Input Class Initialized
DEBUG - 2012-11-17 18:16:10 --> XSS Filtering completed
DEBUG - 2012-11-17 18:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:16:10 --> Language Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Loader Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:16:10 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:16:10 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:16:10 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:16:10 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:16:10 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:16:10 --> Session Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:16:10 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Session routines successfully run
DEBUG - 2012-11-17 18:16:10 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Controller Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:10 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:10 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:16:10 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:16:10 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:16:10 --> Final output sent to browser
DEBUG - 2012-11-17 18:16:10 --> Total execution time: 0.0332
DEBUG - 2012-11-17 18:16:50 --> Config Class Initialized
DEBUG - 2012-11-17 18:16:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:16:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:16:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:16:50 --> URI Class Initialized
DEBUG - 2012-11-17 18:16:50 --> Router Class Initialized
DEBUG - 2012-11-17 18:16:50 --> Output Class Initialized
DEBUG - 2012-11-17 18:16:50 --> Security Class Initialized
DEBUG - 2012-11-17 18:16:50 --> Input Class Initialized
DEBUG - 2012-11-17 18:16:50 --> XSS Filtering completed
DEBUG - 2012-11-17 18:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:16:51 --> Language Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Loader Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:16:51 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:16:51 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:16:51 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:16:51 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:16:51 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:16:51 --> Session Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:16:51 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Session routines successfully run
DEBUG - 2012-11-17 18:16:51 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Controller Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:51 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:51 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:16:51 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:16:51 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:16:51 --> Final output sent to browser
DEBUG - 2012-11-17 18:16:51 --> Total execution time: 0.0390
DEBUG - 2012-11-17 18:16:55 --> Config Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:16:55 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:16:55 --> URI Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Router Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Output Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Security Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Input Class Initialized
DEBUG - 2012-11-17 18:16:55 --> XSS Filtering completed
DEBUG - 2012-11-17 18:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:16:55 --> Language Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Loader Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:16:55 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:16:55 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:16:55 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:16:55 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:16:55 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:16:55 --> Session Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:16:55 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Session routines successfully run
DEBUG - 2012-11-17 18:16:55 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Controller Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:55 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:16:55 --> Model Class Initialized
DEBUG - 2012-11-17 18:16:55 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:16:55 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:16:55 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:16:55 --> Final output sent to browser
DEBUG - 2012-11-17 18:16:55 --> Total execution time: 0.0550
DEBUG - 2012-11-17 18:18:36 --> Config Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:18:36 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:18:36 --> URI Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Router Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Output Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Security Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Input Class Initialized
DEBUG - 2012-11-17 18:18:36 --> XSS Filtering completed
DEBUG - 2012-11-17 18:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:18:36 --> Language Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Loader Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:18:36 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:18:36 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:18:36 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:18:36 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:18:36 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:18:36 --> Session Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:18:36 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Session routines successfully run
DEBUG - 2012-11-17 18:18:36 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Controller Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:36 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:18:36 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:36 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:18:36 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:18:36 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:18:36 --> Final output sent to browser
DEBUG - 2012-11-17 18:18:36 --> Total execution time: 0.0653
DEBUG - 2012-11-17 18:18:42 --> Config Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:18:42 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:18:42 --> URI Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Router Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Output Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Security Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Input Class Initialized
DEBUG - 2012-11-17 18:18:42 --> XSS Filtering completed
DEBUG - 2012-11-17 18:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:18:42 --> Language Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Loader Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:18:42 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:18:42 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:18:42 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:18:42 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:18:42 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:18:42 --> Session Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:18:42 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Session routines successfully run
DEBUG - 2012-11-17 18:18:42 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Controller Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:42 --> Model Class Initialized
DEBUG - 2012-11-17 18:18:42 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:18:42 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:18:42 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:18:42 --> Final output sent to browser
DEBUG - 2012-11-17 18:18:42 --> Total execution time: 0.0379
DEBUG - 2012-11-17 18:19:18 --> Config Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:19:18 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:19:18 --> URI Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Router Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Output Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Security Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Input Class Initialized
DEBUG - 2012-11-17 18:19:18 --> XSS Filtering completed
DEBUG - 2012-11-17 18:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:19:18 --> Language Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Loader Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:19:18 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:19:18 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:19:18 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:19:18 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:19:18 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:19:18 --> Session Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:19:18 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Session routines successfully run
DEBUG - 2012-11-17 18:19:18 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Controller Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:18 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:19:18 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:19:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:19:18 --> Final output sent to browser
DEBUG - 2012-11-17 18:19:18 --> Total execution time: 0.0370
DEBUG - 2012-11-17 18:19:23 --> Config Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:19:23 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:19:23 --> URI Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Router Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Output Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Security Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Input Class Initialized
DEBUG - 2012-11-17 18:19:23 --> XSS Filtering completed
DEBUG - 2012-11-17 18:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:19:23 --> Language Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Loader Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:19:23 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:19:23 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:19:23 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:19:23 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:19:23 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:19:23 --> Session Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:19:23 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Session routines successfully run
DEBUG - 2012-11-17 18:19:23 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Controller Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:23 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:19:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:23 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:19:23 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:19:23 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:19:23 --> Final output sent to browser
DEBUG - 2012-11-17 18:19:23 --> Total execution time: 0.0533
DEBUG - 2012-11-17 18:19:27 --> Config Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:19:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:19:27 --> URI Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Router Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Output Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Security Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Input Class Initialized
DEBUG - 2012-11-17 18:19:27 --> XSS Filtering completed
DEBUG - 2012-11-17 18:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:19:27 --> Language Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Loader Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:19:27 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:19:27 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:19:27 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:19:27 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:19:27 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:19:27 --> Session Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:19:27 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Session routines successfully run
DEBUG - 2012-11-17 18:19:27 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Controller Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:27 --> Model Class Initialized
DEBUG - 2012-11-17 18:19:27 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:19:27 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:19:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:19:27 --> Final output sent to browser
DEBUG - 2012-11-17 18:19:27 --> Total execution time: 0.0359
DEBUG - 2012-11-17 18:23:07 --> Config Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:23:07 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:23:07 --> URI Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Router Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Output Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Security Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Input Class Initialized
DEBUG - 2012-11-17 18:23:07 --> XSS Filtering completed
DEBUG - 2012-11-17 18:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:23:07 --> Language Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Loader Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:23:07 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:23:07 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:23:07 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:23:07 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:23:07 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:23:07 --> Session Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:23:07 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Session routines successfully run
DEBUG - 2012-11-17 18:23:07 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Controller Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:07 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:07 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:23:07 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:23:07 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:23:07 --> Final output sent to browser
DEBUG - 2012-11-17 18:23:07 --> Total execution time: 0.0400
DEBUG - 2012-11-17 18:23:19 --> Config Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:23:19 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:23:19 --> URI Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Router Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Output Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Security Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Input Class Initialized
DEBUG - 2012-11-17 18:23:19 --> XSS Filtering completed
DEBUG - 2012-11-17 18:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:23:19 --> Language Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Loader Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:23:19 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:23:19 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:23:19 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:23:19 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:23:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:23:19 --> Session Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:23:19 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Session routines successfully run
DEBUG - 2012-11-17 18:23:19 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Controller Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:19 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:23:19 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:23:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:23:19 --> Final output sent to browser
DEBUG - 2012-11-17 18:23:19 --> Total execution time: 0.0403
DEBUG - 2012-11-17 18:23:20 --> Config Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:23:20 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:23:20 --> URI Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Router Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Output Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Security Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Input Class Initialized
DEBUG - 2012-11-17 18:23:20 --> XSS Filtering completed
DEBUG - 2012-11-17 18:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:23:20 --> Language Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Loader Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:23:20 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:23:20 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:23:20 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:23:20 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:23:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:23:20 --> Session Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:23:20 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Session routines successfully run
DEBUG - 2012-11-17 18:23:20 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Controller Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:23:20 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:23:20 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:23:20 --> Final output sent to browser
DEBUG - 2012-11-17 18:23:20 --> Total execution time: 0.0378
DEBUG - 2012-11-17 18:23:21 --> Config Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:23:21 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:23:21 --> URI Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Router Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Output Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Security Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Input Class Initialized
DEBUG - 2012-11-17 18:23:21 --> XSS Filtering completed
DEBUG - 2012-11-17 18:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:23:21 --> Language Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Loader Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:23:21 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:23:21 --> Session Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:23:21 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Session routines successfully run
DEBUG - 2012-11-17 18:23:21 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Controller Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:23:21 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:23:21 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:23:21 --> Final output sent to browser
DEBUG - 2012-11-17 18:23:21 --> Total execution time: 0.0624
DEBUG - 2012-11-17 18:23:21 --> Config Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:23:21 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:23:21 --> URI Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Router Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Output Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Security Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Input Class Initialized
DEBUG - 2012-11-17 18:23:21 --> XSS Filtering completed
DEBUG - 2012-11-17 18:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:23:21 --> Language Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Loader Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:23:21 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:23:21 --> Session Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:23:21 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Session routines successfully run
DEBUG - 2012-11-17 18:23:21 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Controller Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> Model Class Initialized
DEBUG - 2012-11-17 18:23:21 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:23:21 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:23:21 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:23:21 --> Final output sent to browser
DEBUG - 2012-11-17 18:23:21 --> Total execution time: 0.0341
DEBUG - 2012-11-17 18:24:09 --> Config Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:24:09 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:24:09 --> URI Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Router Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Output Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Security Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Input Class Initialized
DEBUG - 2012-11-17 18:24:09 --> XSS Filtering completed
DEBUG - 2012-11-17 18:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:24:09 --> Language Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Loader Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:24:09 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:24:09 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:24:09 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:24:09 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:24:09 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:24:09 --> Session Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:24:09 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Session routines successfully run
DEBUG - 2012-11-17 18:24:09 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Controller Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:09 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:09 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:24:09 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:24:09 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:24:09 --> Final output sent to browser
DEBUG - 2012-11-17 18:24:09 --> Total execution time: 0.0449
DEBUG - 2012-11-17 18:24:45 --> Config Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:24:45 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:24:45 --> URI Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Router Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Output Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Security Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Input Class Initialized
DEBUG - 2012-11-17 18:24:45 --> XSS Filtering completed
DEBUG - 2012-11-17 18:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:24:45 --> Language Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Loader Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:24:45 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:24:45 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:24:45 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:24:45 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:24:45 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:24:45 --> Session Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:24:45 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Session routines successfully run
DEBUG - 2012-11-17 18:24:45 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Controller Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:45 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:45 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:24:45 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:24:45 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:24:45 --> Final output sent to browser
DEBUG - 2012-11-17 18:24:45 --> Total execution time: 0.0386
DEBUG - 2012-11-17 18:24:57 --> Config Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:24:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:24:57 --> URI Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Router Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Output Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Security Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Input Class Initialized
DEBUG - 2012-11-17 18:24:57 --> XSS Filtering completed
DEBUG - 2012-11-17 18:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:24:57 --> Language Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Loader Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:24:57 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:24:57 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:24:57 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:24:57 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:24:57 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:24:57 --> Session Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:24:57 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Session routines successfully run
DEBUG - 2012-11-17 18:24:57 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Controller Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:57 --> Model Class Initialized
DEBUG - 2012-11-17 18:24:57 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:24:57 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:24:57 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:24:57 --> Final output sent to browser
DEBUG - 2012-11-17 18:24:57 --> Total execution time: 0.0387
DEBUG - 2012-11-17 18:25:34 --> Config Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:25:34 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:25:34 --> URI Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Router Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Output Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Security Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Input Class Initialized
DEBUG - 2012-11-17 18:25:34 --> XSS Filtering completed
DEBUG - 2012-11-17 18:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:25:34 --> Language Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Loader Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:25:34 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:25:34 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:25:34 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:25:34 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:25:34 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:25:34 --> Session Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:25:34 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Session routines successfully run
DEBUG - 2012-11-17 18:25:34 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Controller Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Model Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Model Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Model Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Model Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Model Class Initialized
DEBUG - 2012-11-17 18:25:34 --> Model Class Initialized
DEBUG - 2012-11-17 18:25:34 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:25:34 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:25:34 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:25:34 --> Final output sent to browser
DEBUG - 2012-11-17 18:25:34 --> Total execution time: 0.0377
DEBUG - 2012-11-17 18:26:38 --> Config Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:26:38 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:26:38 --> URI Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Router Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Output Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Security Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Input Class Initialized
DEBUG - 2012-11-17 18:26:38 --> XSS Filtering completed
DEBUG - 2012-11-17 18:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:26:38 --> Language Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Loader Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:26:38 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:26:38 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:26:38 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:26:38 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:26:38 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:26:38 --> Session Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:26:38 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Session routines successfully run
DEBUG - 2012-11-17 18:26:38 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Controller Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:38 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:38 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:26:38 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:26:38 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:26:38 --> Final output sent to browser
DEBUG - 2012-11-17 18:26:38 --> Total execution time: 0.0385
DEBUG - 2012-11-17 18:26:49 --> Config Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:26:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:26:49 --> URI Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Router Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Output Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Security Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Input Class Initialized
DEBUG - 2012-11-17 18:26:49 --> XSS Filtering completed
DEBUG - 2012-11-17 18:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:26:49 --> Language Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Loader Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:26:49 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:26:49 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:26:49 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:26:49 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:26:49 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:26:49 --> Session Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:26:49 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Session routines successfully run
DEBUG - 2012-11-17 18:26:49 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Controller Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:26:49 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:26:49 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:26:49 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:26:49 --> Final output sent to browser
DEBUG - 2012-11-17 18:26:49 --> Total execution time: 0.0357
DEBUG - 2012-11-17 18:27:04 --> Config Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:27:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:27:04 --> URI Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Router Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Output Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Security Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Input Class Initialized
DEBUG - 2012-11-17 18:27:04 --> XSS Filtering completed
DEBUG - 2012-11-17 18:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:27:04 --> Language Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Loader Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:27:04 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:27:04 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:27:04 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:27:04 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:27:04 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:27:04 --> Session Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:27:04 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Session routines successfully run
DEBUG - 2012-11-17 18:27:04 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Controller Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:04 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:27:04 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:27:04 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:27:04 --> Final output sent to browser
DEBUG - 2012-11-17 18:27:04 --> Total execution time: 0.0389
DEBUG - 2012-11-17 18:27:18 --> Config Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:27:18 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:27:18 --> URI Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Router Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Output Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Security Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Input Class Initialized
DEBUG - 2012-11-17 18:27:18 --> XSS Filtering completed
DEBUG - 2012-11-17 18:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:27:18 --> Language Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Loader Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:27:18 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:27:18 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:27:18 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:27:18 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:27:18 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:27:18 --> Session Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:27:18 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Session routines successfully run
DEBUG - 2012-11-17 18:27:18 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Controller Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:18 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:18 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:27:18 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:27:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:27:18 --> Final output sent to browser
DEBUG - 2012-11-17 18:27:18 --> Total execution time: 0.0379
DEBUG - 2012-11-17 18:27:24 --> Config Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:27:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:27:24 --> URI Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Router Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Output Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Security Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Input Class Initialized
DEBUG - 2012-11-17 18:27:24 --> XSS Filtering completed
DEBUG - 2012-11-17 18:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:27:24 --> Language Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Loader Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:27:24 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:27:24 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:27:24 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:27:24 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:27:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:27:24 --> Session Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:27:24 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Session routines successfully run
DEBUG - 2012-11-17 18:27:24 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Controller Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:27:24 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:27:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:27:24 --> Final output sent to browser
DEBUG - 2012-11-17 18:27:24 --> Total execution time: 0.0396
DEBUG - 2012-11-17 18:27:32 --> Config Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:27:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:27:32 --> URI Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Router Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Output Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Security Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Input Class Initialized
DEBUG - 2012-11-17 18:27:32 --> XSS Filtering completed
DEBUG - 2012-11-17 18:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:27:32 --> Language Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Loader Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:27:32 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:27:32 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:27:32 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:27:32 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:27:32 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:27:32 --> Session Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:27:32 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Session routines successfully run
DEBUG - 2012-11-17 18:27:32 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Controller Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:27:32 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:27:32 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:27:32 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:27:32 --> Final output sent to browser
DEBUG - 2012-11-17 18:27:32 --> Total execution time: 0.0413
DEBUG - 2012-11-17 18:49:24 --> Config Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:49:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:49:24 --> URI Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Router Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Output Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Security Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Input Class Initialized
DEBUG - 2012-11-17 18:49:24 --> XSS Filtering completed
DEBUG - 2012-11-17 18:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:49:24 --> Language Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Loader Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:49:24 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:49:24 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:49:24 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:49:24 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:49:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:49:24 --> Session Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:49:24 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Session routines successfully run
DEBUG - 2012-11-17 18:49:24 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Controller Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:49:24 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:49:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:49:24 --> Final output sent to browser
DEBUG - 2012-11-17 18:49:24 --> Total execution time: 0.0429
DEBUG - 2012-11-17 18:49:30 --> Config Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:49:30 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:49:30 --> URI Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Router Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Output Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Security Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Input Class Initialized
DEBUG - 2012-11-17 18:49:30 --> XSS Filtering completed
DEBUG - 2012-11-17 18:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:49:30 --> Language Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Loader Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:49:30 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:49:30 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:49:30 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:49:30 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:49:30 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:49:30 --> Session Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:49:30 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Session routines successfully run
DEBUG - 2012-11-17 18:49:30 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Controller Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:30 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:30 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:49:30 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:49:30 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:49:30 --> Final output sent to browser
DEBUG - 2012-11-17 18:49:30 --> Total execution time: 0.0352
DEBUG - 2012-11-17 18:49:32 --> Config Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:49:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:49:32 --> URI Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Router Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Output Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Security Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Input Class Initialized
DEBUG - 2012-11-17 18:49:32 --> XSS Filtering completed
DEBUG - 2012-11-17 18:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:49:32 --> Language Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Loader Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:49:32 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:49:32 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:49:32 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:49:32 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:49:32 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:49:32 --> Session Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:49:32 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Session routines successfully run
DEBUG - 2012-11-17 18:49:32 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Controller Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:32 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:32 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:49:32 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:49:32 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:49:32 --> Final output sent to browser
DEBUG - 2012-11-17 18:49:32 --> Total execution time: 0.0345
DEBUG - 2012-11-17 18:49:35 --> Config Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:49:35 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:49:35 --> URI Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Router Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Output Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Security Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Input Class Initialized
DEBUG - 2012-11-17 18:49:35 --> XSS Filtering completed
DEBUG - 2012-11-17 18:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:49:35 --> Language Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Loader Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:49:35 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:49:35 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:49:35 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:49:35 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:49:35 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:49:35 --> Session Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:49:35 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Session routines successfully run
DEBUG - 2012-11-17 18:49:35 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Controller Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:35 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:35 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:49:35 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:49:35 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:49:35 --> Final output sent to browser
DEBUG - 2012-11-17 18:49:35 --> Total execution time: 0.0535
DEBUG - 2012-11-17 18:49:43 --> Config Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:49:43 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:49:43 --> URI Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Router Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Output Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Security Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Input Class Initialized
DEBUG - 2012-11-17 18:49:43 --> XSS Filtering completed
DEBUG - 2012-11-17 18:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:49:43 --> Language Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Loader Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:49:43 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:49:43 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:49:43 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:49:43 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:49:43 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:49:43 --> Session Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:49:43 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Session routines successfully run
DEBUG - 2012-11-17 18:49:43 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Controller Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:43 --> Model Class Initialized
DEBUG - 2012-11-17 18:49:43 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:49:43 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:49:43 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:49:43 --> Final output sent to browser
DEBUG - 2012-11-17 18:49:43 --> Total execution time: 0.0397
DEBUG - 2012-11-17 18:50:23 --> Config Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:50:23 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:50:23 --> URI Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Router Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Output Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Security Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Input Class Initialized
DEBUG - 2012-11-17 18:50:23 --> XSS Filtering completed
DEBUG - 2012-11-17 18:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:50:23 --> Language Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Loader Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:50:23 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:50:23 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:50:23 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:50:23 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:50:23 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:50:23 --> Session Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:50:23 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Session routines successfully run
DEBUG - 2012-11-17 18:50:23 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Controller Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:23 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:23 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:50:23 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:50:23 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:50:23 --> Final output sent to browser
DEBUG - 2012-11-17 18:50:23 --> Total execution time: 0.0381
DEBUG - 2012-11-17 18:50:25 --> Config Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:50:25 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:50:25 --> URI Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Router Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Output Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Security Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Input Class Initialized
DEBUG - 2012-11-17 18:50:25 --> XSS Filtering completed
DEBUG - 2012-11-17 18:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:50:25 --> Language Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Loader Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:50:25 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:50:25 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:50:25 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:50:25 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:50:25 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:50:25 --> Session Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:50:25 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Session routines successfully run
DEBUG - 2012-11-17 18:50:25 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Controller Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:25 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:25 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:50:25 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:50:25 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:50:25 --> Final output sent to browser
DEBUG - 2012-11-17 18:50:25 --> Total execution time: 0.0389
DEBUG - 2012-11-17 18:50:37 --> Config Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:50:37 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:50:37 --> URI Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Router Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Output Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Security Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Input Class Initialized
DEBUG - 2012-11-17 18:50:37 --> XSS Filtering completed
DEBUG - 2012-11-17 18:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:50:37 --> Language Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Loader Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:50:37 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:50:37 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:50:37 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:50:37 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:50:37 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:50:37 --> Session Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:50:37 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Session routines successfully run
DEBUG - 2012-11-17 18:50:37 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Controller Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:37 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:37 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:50:37 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:50:37 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:50:37 --> Final output sent to browser
DEBUG - 2012-11-17 18:50:37 --> Total execution time: 0.0396
DEBUG - 2012-11-17 18:50:52 --> Config Class Initialized
DEBUG - 2012-11-17 18:50:52 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:50:52 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:50:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:50:52 --> URI Class Initialized
DEBUG - 2012-11-17 18:50:52 --> Router Class Initialized
DEBUG - 2012-11-17 18:50:52 --> Output Class Initialized
DEBUG - 2012-11-17 18:50:52 --> Security Class Initialized
DEBUG - 2012-11-17 18:50:52 --> Input Class Initialized
DEBUG - 2012-11-17 18:50:53 --> XSS Filtering completed
DEBUG - 2012-11-17 18:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:50:53 --> Language Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Loader Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:50:53 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:50:53 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:50:53 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:50:53 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:50:53 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:50:53 --> Session Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:50:53 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Session routines successfully run
DEBUG - 2012-11-17 18:50:53 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Controller Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:53 --> Model Class Initialized
DEBUG - 2012-11-17 18:50:53 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:50:53 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:50:53 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:50:53 --> Final output sent to browser
DEBUG - 2012-11-17 18:50:53 --> Total execution time: 0.0363
DEBUG - 2012-11-17 18:51:04 --> Config Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:51:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:51:04 --> URI Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Router Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Output Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Security Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Input Class Initialized
DEBUG - 2012-11-17 18:51:04 --> XSS Filtering completed
DEBUG - 2012-11-17 18:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:51:04 --> Language Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Loader Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:51:04 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:51:04 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:51:04 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:51:04 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:51:04 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:51:04 --> Session Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:51:04 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Session routines successfully run
DEBUG - 2012-11-17 18:51:04 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Controller Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:51:04 --> Model Class Initialized
DEBUG - 2012-11-17 18:51:04 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:51:04 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:51:04 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:51:04 --> Final output sent to browser
DEBUG - 2012-11-17 18:51:04 --> Total execution time: 0.0359
DEBUG - 2012-11-17 18:52:50 --> Config Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:52:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:52:50 --> URI Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Router Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Output Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Security Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Input Class Initialized
DEBUG - 2012-11-17 18:52:50 --> XSS Filtering completed
DEBUG - 2012-11-17 18:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:52:50 --> Language Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Loader Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:52:50 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:52:50 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:52:50 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:52:50 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:52:50 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:52:50 --> Session Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:52:50 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Session routines successfully run
DEBUG - 2012-11-17 18:52:50 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Controller Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:50 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:50 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:52:50 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:52:50 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:52:50 --> Final output sent to browser
DEBUG - 2012-11-17 18:52:50 --> Total execution time: 0.0376
DEBUG - 2012-11-17 18:52:58 --> Config Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:52:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:52:58 --> URI Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Router Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Output Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Security Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Input Class Initialized
DEBUG - 2012-11-17 18:52:58 --> XSS Filtering completed
DEBUG - 2012-11-17 18:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:52:58 --> Language Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Loader Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:52:58 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:52:58 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:52:58 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:52:58 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:52:58 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:52:58 --> Session Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:52:58 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Session routines successfully run
DEBUG - 2012-11-17 18:52:58 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Controller Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:58 --> Model Class Initialized
DEBUG - 2012-11-17 18:52:58 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:52:58 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:52:58 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:52:58 --> Final output sent to browser
DEBUG - 2012-11-17 18:52:58 --> Total execution time: 0.0391
DEBUG - 2012-11-17 18:53:05 --> Config Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:53:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:53:05 --> URI Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Router Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Output Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Security Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Input Class Initialized
DEBUG - 2012-11-17 18:53:05 --> XSS Filtering completed
DEBUG - 2012-11-17 18:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:53:05 --> Language Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Loader Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:53:05 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:53:05 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:53:05 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:53:05 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:53:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:53:05 --> Session Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:53:05 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Session routines successfully run
DEBUG - 2012-11-17 18:53:05 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Controller Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Model Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Model Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Model Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Model Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Model Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Model Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Model Class Initialized
DEBUG - 2012-11-17 18:53:05 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:53:05 --> Model Class Initialized
DEBUG - 2012-11-17 18:53:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:53:05 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:53:05 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:53:05 --> Final output sent to browser
DEBUG - 2012-11-17 18:53:05 --> Total execution time: 0.0604
DEBUG - 2012-11-17 18:54:49 --> Config Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:54:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:54:49 --> URI Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Router Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Output Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Security Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Input Class Initialized
DEBUG - 2012-11-17 18:54:49 --> XSS Filtering completed
DEBUG - 2012-11-17 18:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:54:49 --> Language Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Loader Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:54:49 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:54:49 --> Session Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:54:49 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Session routines successfully run
DEBUG - 2012-11-17 18:54:49 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Controller Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:54:49 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:54:49 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:54:49 --> Final output sent to browser
DEBUG - 2012-11-17 18:54:49 --> Total execution time: 0.0410
DEBUG - 2012-11-17 18:54:49 --> Config Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:54:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:54:49 --> URI Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Router Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Output Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Security Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Input Class Initialized
DEBUG - 2012-11-17 18:54:49 --> XSS Filtering completed
DEBUG - 2012-11-17 18:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:54:49 --> Language Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Loader Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:54:49 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:54:49 --> Session Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:54:49 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Session routines successfully run
DEBUG - 2012-11-17 18:54:49 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Controller Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:49 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:54:49 --> Model Class Initialized
DEBUG - 2012-11-17 18:54:50 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:54:50 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:54:50 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:54:50 --> Final output sent to browser
DEBUG - 2012-11-17 18:54:50 --> Total execution time: 0.0603
DEBUG - 2012-11-17 18:58:48 --> Config Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:58:48 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:58:48 --> URI Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Router Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Output Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Security Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Input Class Initialized
DEBUG - 2012-11-17 18:58:48 --> XSS Filtering completed
DEBUG - 2012-11-17 18:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:58:48 --> Language Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Loader Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:58:48 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:58:48 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:58:48 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:58:48 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:58:48 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:58:48 --> Session Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:58:48 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Session routines successfully run
DEBUG - 2012-11-17 18:58:48 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Controller Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Model Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Model Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Model Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Model Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Model Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Model Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Model Class Initialized
DEBUG - 2012-11-17 18:58:48 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:58:48 --> Model Class Initialized
DEBUG - 2012-11-17 18:58:48 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:58:48 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:58:48 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:58:48 --> Final output sent to browser
DEBUG - 2012-11-17 18:58:48 --> Total execution time: 0.0565
DEBUG - 2012-11-17 18:59:20 --> Config Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:59:20 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:59:20 --> URI Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Router Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Output Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Security Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Input Class Initialized
DEBUG - 2012-11-17 18:59:20 --> XSS Filtering completed
DEBUG - 2012-11-17 18:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:59:20 --> Language Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Loader Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:59:20 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:59:20 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:59:20 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:59:20 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:59:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:59:20 --> Session Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:59:20 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Session routines successfully run
DEBUG - 2012-11-17 18:59:20 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Controller Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:20 --> Helper loaded: file_helper
DEBUG - 2012-11-17 18:59:20 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:59:20 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 18:59:20 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:59:20 --> Final output sent to browser
DEBUG - 2012-11-17 18:59:20 --> Total execution time: 0.0609
DEBUG - 2012-11-17 18:59:24 --> Config Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Hooks Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Utf8 Class Initialized
DEBUG - 2012-11-17 18:59:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 18:59:24 --> URI Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Router Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Output Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Security Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Input Class Initialized
DEBUG - 2012-11-17 18:59:24 --> XSS Filtering completed
DEBUG - 2012-11-17 18:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 18:59:24 --> Language Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Loader Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Helper loaded: date_helper
DEBUG - 2012-11-17 18:59:24 --> Helper loaded: form_helper
DEBUG - 2012-11-17 18:59:24 --> Helper loaded: language_helper
DEBUG - 2012-11-17 18:59:24 --> Helper loaded: url_helper
DEBUG - 2012-11-17 18:59:24 --> Helper loaded: html_helper
DEBUG - 2012-11-17 18:59:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 18:59:24 --> Session Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Helper loaded: string_helper
DEBUG - 2012-11-17 18:59:24 --> Encrypt Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Session routines successfully run
DEBUG - 2012-11-17 18:59:24 --> Form Validation Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Controller Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Database Driver Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:24 --> Model Class Initialized
DEBUG - 2012-11-17 18:59:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 18:59:24 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 18:59:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 18:59:24 --> Final output sent to browser
DEBUG - 2012-11-17 18:59:24 --> Total execution time: 0.0357
DEBUG - 2012-11-17 19:00:16 --> Config Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:00:16 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:00:16 --> URI Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Router Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Output Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Security Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Input Class Initialized
DEBUG - 2012-11-17 19:00:16 --> XSS Filtering completed
DEBUG - 2012-11-17 19:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:00:16 --> Language Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Loader Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:00:16 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:00:16 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:00:16 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:00:16 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:00:16 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:00:16 --> Session Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:00:16 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Session routines successfully run
DEBUG - 2012-11-17 19:00:16 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Controller Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:16 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:00:16 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:00:16 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:00:16 --> Final output sent to browser
DEBUG - 2012-11-17 19:00:16 --> Total execution time: 0.0488
DEBUG - 2012-11-17 19:00:46 --> Config Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:00:46 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:00:46 --> URI Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Router Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Output Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Security Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Input Class Initialized
DEBUG - 2012-11-17 19:00:46 --> XSS Filtering completed
DEBUG - 2012-11-17 19:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:00:46 --> Language Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Loader Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:00:46 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:00:46 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:00:46 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:00:46 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:00:46 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:00:46 --> Session Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:00:46 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Session routines successfully run
DEBUG - 2012-11-17 19:00:46 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Controller Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:46 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:00:46 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:00:46 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:00:46 --> Final output sent to browser
DEBUG - 2012-11-17 19:00:46 --> Total execution time: 0.0370
DEBUG - 2012-11-17 19:00:58 --> Config Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:00:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:00:58 --> URI Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Router Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Output Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Security Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Input Class Initialized
DEBUG - 2012-11-17 19:00:58 --> XSS Filtering completed
DEBUG - 2012-11-17 19:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:00:58 --> Language Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Loader Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:00:58 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:00:58 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:00:58 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:00:58 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:00:58 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:00:58 --> Session Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:00:58 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Session routines successfully run
DEBUG - 2012-11-17 19:00:58 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Controller Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:00:58 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:00:58 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:00:58 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:00:58 --> Final output sent to browser
DEBUG - 2012-11-17 19:00:58 --> Total execution time: 0.0400
DEBUG - 2012-11-17 19:06:10 --> Config Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:06:10 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:06:10 --> URI Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Router Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Output Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Security Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Input Class Initialized
DEBUG - 2012-11-17 19:06:10 --> XSS Filtering completed
DEBUG - 2012-11-17 19:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:06:10 --> Language Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Loader Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:06:10 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:06:10 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:06:10 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:06:10 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:06:10 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:06:10 --> Session Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:06:10 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Session routines successfully run
DEBUG - 2012-11-17 19:06:10 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Controller Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:10 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:06:10 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:06:10 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:06:10 --> Final output sent to browser
DEBUG - 2012-11-17 19:06:10 --> Total execution time: 0.0378
DEBUG - 2012-11-17 19:06:28 --> Config Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:06:28 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:06:28 --> URI Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Router Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Output Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Security Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Input Class Initialized
DEBUG - 2012-11-17 19:06:28 --> XSS Filtering completed
DEBUG - 2012-11-17 19:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:06:28 --> Language Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Loader Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:06:28 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:06:28 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:06:28 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:06:28 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:06:28 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:06:28 --> Session Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:06:28 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Session routines successfully run
DEBUG - 2012-11-17 19:06:28 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Controller Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:28 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:28 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:06:28 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:06:28 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:06:28 --> Final output sent to browser
DEBUG - 2012-11-17 19:06:28 --> Total execution time: 0.0353
DEBUG - 2012-11-17 19:06:29 --> Config Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:06:29 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:06:29 --> URI Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Router Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Output Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Security Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Input Class Initialized
DEBUG - 2012-11-17 19:06:29 --> XSS Filtering completed
DEBUG - 2012-11-17 19:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:06:29 --> Language Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Loader Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:06:29 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:06:29 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:06:29 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:06:29 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:06:29 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:06:29 --> Session Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:06:29 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Session routines successfully run
DEBUG - 2012-11-17 19:06:29 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Controller Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:29 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:29 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:06:29 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:06:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:06:29 --> Final output sent to browser
DEBUG - 2012-11-17 19:06:29 --> Total execution time: 0.0339
DEBUG - 2012-11-17 19:06:40 --> Config Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:06:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:06:40 --> URI Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Router Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Output Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Security Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Input Class Initialized
DEBUG - 2012-11-17 19:06:40 --> XSS Filtering completed
DEBUG - 2012-11-17 19:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:06:40 --> Language Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Loader Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:06:40 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:06:40 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:06:40 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:06:40 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:06:40 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:06:40 --> Session Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:06:40 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Session routines successfully run
DEBUG - 2012-11-17 19:06:40 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Controller Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:06:40 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:06:40 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:06:40 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:06:40 --> Final output sent to browser
DEBUG - 2012-11-17 19:06:40 --> Total execution time: 0.0395
DEBUG - 2012-11-17 19:10:24 --> Config Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:10:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:10:24 --> URI Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Router Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Output Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Security Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Input Class Initialized
DEBUG - 2012-11-17 19:10:24 --> XSS Filtering completed
DEBUG - 2012-11-17 19:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:10:24 --> Language Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Loader Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:10:24 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:10:24 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:10:24 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:10:24 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:10:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:10:24 --> Session Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:10:24 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Session routines successfully run
DEBUG - 2012-11-17 19:10:24 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Controller Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:10:24 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:10:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:10:24 --> Final output sent to browser
DEBUG - 2012-11-17 19:10:24 --> Total execution time: 0.0424
DEBUG - 2012-11-17 19:10:42 --> Config Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:10:42 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:10:42 --> URI Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Router Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Output Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Security Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Input Class Initialized
DEBUG - 2012-11-17 19:10:42 --> XSS Filtering completed
DEBUG - 2012-11-17 19:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:10:42 --> Language Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Loader Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:10:42 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:10:42 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:10:42 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:10:42 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:10:42 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:10:42 --> Session Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:10:42 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Session routines successfully run
DEBUG - 2012-11-17 19:10:42 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Controller Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:42 --> Model Class Initialized
DEBUG - 2012-11-17 19:10:42 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:10:42 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:10:42 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:10:42 --> Final output sent to browser
DEBUG - 2012-11-17 19:10:42 --> Total execution time: 0.0414
DEBUG - 2012-11-17 19:14:15 --> Config Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:14:15 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:14:15 --> URI Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Router Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Output Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Security Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Input Class Initialized
DEBUG - 2012-11-17 19:14:15 --> XSS Filtering completed
DEBUG - 2012-11-17 19:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:14:15 --> Language Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Loader Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:14:15 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:14:15 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:14:15 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:14:15 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:14:15 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:14:15 --> Session Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:14:15 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Session routines successfully run
DEBUG - 2012-11-17 19:14:15 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Controller Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Model Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Model Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Model Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Model Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Model Class Initialized
DEBUG - 2012-11-17 19:14:15 --> Model Class Initialized
DEBUG - 2012-11-17 19:14:15 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:14:15 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:14:15 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:14:15 --> Final output sent to browser
DEBUG - 2012-11-17 19:14:15 --> Total execution time: 0.0425
DEBUG - 2012-11-17 19:15:59 --> Config Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:15:59 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:15:59 --> URI Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Router Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Output Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Security Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Input Class Initialized
DEBUG - 2012-11-17 19:15:59 --> XSS Filtering completed
DEBUG - 2012-11-17 19:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:15:59 --> Language Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Loader Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:15:59 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:15:59 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:15:59 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:15:59 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:15:59 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:15:59 --> Session Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:15:59 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Session routines successfully run
DEBUG - 2012-11-17 19:15:59 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Controller Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:15:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:15:59 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:15:59 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:15:59 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:15:59 --> Final output sent to browser
DEBUG - 2012-11-17 19:15:59 --> Total execution time: 0.0386
DEBUG - 2012-11-17 19:16:12 --> Config Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:16:12 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:16:12 --> URI Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Router Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Output Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Security Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Input Class Initialized
DEBUG - 2012-11-17 19:16:12 --> XSS Filtering completed
DEBUG - 2012-11-17 19:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:16:12 --> Language Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Loader Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:16:12 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:16:12 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:16:12 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:16:12 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:16:12 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:16:12 --> Session Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:16:12 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Session routines successfully run
DEBUG - 2012-11-17 19:16:12 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Controller Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:12 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:12 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:16:12 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:16:12 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:16:12 --> Final output sent to browser
DEBUG - 2012-11-17 19:16:12 --> Total execution time: 0.0361
DEBUG - 2012-11-17 19:16:27 --> Config Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:16:27 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:16:27 --> URI Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Router Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Output Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Security Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Input Class Initialized
DEBUG - 2012-11-17 19:16:27 --> XSS Filtering completed
DEBUG - 2012-11-17 19:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:16:27 --> Language Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Loader Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:16:27 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:16:27 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:16:27 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:16:27 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:16:27 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:16:27 --> Session Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:16:27 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Session routines successfully run
DEBUG - 2012-11-17 19:16:27 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Controller Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:27 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:27 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:16:27 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:16:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:16:27 --> Final output sent to browser
DEBUG - 2012-11-17 19:16:27 --> Total execution time: 0.0346
DEBUG - 2012-11-17 19:16:30 --> Config Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:16:30 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:16:30 --> URI Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Router Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Output Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Security Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Input Class Initialized
DEBUG - 2012-11-17 19:16:30 --> XSS Filtering completed
DEBUG - 2012-11-17 19:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:16:30 --> Language Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Loader Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:16:30 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:16:30 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:16:30 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:16:30 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:16:30 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:16:30 --> Session Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:16:30 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Session routines successfully run
DEBUG - 2012-11-17 19:16:30 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Controller Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:30 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:16:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:16:30 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:16:30 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:16:30 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:16:30 --> Final output sent to browser
DEBUG - 2012-11-17 19:16:30 --> Total execution time: 0.0639
DEBUG - 2012-11-17 19:19:50 --> Config Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:19:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:19:50 --> URI Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Router Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Output Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Security Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Input Class Initialized
DEBUG - 2012-11-17 19:19:50 --> XSS Filtering completed
DEBUG - 2012-11-17 19:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:19:50 --> Language Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Loader Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:19:50 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:19:50 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:19:50 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:19:50 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:19:50 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:19:50 --> Session Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:19:50 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Session routines successfully run
DEBUG - 2012-11-17 19:19:50 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Controller Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:19:50 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:19:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:19:50 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:19:50 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:19:50 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:19:50 --> Final output sent to browser
DEBUG - 2012-11-17 19:19:50 --> Total execution time: 0.0634
DEBUG - 2012-11-17 19:20:11 --> Config Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:20:11 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:20:11 --> URI Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Router Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Output Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Security Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Input Class Initialized
DEBUG - 2012-11-17 19:20:11 --> XSS Filtering completed
DEBUG - 2012-11-17 19:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:20:11 --> Language Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Loader Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:20:11 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:20:11 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:20:11 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:20:11 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:20:11 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:20:11 --> Session Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:20:11 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Session routines successfully run
DEBUG - 2012-11-17 19:20:11 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Controller Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:11 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:20:11 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:11 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:20:11 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:20:11 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:20:11 --> Final output sent to browser
DEBUG - 2012-11-17 19:20:11 --> Total execution time: 0.0638
DEBUG - 2012-11-17 19:20:46 --> Config Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:20:46 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:20:46 --> URI Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Router Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Output Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Security Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Input Class Initialized
DEBUG - 2012-11-17 19:20:46 --> XSS Filtering completed
DEBUG - 2012-11-17 19:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:20:46 --> Language Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Loader Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:20:46 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:20:46 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:20:46 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:20:46 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:20:46 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:20:46 --> Session Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:20:46 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Session routines successfully run
DEBUG - 2012-11-17 19:20:46 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Controller Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:46 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:20:46 --> Model Class Initialized
DEBUG - 2012-11-17 19:20:46 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:20:46 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:20:46 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:20:46 --> Final output sent to browser
DEBUG - 2012-11-17 19:20:46 --> Total execution time: 0.0645
DEBUG - 2012-11-17 19:21:37 --> Config Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:21:37 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:21:37 --> URI Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Router Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Output Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Security Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Input Class Initialized
DEBUG - 2012-11-17 19:21:37 --> XSS Filtering completed
DEBUG - 2012-11-17 19:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:21:37 --> Language Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Loader Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:21:37 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:21:37 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:21:37 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:21:37 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:21:37 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:21:37 --> Session Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:21:37 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Session routines successfully run
DEBUG - 2012-11-17 19:21:37 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Controller Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:21:37 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:21:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:21:37 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:21:37 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:21:37 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:21:37 --> Final output sent to browser
DEBUG - 2012-11-17 19:21:37 --> Total execution time: 0.0632
DEBUG - 2012-11-17 19:22:35 --> Config Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:22:35 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:22:35 --> URI Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Router Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Output Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Security Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Input Class Initialized
DEBUG - 2012-11-17 19:22:35 --> XSS Filtering completed
DEBUG - 2012-11-17 19:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:22:35 --> Language Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Loader Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:22:35 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:22:35 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:22:35 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:22:35 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:22:35 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:22:35 --> Session Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:22:35 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Session routines successfully run
DEBUG - 2012-11-17 19:22:35 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Controller Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:22:35 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:22:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:22:35 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:22:35 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:22:35 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:22:35 --> Final output sent to browser
DEBUG - 2012-11-17 19:22:35 --> Total execution time: 0.0639
DEBUG - 2012-11-17 19:24:03 --> Config Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:24:03 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:24:03 --> URI Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Router Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Output Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Security Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Input Class Initialized
DEBUG - 2012-11-17 19:24:03 --> XSS Filtering completed
DEBUG - 2012-11-17 19:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:24:03 --> Language Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Loader Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:24:03 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:24:03 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:24:03 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:24:03 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:24:03 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:24:03 --> Session Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:24:03 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Session routines successfully run
DEBUG - 2012-11-17 19:24:03 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Controller Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:03 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:24:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:03 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:24:03 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:24:03 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:24:03 --> Final output sent to browser
DEBUG - 2012-11-17 19:24:03 --> Total execution time: 0.0541
DEBUG - 2012-11-17 19:24:18 --> Config Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:24:18 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:24:18 --> URI Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Router Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Output Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Security Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Input Class Initialized
DEBUG - 2012-11-17 19:24:18 --> XSS Filtering completed
DEBUG - 2012-11-17 19:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:24:18 --> Language Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Loader Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:24:18 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:24:18 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:24:18 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:24:18 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:24:18 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:24:18 --> Session Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:24:18 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Session routines successfully run
DEBUG - 2012-11-17 19:24:18 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Controller Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:18 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:24:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:18 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:24:18 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:24:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:24:18 --> Final output sent to browser
DEBUG - 2012-11-17 19:24:18 --> Total execution time: 0.0654
DEBUG - 2012-11-17 19:24:39 --> Config Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:24:39 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:24:39 --> URI Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Router Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Output Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Security Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Input Class Initialized
DEBUG - 2012-11-17 19:24:39 --> XSS Filtering completed
DEBUG - 2012-11-17 19:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:24:39 --> Language Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Loader Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:24:39 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:24:39 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:24:39 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:24:39 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:24:39 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:24:39 --> Session Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:24:39 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Session routines successfully run
DEBUG - 2012-11-17 19:24:39 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Controller Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:39 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:24:39 --> Model Class Initialized
DEBUG - 2012-11-17 19:24:39 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:24:39 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:24:39 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:24:39 --> Final output sent to browser
DEBUG - 2012-11-17 19:24:39 --> Total execution time: 0.0560
DEBUG - 2012-11-17 19:25:10 --> Config Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:25:10 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:25:10 --> URI Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Router Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Output Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Security Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Input Class Initialized
DEBUG - 2012-11-17 19:25:10 --> XSS Filtering completed
DEBUG - 2012-11-17 19:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:25:10 --> Language Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Loader Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:25:10 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:25:10 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:25:10 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:25:10 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:25:10 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:25:10 --> Session Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:25:10 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Session routines successfully run
DEBUG - 2012-11-17 19:25:10 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Controller Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:25:10 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:25:10 --> Model Class Initialized
DEBUG - 2012-11-17 19:25:10 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:25:10 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:25:10 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:25:10 --> Final output sent to browser
DEBUG - 2012-11-17 19:25:10 --> Total execution time: 0.0585
DEBUG - 2012-11-17 19:30:55 --> Config Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:30:55 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:30:55 --> URI Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Router Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Output Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Security Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Input Class Initialized
DEBUG - 2012-11-17 19:30:55 --> XSS Filtering completed
DEBUG - 2012-11-17 19:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:30:55 --> Language Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Loader Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:30:55 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:30:55 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:30:55 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:30:55 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:30:55 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:30:55 --> Session Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:30:55 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Session routines successfully run
DEBUG - 2012-11-17 19:30:55 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Controller Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Model Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Model Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Model Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Model Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Model Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Model Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Model Class Initialized
DEBUG - 2012-11-17 19:30:55 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:30:55 --> Model Class Initialized
DEBUG - 2012-11-17 19:30:55 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:30:55 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:30:55 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:30:55 --> Final output sent to browser
DEBUG - 2012-11-17 19:30:55 --> Total execution time: 0.0585
DEBUG - 2012-11-17 19:32:20 --> Config Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:32:20 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:32:20 --> URI Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Router Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Output Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Security Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Input Class Initialized
DEBUG - 2012-11-17 19:32:20 --> XSS Filtering completed
DEBUG - 2012-11-17 19:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:32:20 --> Language Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Loader Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:32:20 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:32:20 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:32:20 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:32:20 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:32:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:32:20 --> Session Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:32:20 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Session routines successfully run
DEBUG - 2012-11-17 19:32:20 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Controller Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:20 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:32:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:32:20 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:32:20 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:32:20 --> Final output sent to browser
DEBUG - 2012-11-17 19:32:20 --> Total execution time: 0.0635
DEBUG - 2012-11-17 19:32:50 --> Config Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:32:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:32:50 --> URI Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Router Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Output Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Security Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Input Class Initialized
DEBUG - 2012-11-17 19:32:50 --> XSS Filtering completed
DEBUG - 2012-11-17 19:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:32:50 --> Language Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Loader Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:32:50 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:32:50 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:32:50 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:32:50 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:32:50 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:32:50 --> Session Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:32:50 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Session routines successfully run
DEBUG - 2012-11-17 19:32:50 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Controller Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:50 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:32:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:32:50 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:32:50 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:32:50 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:32:50 --> Final output sent to browser
DEBUG - 2012-11-17 19:32:50 --> Total execution time: 0.0521
DEBUG - 2012-11-17 19:33:37 --> Config Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:33:37 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:33:37 --> URI Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Router Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Output Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Security Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Input Class Initialized
DEBUG - 2012-11-17 19:33:37 --> XSS Filtering completed
DEBUG - 2012-11-17 19:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:33:37 --> Language Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Loader Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:33:37 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:33:37 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:33:37 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:33:37 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:33:37 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:33:37 --> Session Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:33:37 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Session routines successfully run
DEBUG - 2012-11-17 19:33:37 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Controller Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:33:37 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:33:37 --> Model Class Initialized
DEBUG - 2012-11-17 19:33:37 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:33:37 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:33:37 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:33:37 --> Final output sent to browser
DEBUG - 2012-11-17 19:33:37 --> Total execution time: 0.0541
DEBUG - 2012-11-17 19:35:40 --> Config Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:35:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:35:40 --> URI Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Router Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Output Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Security Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Input Class Initialized
DEBUG - 2012-11-17 19:35:40 --> XSS Filtering completed
DEBUG - 2012-11-17 19:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:35:40 --> Language Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Loader Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:35:40 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:35:40 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:35:40 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:35:40 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:35:40 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:35:40 --> Session Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:35:40 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Session routines successfully run
DEBUG - 2012-11-17 19:35:40 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Controller Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:35:40 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:35:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:35:40 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:35:40 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:35:40 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:35:40 --> Final output sent to browser
DEBUG - 2012-11-17 19:35:40 --> Total execution time: 0.0593
DEBUG - 2012-11-17 19:36:20 --> Config Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:36:20 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:36:20 --> URI Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Router Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Output Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Security Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Input Class Initialized
DEBUG - 2012-11-17 19:36:20 --> XSS Filtering completed
DEBUG - 2012-11-17 19:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:36:20 --> Language Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Loader Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:36:20 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:36:20 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:36:20 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:36:20 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:36:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:36:20 --> Session Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:36:20 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Session routines successfully run
DEBUG - 2012-11-17 19:36:20 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Controller Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:20 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:36:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:36:20 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:36:20 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:36:20 --> Final output sent to browser
DEBUG - 2012-11-17 19:36:20 --> Total execution time: 0.0654
DEBUG - 2012-11-17 19:36:41 --> Config Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:36:41 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:36:41 --> URI Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Router Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Output Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Security Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Input Class Initialized
DEBUG - 2012-11-17 19:36:41 --> XSS Filtering completed
DEBUG - 2012-11-17 19:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:36:41 --> Language Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Loader Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:36:41 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:36:41 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:36:41 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:36:41 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:36:41 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:36:41 --> Session Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:36:41 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Session routines successfully run
DEBUG - 2012-11-17 19:36:41 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Controller Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:41 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:36:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:36:41 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:36:41 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:36:41 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:36:41 --> Final output sent to browser
DEBUG - 2012-11-17 19:36:41 --> Total execution time: 0.0616
DEBUG - 2012-11-17 19:37:00 --> Config Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:37:00 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:37:00 --> URI Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Router Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Output Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Security Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Input Class Initialized
DEBUG - 2012-11-17 19:37:00 --> XSS Filtering completed
DEBUG - 2012-11-17 19:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:37:00 --> Language Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Loader Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:37:00 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:37:00 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:37:00 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:37:00 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:37:00 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:37:00 --> Session Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:37:00 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Session routines successfully run
DEBUG - 2012-11-17 19:37:00 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Controller Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:00 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:37:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:00 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:37:00 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:37:00 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:37:00 --> Final output sent to browser
DEBUG - 2012-11-17 19:37:00 --> Total execution time: 0.0634
DEBUG - 2012-11-17 19:37:33 --> Config Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:37:33 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:37:33 --> URI Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Router Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Output Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Security Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Input Class Initialized
DEBUG - 2012-11-17 19:37:33 --> XSS Filtering completed
DEBUG - 2012-11-17 19:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:37:33 --> Language Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Loader Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:37:33 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:37:33 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:37:33 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:37:33 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:37:33 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:37:33 --> Session Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:37:33 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Session routines successfully run
DEBUG - 2012-11-17 19:37:33 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Controller Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:33 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:37:33 --> Model Class Initialized
DEBUG - 2012-11-17 19:37:33 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:37:33 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:37:33 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:37:33 --> Final output sent to browser
DEBUG - 2012-11-17 19:37:33 --> Total execution time: 0.0578
DEBUG - 2012-11-17 19:38:20 --> Config Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:38:20 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:38:20 --> URI Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Router Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Output Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Security Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Input Class Initialized
DEBUG - 2012-11-17 19:38:20 --> XSS Filtering completed
DEBUG - 2012-11-17 19:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:38:20 --> Language Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Loader Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:38:20 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:38:20 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:38:20 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:38:20 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:38:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:38:20 --> Session Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:38:20 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Session routines successfully run
DEBUG - 2012-11-17 19:38:20 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Controller Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:20 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:38:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:38:20 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:38:20 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:38:20 --> Final output sent to browser
DEBUG - 2012-11-17 19:38:20 --> Total execution time: 0.0552
DEBUG - 2012-11-17 19:38:53 --> Config Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:38:53 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:38:53 --> URI Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Router Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Output Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Security Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Input Class Initialized
DEBUG - 2012-11-17 19:38:53 --> XSS Filtering completed
DEBUG - 2012-11-17 19:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:38:53 --> Language Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Loader Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:38:53 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:38:53 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:38:53 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:38:53 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:38:53 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:38:53 --> Session Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:38:53 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Session routines successfully run
DEBUG - 2012-11-17 19:38:53 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Controller Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:53 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:38:53 --> Model Class Initialized
DEBUG - 2012-11-17 19:38:53 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:38:53 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:38:53 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:38:53 --> Final output sent to browser
DEBUG - 2012-11-17 19:38:53 --> Total execution time: 0.0634
DEBUG - 2012-11-17 19:39:00 --> Config Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:39:00 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:39:00 --> URI Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Router Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Output Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Security Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Input Class Initialized
DEBUG - 2012-11-17 19:39:00 --> XSS Filtering completed
DEBUG - 2012-11-17 19:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:39:00 --> Language Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Loader Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:39:00 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:39:00 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:39:00 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:39:00 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:39:00 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:39:00 --> Session Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:39:00 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Session routines successfully run
DEBUG - 2012-11-17 19:39:00 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Controller Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:00 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:00 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:39:00 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:39:00 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:39:00 --> Final output sent to browser
DEBUG - 2012-11-17 19:39:00 --> Total execution time: 0.0393
DEBUG - 2012-11-17 19:39:03 --> Config Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:39:03 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:39:03 --> URI Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Router Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Output Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Security Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Input Class Initialized
DEBUG - 2012-11-17 19:39:03 --> XSS Filtering completed
DEBUG - 2012-11-17 19:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:39:03 --> Language Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Loader Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:39:03 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:39:03 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:39:03 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:39:03 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:39:03 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:39:03 --> Session Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:39:03 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Session routines successfully run
DEBUG - 2012-11-17 19:39:03 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Controller Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:03 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:03 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:39:03 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 19:39:03 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:39:03 --> Final output sent to browser
DEBUG - 2012-11-17 19:39:03 --> Total execution time: 0.0358
DEBUG - 2012-11-17 19:39:05 --> Config Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:39:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:39:05 --> URI Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Router Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Output Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Security Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Input Class Initialized
DEBUG - 2012-11-17 19:39:05 --> XSS Filtering completed
DEBUG - 2012-11-17 19:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:39:05 --> Language Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Loader Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:39:05 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:39:05 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:39:05 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:39:05 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:39:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:39:05 --> Session Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:39:05 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Session routines successfully run
DEBUG - 2012-11-17 19:39:05 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Controller Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:05 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:39:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:39:05 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:39:05 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:39:05 --> Final output sent to browser
DEBUG - 2012-11-17 19:39:05 --> Total execution time: 0.0585
DEBUG - 2012-11-17 19:39:07 --> Config Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:39:07 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:39:07 --> URI Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Router Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Output Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Security Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Input Class Initialized
DEBUG - 2012-11-17 19:39:07 --> XSS Filtering completed
DEBUG - 2012-11-17 19:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:39:07 --> Language Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Loader Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:39:07 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:39:07 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:39:07 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:39:07 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:39:07 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:39:07 --> Session Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:39:07 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Session routines successfully run
DEBUG - 2012-11-17 19:39:07 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Controller Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:07 --> Model Class Initialized
DEBUG - 2012-11-17 19:39:07 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:39:07 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:39:07 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:39:07 --> Final output sent to browser
DEBUG - 2012-11-17 19:39:07 --> Total execution time: 0.0345
DEBUG - 2012-11-17 19:41:31 --> Config Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:41:31 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:41:31 --> URI Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Router Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Output Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Security Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Input Class Initialized
DEBUG - 2012-11-17 19:41:31 --> XSS Filtering completed
DEBUG - 2012-11-17 19:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:41:31 --> Language Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Loader Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:41:31 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:41:31 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:41:31 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:41:31 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:41:31 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:41:31 --> Session Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:41:31 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Session routines successfully run
DEBUG - 2012-11-17 19:41:31 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:41:31 --> Controller Class Initialized
DEBUG - 2012-11-17 19:41:31 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:41:31 --> File loaded: application/views/content/about_view.php
DEBUG - 2012-11-17 19:41:31 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:41:31 --> Final output sent to browser
DEBUG - 2012-11-17 19:41:31 --> Total execution time: 0.0362
DEBUG - 2012-11-17 19:43:56 --> Config Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:43:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:43:56 --> URI Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Router Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Output Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Security Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Input Class Initialized
DEBUG - 2012-11-17 19:43:56 --> XSS Filtering completed
DEBUG - 2012-11-17 19:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:43:56 --> Language Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Loader Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:43:56 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:43:56 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:43:56 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:43:56 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:43:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:43:56 --> Session Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:43:56 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Session routines successfully run
DEBUG - 2012-11-17 19:43:56 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Controller Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:43:56 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:43:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:43:56 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:43:56 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:43:56 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:43:56 --> Final output sent to browser
DEBUG - 2012-11-17 19:43:56 --> Total execution time: 0.0524
DEBUG - 2012-11-17 19:44:31 --> Config Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:44:31 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:44:31 --> URI Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Router Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Output Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Security Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Input Class Initialized
DEBUG - 2012-11-17 19:44:31 --> XSS Filtering completed
DEBUG - 2012-11-17 19:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:44:31 --> Language Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Loader Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:44:31 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:44:31 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:44:31 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:44:31 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:44:31 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:44:31 --> Session Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:44:31 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Session routines successfully run
DEBUG - 2012-11-17 19:44:31 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Controller Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:31 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:44:31 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:31 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:44:31 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:44:31 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:44:31 --> Final output sent to browser
DEBUG - 2012-11-17 19:44:31 --> Total execution time: 0.0716
DEBUG - 2012-11-17 19:44:50 --> Config Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:44:50 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:44:50 --> URI Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Router Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Output Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Security Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Input Class Initialized
DEBUG - 2012-11-17 19:44:50 --> XSS Filtering completed
DEBUG - 2012-11-17 19:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:44:50 --> Language Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Loader Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:44:50 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:44:50 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:44:50 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:44:50 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:44:50 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:44:50 --> Session Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:44:50 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Session routines successfully run
DEBUG - 2012-11-17 19:44:50 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Controller Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:50 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:44:50 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:50 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:44:50 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:44:50 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:44:50 --> Final output sent to browser
DEBUG - 2012-11-17 19:44:50 --> Total execution time: 0.0571
DEBUG - 2012-11-17 19:44:56 --> Config Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:44:56 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:44:56 --> URI Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Router Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Output Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Security Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Input Class Initialized
DEBUG - 2012-11-17 19:44:56 --> XSS Filtering completed
DEBUG - 2012-11-17 19:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:44:56 --> Language Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Loader Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:44:56 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:44:56 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:44:56 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:44:56 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:44:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:44:56 --> Session Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:44:56 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Session routines successfully run
DEBUG - 2012-11-17 19:44:56 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Controller Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:56 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:44:56 --> Model Class Initialized
DEBUG - 2012-11-17 19:44:56 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:44:56 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:44:56 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:44:56 --> Final output sent to browser
DEBUG - 2012-11-17 19:44:56 --> Total execution time: 0.0622
DEBUG - 2012-11-17 19:45:16 --> Config Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:45:16 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:45:16 --> URI Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Router Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Output Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Security Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Input Class Initialized
DEBUG - 2012-11-17 19:45:16 --> XSS Filtering completed
DEBUG - 2012-11-17 19:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:45:16 --> Language Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Loader Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:45:16 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:45:16 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:45:16 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:45:16 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:45:16 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:45:16 --> Session Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:45:16 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Session routines successfully run
DEBUG - 2012-11-17 19:45:16 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Controller Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:16 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:45:16 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:45:16 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:45:16 --> Final output sent to browser
DEBUG - 2012-11-17 19:45:16 --> Total execution time: 0.0365
DEBUG - 2012-11-17 19:45:20 --> Config Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:45:20 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:45:20 --> URI Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Router Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Output Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Security Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Input Class Initialized
DEBUG - 2012-11-17 19:45:20 --> XSS Filtering completed
DEBUG - 2012-11-17 19:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:45:20 --> Language Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Loader Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:45:20 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:45:20 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:45:20 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:45:20 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:45:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:45:20 --> Session Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:45:20 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Session routines successfully run
DEBUG - 2012-11-17 19:45:20 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Controller Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:20 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:45:20 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 19:45:20 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:45:20 --> Final output sent to browser
DEBUG - 2012-11-17 19:45:20 --> Total execution time: 0.0340
DEBUG - 2012-11-17 19:45:32 --> Config Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:45:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:45:32 --> URI Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Router Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Output Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Security Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Input Class Initialized
DEBUG - 2012-11-17 19:45:32 --> XSS Filtering completed
DEBUG - 2012-11-17 19:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:45:32 --> Language Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Loader Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:45:32 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:45:32 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:45:32 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:45:32 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:45:32 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:45:32 --> Session Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:45:32 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Session routines successfully run
DEBUG - 2012-11-17 19:45:32 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Controller Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:32 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:45:32 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:45:32 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:45:32 --> Final output sent to browser
DEBUG - 2012-11-17 19:45:32 --> Total execution time: 0.0378
DEBUG - 2012-11-17 19:45:41 --> Config Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:45:41 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:45:41 --> URI Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Router Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Output Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Security Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Input Class Initialized
DEBUG - 2012-11-17 19:45:41 --> XSS Filtering completed
DEBUG - 2012-11-17 19:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:45:41 --> Language Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Loader Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:45:41 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:45:41 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:45:41 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:45:41 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:45:41 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:45:41 --> Session Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:45:41 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Session routines successfully run
DEBUG - 2012-11-17 19:45:41 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Controller Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:41 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:45:41 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:41 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:45:41 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:45:41 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:45:41 --> Final output sent to browser
DEBUG - 2012-11-17 19:45:41 --> Total execution time: 0.0569
DEBUG - 2012-11-17 19:45:58 --> Config Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:45:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:45:58 --> URI Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Router Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Output Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Security Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Input Class Initialized
DEBUG - 2012-11-17 19:45:58 --> XSS Filtering completed
DEBUG - 2012-11-17 19:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:45:58 --> Language Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Loader Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:45:58 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:45:58 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:45:58 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:45:58 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:45:58 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:45:58 --> Session Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:45:58 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Session routines successfully run
DEBUG - 2012-11-17 19:45:58 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Controller Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:58 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:45:58 --> Model Class Initialized
DEBUG - 2012-11-17 19:45:58 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:45:58 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:45:58 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:45:58 --> Final output sent to browser
DEBUG - 2012-11-17 19:45:58 --> Total execution time: 0.0612
DEBUG - 2012-11-17 19:46:04 --> Config Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:46:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:46:04 --> URI Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Router Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Output Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Security Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Input Class Initialized
DEBUG - 2012-11-17 19:46:04 --> XSS Filtering completed
DEBUG - 2012-11-17 19:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:46:04 --> Language Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Loader Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:46:04 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:46:04 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:46:04 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:46:04 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:46:04 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:46:04 --> Session Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:46:04 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Session routines successfully run
DEBUG - 2012-11-17 19:46:04 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Controller Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Model Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Model Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Model Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Model Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Model Class Initialized
DEBUG - 2012-11-17 19:46:04 --> Model Class Initialized
DEBUG - 2012-11-17 19:46:04 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:46:04 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:46:04 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:46:04 --> Final output sent to browser
DEBUG - 2012-11-17 19:46:04 --> Total execution time: 0.0374
DEBUG - 2012-11-17 19:51:32 --> Config Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:51:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:51:32 --> URI Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Router Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Output Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Security Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Input Class Initialized
DEBUG - 2012-11-17 19:51:32 --> XSS Filtering completed
DEBUG - 2012-11-17 19:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:51:32 --> Language Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Loader Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:51:32 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:51:32 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:51:32 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:51:32 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:51:32 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:51:32 --> Session Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:51:32 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Session routines successfully run
DEBUG - 2012-11-17 19:51:32 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Controller Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:32 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:32 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:51:32 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 19:51:32 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:51:32 --> Final output sent to browser
DEBUG - 2012-11-17 19:51:32 --> Total execution time: 0.0368
DEBUG - 2012-11-17 19:51:36 --> Config Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:51:36 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:51:36 --> URI Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Router Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Output Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Security Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Input Class Initialized
DEBUG - 2012-11-17 19:51:36 --> XSS Filtering completed
DEBUG - 2012-11-17 19:51:36 --> XSS Filtering completed
DEBUG - 2012-11-17 19:51:36 --> XSS Filtering completed
DEBUG - 2012-11-17 19:51:36 --> XSS Filtering completed
DEBUG - 2012-11-17 19:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:51:36 --> Language Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Loader Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:51:36 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:51:36 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:51:36 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:51:36 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:51:36 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:51:36 --> Session Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:51:36 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Session routines successfully run
DEBUG - 2012-11-17 19:51:36 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Controller Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:51:36 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:36 --> Model Class Initialized
DEBUG - 2012-11-17 19:51:36 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:51:36 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 19:51:36 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:51:43 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:51:49 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 19:51:49 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:51:49 --> Final output sent to browser
DEBUG - 2012-11-17 19:51:49 --> Total execution time: 12.7512
DEBUG - 2012-11-17 19:53:40 --> Config Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:53:40 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:53:40 --> URI Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Router Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Output Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Security Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Input Class Initialized
DEBUG - 2012-11-17 19:53:40 --> XSS Filtering completed
DEBUG - 2012-11-17 19:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:53:40 --> Language Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Loader Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:53:40 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:53:40 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:53:40 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:53:40 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:53:40 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:53:40 --> Session Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:53:40 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Session routines successfully run
DEBUG - 2012-11-17 19:53:40 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Controller Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:53:40 --> Model Class Initialized
DEBUG - 2012-11-17 19:53:40 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:53:40 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:53:40 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:53:40 --> Final output sent to browser
DEBUG - 2012-11-17 19:53:40 --> Total execution time: 0.0323
DEBUG - 2012-11-17 19:54:16 --> Config Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:54:16 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:54:16 --> URI Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Router Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Output Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Security Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Input Class Initialized
DEBUG - 2012-11-17 19:54:16 --> XSS Filtering completed
DEBUG - 2012-11-17 19:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:54:16 --> Language Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Loader Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:54:16 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:54:16 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:54:16 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:54:16 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:54:16 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:54:16 --> Session Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:54:16 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Session routines successfully run
DEBUG - 2012-11-17 19:54:16 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Controller Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:16 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:16 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:54:16 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:54:16 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:54:16 --> Final output sent to browser
DEBUG - 2012-11-17 19:54:16 --> Total execution time: 0.0343
DEBUG - 2012-11-17 19:54:19 --> Config Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:54:19 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:54:19 --> URI Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Router Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Output Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Security Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Input Class Initialized
DEBUG - 2012-11-17 19:54:19 --> XSS Filtering completed
DEBUG - 2012-11-17 19:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:54:19 --> Language Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Loader Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:54:19 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:54:19 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:54:19 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:54:19 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:54:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:54:19 --> Session Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:54:19 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Session routines successfully run
DEBUG - 2012-11-17 19:54:19 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Controller Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:19 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:54:19 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:54:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:54:19 --> Final output sent to browser
DEBUG - 2012-11-17 19:54:19 --> Total execution time: 0.0330
DEBUG - 2012-11-17 19:54:25 --> Config Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:54:25 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:54:25 --> URI Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Router Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Output Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Security Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Input Class Initialized
DEBUG - 2012-11-17 19:54:25 --> XSS Filtering completed
DEBUG - 2012-11-17 19:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:54:25 --> Language Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Loader Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:54:25 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:54:25 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:54:25 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:54:25 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:54:25 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:54:25 --> Session Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:54:25 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Session routines successfully run
DEBUG - 2012-11-17 19:54:25 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Controller Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:25 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:25 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:54:25 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2012-11-17 19:54:25 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:54:25 --> Final output sent to browser
DEBUG - 2012-11-17 19:54:25 --> Total execution time: 0.0362
DEBUG - 2012-11-17 19:54:30 --> Config Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:54:30 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:54:30 --> URI Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Router Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Output Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Security Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Input Class Initialized
DEBUG - 2012-11-17 19:54:30 --> XSS Filtering completed
DEBUG - 2012-11-17 19:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:54:30 --> Language Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Loader Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:54:30 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:54:30 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:54:30 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:54:30 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:54:30 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:54:30 --> Session Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:54:30 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Session routines successfully run
DEBUG - 2012-11-17 19:54:30 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Controller Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:30 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:54:30 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:30 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:54:30 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:54:30 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:54:30 --> Final output sent to browser
DEBUG - 2012-11-17 19:54:30 --> Total execution time: 0.0561
DEBUG - 2012-11-17 19:54:35 --> Config Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:54:35 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:54:35 --> URI Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Router Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Output Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Security Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Input Class Initialized
DEBUG - 2012-11-17 19:54:35 --> XSS Filtering completed
DEBUG - 2012-11-17 19:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:54:35 --> Language Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Loader Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:54:35 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:54:35 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:54:35 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:54:35 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:54:35 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:54:35 --> Session Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:54:35 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Session routines successfully run
DEBUG - 2012-11-17 19:54:35 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Controller Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:35 --> Model Class Initialized
DEBUG - 2012-11-17 19:54:35 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:54:35 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 19:54:35 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:54:35 --> Final output sent to browser
DEBUG - 2012-11-17 19:54:35 --> Total execution time: 0.0402
DEBUG - 2012-11-17 19:55:57 --> Config Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:55:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:55:57 --> URI Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Router Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Output Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Security Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Input Class Initialized
DEBUG - 2012-11-17 19:55:57 --> XSS Filtering completed
DEBUG - 2012-11-17 19:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:55:57 --> Language Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Loader Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:55:57 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:55:57 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:55:57 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:55:57 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:55:57 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:55:57 --> Session Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:55:57 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Session routines successfully run
DEBUG - 2012-11-17 19:55:57 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Controller Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Model Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Model Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Model Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Model Class Initialized
DEBUG - 2012-11-17 19:55:57 --> Model Class Initialized
DEBUG - 2012-11-17 19:55:57 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:55:57 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 19:55:57 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:55:57 --> Final output sent to browser
DEBUG - 2012-11-17 19:55:57 --> Total execution time: 0.0387
DEBUG - 2012-11-17 19:55:59 --> Config Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:55:59 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:55:59 --> URI Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Router Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Output Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Security Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Input Class Initialized
DEBUG - 2012-11-17 19:55:59 --> XSS Filtering completed
DEBUG - 2012-11-17 19:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:55:59 --> Language Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Loader Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:55:59 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:55:59 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:55:59 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:55:59 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:55:59 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:55:59 --> Session Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:55:59 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Session routines successfully run
DEBUG - 2012-11-17 19:55:59 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Controller Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:55:59 --> Model Class Initialized
DEBUG - 2012-11-17 19:55:59 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:55:59 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 19:55:59 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:55:59 --> Final output sent to browser
DEBUG - 2012-11-17 19:55:59 --> Total execution time: 0.0342
DEBUG - 2012-11-17 19:56:01 --> Config Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:56:01 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:56:01 --> URI Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Router Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Output Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Security Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Input Class Initialized
DEBUG - 2012-11-17 19:56:01 --> XSS Filtering completed
DEBUG - 2012-11-17 19:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:56:01 --> Language Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Loader Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:56:01 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:56:01 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:56:01 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:56:01 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:56:01 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:56:01 --> Session Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:56:01 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Session routines successfully run
DEBUG - 2012-11-17 19:56:01 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Controller Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:01 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:56:01 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:01 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:56:01 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-17 19:56:01 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:56:01 --> Final output sent to browser
DEBUG - 2012-11-17 19:56:01 --> Total execution time: 0.0662
DEBUG - 2012-11-17 19:56:02 --> Config Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:56:02 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:56:02 --> URI Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Router Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Output Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Security Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Input Class Initialized
DEBUG - 2012-11-17 19:56:02 --> XSS Filtering completed
DEBUG - 2012-11-17 19:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:56:02 --> Language Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Loader Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:56:02 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:56:02 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:56:02 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:56:02 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:56:02 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:56:02 --> Session Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:56:02 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Session routines successfully run
DEBUG - 2012-11-17 19:56:02 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Controller Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:02 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:02 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:56:02 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 19:56:02 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:56:02 --> Final output sent to browser
DEBUG - 2012-11-17 19:56:02 --> Total execution time: 0.0369
DEBUG - 2012-11-17 19:56:18 --> Config Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:56:18 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:56:18 --> URI Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Router Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Output Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Security Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Input Class Initialized
DEBUG - 2012-11-17 19:56:18 --> XSS Filtering completed
DEBUG - 2012-11-17 19:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:56:18 --> Language Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Loader Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:56:18 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:56:18 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:56:18 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:56:18 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:56:18 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:56:18 --> Session Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:56:18 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Session routines successfully run
DEBUG - 2012-11-17 19:56:18 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Controller Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:18 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:18 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:56:18 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-17 19:56:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:56:18 --> Final output sent to browser
DEBUG - 2012-11-17 19:56:18 --> Total execution time: 0.0377
DEBUG - 2012-11-17 19:56:24 --> Config Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:56:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:56:24 --> URI Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Router Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Output Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Security Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Input Class Initialized
DEBUG - 2012-11-17 19:56:24 --> XSS Filtering completed
DEBUG - 2012-11-17 19:56:24 --> XSS Filtering completed
DEBUG - 2012-11-17 19:56:24 --> XSS Filtering completed
DEBUG - 2012-11-17 19:56:24 --> XSS Filtering completed
DEBUG - 2012-11-17 19:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:56:24 --> Language Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Loader Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:56:24 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:56:24 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:56:24 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:56:24 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:56:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:56:24 --> Session Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:56:24 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Session routines successfully run
DEBUG - 2012-11-17 19:56:24 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Controller Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:56:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:24 --> Model Class Initialized
DEBUG - 2012-11-17 19:56:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:56:24 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 19:56:24 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:56:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:56:37 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 19:56:37 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:56:37 --> Final output sent to browser
DEBUG - 2012-11-17 19:56:37 --> Total execution time: 12.7108
DEBUG - 2012-11-17 19:58:05 --> Config Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Hooks Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Utf8 Class Initialized
DEBUG - 2012-11-17 19:58:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 19:58:05 --> URI Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Router Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Output Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Security Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Input Class Initialized
DEBUG - 2012-11-17 19:58:05 --> XSS Filtering completed
DEBUG - 2012-11-17 19:58:05 --> XSS Filtering completed
DEBUG - 2012-11-17 19:58:05 --> XSS Filtering completed
DEBUG - 2012-11-17 19:58:05 --> XSS Filtering completed
DEBUG - 2012-11-17 19:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 19:58:05 --> Language Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Loader Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Helper loaded: date_helper
DEBUG - 2012-11-17 19:58:05 --> Helper loaded: form_helper
DEBUG - 2012-11-17 19:58:05 --> Helper loaded: language_helper
DEBUG - 2012-11-17 19:58:05 --> Helper loaded: url_helper
DEBUG - 2012-11-17 19:58:05 --> Helper loaded: html_helper
DEBUG - 2012-11-17 19:58:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 19:58:05 --> Session Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Helper loaded: string_helper
DEBUG - 2012-11-17 19:58:05 --> Encrypt Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Session routines successfully run
DEBUG - 2012-11-17 19:58:05 --> Form Validation Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Controller Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Helper loaded: file_helper
DEBUG - 2012-11-17 19:58:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:58:05 --> Model Class Initialized
DEBUG - 2012-11-17 19:58:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 19:58:05 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 19:58:05 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:58:12 --> Database Driver Class Initialized
DEBUG - 2012-11-17 19:58:18 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 19:58:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 19:58:18 --> Final output sent to browser
DEBUG - 2012-11-17 19:58:18 --> Total execution time: 12.7614
DEBUG - 2012-11-17 20:07:12 --> Config Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Hooks Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Utf8 Class Initialized
DEBUG - 2012-11-17 20:07:12 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 20:07:12 --> URI Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Router Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Output Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Security Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Input Class Initialized
DEBUG - 2012-11-17 20:07:12 --> XSS Filtering completed
DEBUG - 2012-11-17 20:07:12 --> XSS Filtering completed
DEBUG - 2012-11-17 20:07:12 --> XSS Filtering completed
DEBUG - 2012-11-17 20:07:12 --> XSS Filtering completed
DEBUG - 2012-11-17 20:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 20:07:12 --> Language Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Loader Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Helper loaded: date_helper
DEBUG - 2012-11-17 20:07:12 --> Helper loaded: form_helper
DEBUG - 2012-11-17 20:07:12 --> Helper loaded: language_helper
DEBUG - 2012-11-17 20:07:12 --> Helper loaded: url_helper
DEBUG - 2012-11-17 20:07:12 --> Helper loaded: html_helper
DEBUG - 2012-11-17 20:07:12 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 20:07:12 --> Session Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Helper loaded: string_helper
DEBUG - 2012-11-17 20:07:12 --> Encrypt Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Session routines successfully run
DEBUG - 2012-11-17 20:07:12 --> Form Validation Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Controller Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Model Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Model Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Model Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Model Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Model Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Model Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Helper loaded: file_helper
DEBUG - 2012-11-17 20:07:12 --> Model Class Initialized
DEBUG - 2012-11-17 20:07:12 --> Model Class Initialized
DEBUG - 2012-11-17 20:07:12 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 20:07:12 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 20:07:12 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:07:18 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:07:24 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 20:07:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 20:07:24 --> Final output sent to browser
DEBUG - 2012-11-17 20:07:24 --> Total execution time: 12.6822
DEBUG - 2012-11-17 20:12:49 --> Config Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Hooks Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Utf8 Class Initialized
DEBUG - 2012-11-17 20:12:49 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 20:12:49 --> URI Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Router Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Output Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Security Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Input Class Initialized
DEBUG - 2012-11-17 20:12:49 --> XSS Filtering completed
DEBUG - 2012-11-17 20:12:49 --> XSS Filtering completed
DEBUG - 2012-11-17 20:12:49 --> XSS Filtering completed
DEBUG - 2012-11-17 20:12:49 --> XSS Filtering completed
DEBUG - 2012-11-17 20:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 20:12:49 --> Language Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Loader Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Helper loaded: date_helper
DEBUG - 2012-11-17 20:12:49 --> Helper loaded: form_helper
DEBUG - 2012-11-17 20:12:49 --> Helper loaded: language_helper
DEBUG - 2012-11-17 20:12:49 --> Helper loaded: url_helper
DEBUG - 2012-11-17 20:12:49 --> Helper loaded: html_helper
DEBUG - 2012-11-17 20:12:49 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 20:12:49 --> Session Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Helper loaded: string_helper
DEBUG - 2012-11-17 20:12:49 --> Encrypt Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Session routines successfully run
DEBUG - 2012-11-17 20:12:49 --> Form Validation Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Controller Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Model Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Model Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Model Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Model Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Model Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Model Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Helper loaded: file_helper
DEBUG - 2012-11-17 20:12:49 --> Model Class Initialized
DEBUG - 2012-11-17 20:12:49 --> Model Class Initialized
DEBUG - 2012-11-17 20:12:49 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 20:12:49 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 20:12:49 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:12:56 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:13:02 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 20:13:02 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 20:13:02 --> Final output sent to browser
DEBUG - 2012-11-17 20:13:02 --> Total execution time: 12.6776
DEBUG - 2012-11-17 20:14:10 --> Config Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Hooks Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Utf8 Class Initialized
DEBUG - 2012-11-17 20:14:10 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 20:14:10 --> URI Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Router Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Output Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Security Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Input Class Initialized
DEBUG - 2012-11-17 20:14:10 --> XSS Filtering completed
DEBUG - 2012-11-17 20:14:10 --> XSS Filtering completed
DEBUG - 2012-11-17 20:14:10 --> XSS Filtering completed
DEBUG - 2012-11-17 20:14:10 --> XSS Filtering completed
DEBUG - 2012-11-17 20:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 20:14:10 --> Language Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Loader Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Helper loaded: date_helper
DEBUG - 2012-11-17 20:14:10 --> Helper loaded: form_helper
DEBUG - 2012-11-17 20:14:10 --> Helper loaded: language_helper
DEBUG - 2012-11-17 20:14:10 --> Helper loaded: url_helper
DEBUG - 2012-11-17 20:14:10 --> Helper loaded: html_helper
DEBUG - 2012-11-17 20:14:10 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 20:14:10 --> Session Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Helper loaded: string_helper
DEBUG - 2012-11-17 20:14:10 --> Encrypt Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Session routines successfully run
DEBUG - 2012-11-17 20:14:10 --> Form Validation Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Controller Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Model Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Model Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Model Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Model Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Model Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Model Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Helper loaded: file_helper
DEBUG - 2012-11-17 20:14:10 --> Model Class Initialized
DEBUG - 2012-11-17 20:14:10 --> Model Class Initialized
DEBUG - 2012-11-17 20:14:10 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 20:14:10 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 20:14:10 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:14:17 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:14:23 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 20:14:23 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 20:14:23 --> Final output sent to browser
DEBUG - 2012-11-17 20:14:23 --> Total execution time: 12.8094
DEBUG - 2012-11-17 20:15:28 --> Config Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Hooks Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Utf8 Class Initialized
DEBUG - 2012-11-17 20:15:28 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 20:15:28 --> URI Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Router Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Output Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Security Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Input Class Initialized
DEBUG - 2012-11-17 20:15:28 --> XSS Filtering completed
DEBUG - 2012-11-17 20:15:28 --> XSS Filtering completed
DEBUG - 2012-11-17 20:15:28 --> XSS Filtering completed
DEBUG - 2012-11-17 20:15:28 --> XSS Filtering completed
DEBUG - 2012-11-17 20:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 20:15:28 --> Language Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Loader Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Helper loaded: date_helper
DEBUG - 2012-11-17 20:15:28 --> Helper loaded: form_helper
DEBUG - 2012-11-17 20:15:28 --> Helper loaded: language_helper
DEBUG - 2012-11-17 20:15:28 --> Helper loaded: url_helper
DEBUG - 2012-11-17 20:15:28 --> Helper loaded: html_helper
DEBUG - 2012-11-17 20:15:28 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 20:15:28 --> Session Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Helper loaded: string_helper
DEBUG - 2012-11-17 20:15:28 --> Encrypt Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Session routines successfully run
DEBUG - 2012-11-17 20:15:28 --> Form Validation Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Controller Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Model Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Model Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Model Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Model Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Model Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Model Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Helper loaded: file_helper
DEBUG - 2012-11-17 20:15:28 --> Model Class Initialized
DEBUG - 2012-11-17 20:15:28 --> Model Class Initialized
DEBUG - 2012-11-17 20:15:28 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 20:15:28 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 20:15:28 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:15:35 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:15:41 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 20:15:41 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 20:15:41 --> Final output sent to browser
DEBUG - 2012-11-17 20:15:41 --> Total execution time: 12.7167
DEBUG - 2012-11-17 20:17:31 --> Config Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Hooks Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Utf8 Class Initialized
DEBUG - 2012-11-17 20:17:31 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 20:17:31 --> URI Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Router Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Output Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Security Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Input Class Initialized
DEBUG - 2012-11-17 20:17:31 --> XSS Filtering completed
DEBUG - 2012-11-17 20:17:31 --> XSS Filtering completed
DEBUG - 2012-11-17 20:17:31 --> XSS Filtering completed
DEBUG - 2012-11-17 20:17:31 --> XSS Filtering completed
DEBUG - 2012-11-17 20:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 20:17:31 --> Language Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Loader Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Helper loaded: date_helper
DEBUG - 2012-11-17 20:17:31 --> Helper loaded: form_helper
DEBUG - 2012-11-17 20:17:31 --> Helper loaded: language_helper
DEBUG - 2012-11-17 20:17:31 --> Helper loaded: url_helper
DEBUG - 2012-11-17 20:17:31 --> Helper loaded: html_helper
DEBUG - 2012-11-17 20:17:31 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 20:17:31 --> Session Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Helper loaded: string_helper
DEBUG - 2012-11-17 20:17:31 --> Encrypt Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Session routines successfully run
DEBUG - 2012-11-17 20:17:31 --> Form Validation Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Controller Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Model Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Model Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Model Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Model Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Model Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Model Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Helper loaded: file_helper
DEBUG - 2012-11-17 20:17:31 --> Model Class Initialized
DEBUG - 2012-11-17 20:17:31 --> Model Class Initialized
DEBUG - 2012-11-17 20:17:31 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 20:17:31 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 20:17:31 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:17:38 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:17:44 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 20:17:44 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 20:17:44 --> Final output sent to browser
DEBUG - 2012-11-17 20:17:44 --> Total execution time: 12.7667
DEBUG - 2012-11-17 20:20:13 --> Config Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Hooks Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Utf8 Class Initialized
DEBUG - 2012-11-17 20:20:13 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 20:20:13 --> URI Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Router Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Output Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Security Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Input Class Initialized
DEBUG - 2012-11-17 20:20:13 --> XSS Filtering completed
DEBUG - 2012-11-17 20:20:13 --> XSS Filtering completed
DEBUG - 2012-11-17 20:20:13 --> XSS Filtering completed
DEBUG - 2012-11-17 20:20:13 --> XSS Filtering completed
DEBUG - 2012-11-17 20:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 20:20:13 --> Language Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Loader Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Helper loaded: date_helper
DEBUG - 2012-11-17 20:20:13 --> Helper loaded: form_helper
DEBUG - 2012-11-17 20:20:13 --> Helper loaded: language_helper
DEBUG - 2012-11-17 20:20:13 --> Helper loaded: url_helper
DEBUG - 2012-11-17 20:20:13 --> Helper loaded: html_helper
DEBUG - 2012-11-17 20:20:13 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 20:20:13 --> Session Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Helper loaded: string_helper
DEBUG - 2012-11-17 20:20:13 --> Encrypt Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Session routines successfully run
DEBUG - 2012-11-17 20:20:13 --> Form Validation Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Controller Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Model Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Model Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Model Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Model Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Model Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Model Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Helper loaded: file_helper
DEBUG - 2012-11-17 20:20:13 --> Model Class Initialized
DEBUG - 2012-11-17 20:20:13 --> Model Class Initialized
DEBUG - 2012-11-17 20:20:13 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 20:20:13 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 20:20:13 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:20:20 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:20:26 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 20:20:26 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 20:20:26 --> Final output sent to browser
DEBUG - 2012-11-17 20:20:26 --> Total execution time: 13.0820
DEBUG - 2012-11-17 20:35:58 --> Config Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Hooks Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Utf8 Class Initialized
DEBUG - 2012-11-17 20:35:58 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 20:35:58 --> URI Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Router Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Output Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Security Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Input Class Initialized
DEBUG - 2012-11-17 20:35:58 --> XSS Filtering completed
DEBUG - 2012-11-17 20:35:58 --> XSS Filtering completed
DEBUG - 2012-11-17 20:35:58 --> XSS Filtering completed
DEBUG - 2012-11-17 20:35:58 --> XSS Filtering completed
DEBUG - 2012-11-17 20:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 20:35:58 --> Language Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Loader Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Helper loaded: date_helper
DEBUG - 2012-11-17 20:35:58 --> Helper loaded: form_helper
DEBUG - 2012-11-17 20:35:58 --> Helper loaded: language_helper
DEBUG - 2012-11-17 20:35:58 --> Helper loaded: url_helper
DEBUG - 2012-11-17 20:35:58 --> Helper loaded: html_helper
DEBUG - 2012-11-17 20:35:58 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 20:35:58 --> Session Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Helper loaded: string_helper
DEBUG - 2012-11-17 20:35:58 --> Encrypt Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Session routines successfully run
DEBUG - 2012-11-17 20:35:58 --> Form Validation Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Controller Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Model Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Model Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Model Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Model Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Model Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Model Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Helper loaded: file_helper
DEBUG - 2012-11-17 20:35:58 --> Model Class Initialized
DEBUG - 2012-11-17 20:35:58 --> Model Class Initialized
DEBUG - 2012-11-17 20:35:58 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 20:35:58 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 20:35:58 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:36:05 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:36:11 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 20:36:11 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 20:36:11 --> Final output sent to browser
DEBUG - 2012-11-17 20:36:11 --> Total execution time: 12.8886
DEBUG - 2012-11-17 20:36:39 --> Config Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Hooks Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Utf8 Class Initialized
DEBUG - 2012-11-17 20:36:39 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 20:36:39 --> URI Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Router Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Output Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Security Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Input Class Initialized
DEBUG - 2012-11-17 20:36:39 --> XSS Filtering completed
DEBUG - 2012-11-17 20:36:39 --> XSS Filtering completed
DEBUG - 2012-11-17 20:36:39 --> XSS Filtering completed
DEBUG - 2012-11-17 20:36:39 --> XSS Filtering completed
DEBUG - 2012-11-17 20:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 20:36:39 --> Language Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Loader Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Helper loaded: date_helper
DEBUG - 2012-11-17 20:36:39 --> Helper loaded: form_helper
DEBUG - 2012-11-17 20:36:39 --> Helper loaded: language_helper
DEBUG - 2012-11-17 20:36:39 --> Helper loaded: url_helper
DEBUG - 2012-11-17 20:36:39 --> Helper loaded: html_helper
DEBUG - 2012-11-17 20:36:39 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 20:36:39 --> Session Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Helper loaded: string_helper
DEBUG - 2012-11-17 20:36:39 --> Encrypt Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Session routines successfully run
DEBUG - 2012-11-17 20:36:39 --> Form Validation Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Controller Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Model Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Model Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Model Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Model Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Model Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Model Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Helper loaded: file_helper
DEBUG - 2012-11-17 20:36:39 --> Model Class Initialized
DEBUG - 2012-11-17 20:36:39 --> Model Class Initialized
DEBUG - 2012-11-17 20:36:39 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 20:36:39 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 20:36:39 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:36:46 --> Database Driver Class Initialized
DEBUG - 2012-11-17 20:36:52 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 20:36:52 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 20:36:52 --> Final output sent to browser
DEBUG - 2012-11-17 20:36:52 --> Total execution time: 12.8242
DEBUG - 2012-11-17 22:11:14 --> Config Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Hooks Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Utf8 Class Initialized
DEBUG - 2012-11-17 22:11:14 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 22:11:14 --> URI Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Router Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Output Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Security Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Input Class Initialized
DEBUG - 2012-11-17 22:11:14 --> XSS Filtering completed
DEBUG - 2012-11-17 22:11:14 --> XSS Filtering completed
DEBUG - 2012-11-17 22:11:14 --> XSS Filtering completed
DEBUG - 2012-11-17 22:11:14 --> XSS Filtering completed
DEBUG - 2012-11-17 22:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 22:11:14 --> Language Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Loader Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Helper loaded: date_helper
DEBUG - 2012-11-17 22:11:14 --> Helper loaded: form_helper
DEBUG - 2012-11-17 22:11:14 --> Helper loaded: language_helper
DEBUG - 2012-11-17 22:11:14 --> Helper loaded: url_helper
DEBUG - 2012-11-17 22:11:14 --> Helper loaded: html_helper
DEBUG - 2012-11-17 22:11:14 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 22:11:14 --> Session Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Helper loaded: string_helper
DEBUG - 2012-11-17 22:11:14 --> Encrypt Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Session routines successfully run
DEBUG - 2012-11-17 22:11:14 --> Form Validation Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Controller Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Helper loaded: file_helper
DEBUG - 2012-11-17 22:11:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:11:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:11:14 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 22:11:14 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 22:11:14 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:11:20 --> Database Driver Class Initialized
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:11:27 --> Could not find the language line "voc.i18n_activity_hours"
ERROR - 2012-11-17 22:11:27 --> Could not find the language line "voc.i18n_activity_wday"
DEBUG - 2012-11-17 22:11:27 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 22:11:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 22:11:27 --> Final output sent to browser
DEBUG - 2012-11-17 22:11:27 --> Total execution time: 12.9030
DEBUG - 2012-11-17 22:13:15 --> Config Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Hooks Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Utf8 Class Initialized
DEBUG - 2012-11-17 22:13:15 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 22:13:15 --> URI Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Router Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Output Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Security Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Input Class Initialized
DEBUG - 2012-11-17 22:13:15 --> XSS Filtering completed
DEBUG - 2012-11-17 22:13:15 --> XSS Filtering completed
DEBUG - 2012-11-17 22:13:15 --> XSS Filtering completed
DEBUG - 2012-11-17 22:13:15 --> XSS Filtering completed
DEBUG - 2012-11-17 22:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 22:13:15 --> Language Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Loader Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Helper loaded: date_helper
DEBUG - 2012-11-17 22:13:15 --> Helper loaded: form_helper
DEBUG - 2012-11-17 22:13:15 --> Helper loaded: language_helper
DEBUG - 2012-11-17 22:13:15 --> Helper loaded: url_helper
DEBUG - 2012-11-17 22:13:15 --> Helper loaded: html_helper
DEBUG - 2012-11-17 22:13:15 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 22:13:15 --> Session Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Helper loaded: string_helper
DEBUG - 2012-11-17 22:13:15 --> Encrypt Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Session routines successfully run
DEBUG - 2012-11-17 22:13:15 --> Form Validation Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Controller Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Helper loaded: file_helper
DEBUG - 2012-11-17 22:13:15 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:15 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:15 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 22:13:15 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 22:13:15 --> Database Driver Class Initialized
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 14 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 1 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 316
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 15 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 317
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined index: 04 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 318
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 2011 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 319
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 23 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined index: 07 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 2 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 316
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined index: 08 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined index: 09 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 10 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 11 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 18 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 19 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 22 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 3 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 316
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 16 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 21 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 4 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 316
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 5 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 316
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 6 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 316
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 17 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 16 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 317
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 12 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 20 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 13 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined index: 00 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 0 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 316
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined index: 01 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 15 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:16 --> Severity: Notice  --> Undefined offset: 17 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 317
ERROR - 2012-11-17 22:13:17 --> Severity: Notice  --> Undefined index: 05 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 318
ERROR - 2012-11-17 22:13:17 --> Severity: Notice  --> Undefined offset: 18 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 317
ERROR - 2012-11-17 22:13:17 --> Severity: Notice  --> Undefined offset: 19 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 317
ERROR - 2012-11-17 22:13:17 --> Severity: Notice  --> Undefined offset: 20 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 317
ERROR - 2012-11-17 22:13:17 --> Severity: Notice  --> Undefined offset: 2012 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 319
ERROR - 2012-11-17 22:13:18 --> Severity: Notice  --> Undefined index: 06 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:19 --> Severity: Notice  --> Undefined index: 02 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:20 --> Severity: Notice  --> Undefined index: 05 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:21 --> Severity: Notice  --> Undefined index: 04 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 315
ERROR - 2012-11-17 22:13:21 --> Severity: Notice  --> Undefined offset: 21 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 317
ERROR - 2012-11-17 22:13:21 --> Severity: Notice  --> Undefined offset: 22 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 317
ERROR - 2012-11-17 22:13:21 --> Severity: Notice  --> Undefined offset: 23 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 317
ERROR - 2012-11-17 22:13:21 --> Severity: Notice  --> Undefined index: 06 /opt/lampp/htdocs/cleverfigures/trunk/application/models/wiki_model.php 318
DEBUG - 2012-11-17 22:13:22 --> Database Driver Class Initialized
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 95
ERROR - 2012-11-17 22:13:28 --> Could not find the language line "voc.i18n_activity_hours"
ERROR - 2012-11-17 22:13:28 --> Could not find the language line "voc.i18n_activity_wday"
DEBUG - 2012-11-17 22:13:28 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 22:13:28 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 22:13:28 --> Final output sent to browser
DEBUG - 2012-11-17 22:13:28 --> Total execution time: 12.7724
DEBUG - 2012-11-17 22:13:59 --> Config Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Hooks Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Utf8 Class Initialized
DEBUG - 2012-11-17 22:13:59 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 22:13:59 --> URI Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Router Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Output Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Security Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Input Class Initialized
DEBUG - 2012-11-17 22:13:59 --> XSS Filtering completed
DEBUG - 2012-11-17 22:13:59 --> XSS Filtering completed
DEBUG - 2012-11-17 22:13:59 --> XSS Filtering completed
DEBUG - 2012-11-17 22:13:59 --> XSS Filtering completed
DEBUG - 2012-11-17 22:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 22:13:59 --> Language Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Loader Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Helper loaded: date_helper
DEBUG - 2012-11-17 22:13:59 --> Helper loaded: form_helper
DEBUG - 2012-11-17 22:13:59 --> Helper loaded: language_helper
DEBUG - 2012-11-17 22:13:59 --> Helper loaded: url_helper
DEBUG - 2012-11-17 22:13:59 --> Helper loaded: html_helper
DEBUG - 2012-11-17 22:13:59 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 22:13:59 --> Session Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Helper loaded: string_helper
DEBUG - 2012-11-17 22:13:59 --> Encrypt Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Session routines successfully run
DEBUG - 2012-11-17 22:13:59 --> Form Validation Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Controller Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Helper loaded: file_helper
DEBUG - 2012-11-17 22:13:59 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:59 --> Model Class Initialized
DEBUG - 2012-11-17 22:13:59 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 22:13:59 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 22:13:59 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:14:06 --> Database Driver Class Initialized
ERROR - 2012-11-17 22:14:12 --> Could not find the language line "voc.i18n_activity_hours"
ERROR - 2012-11-17 22:14:12 --> Could not find the language line "voc.i18n_activity_wday"
DEBUG - 2012-11-17 22:14:12 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 22:14:12 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 22:14:12 --> Final output sent to browser
DEBUG - 2012-11-17 22:14:12 --> Total execution time: 12.9492
DEBUG - 2012-11-17 22:15:14 --> Config Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Hooks Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Utf8 Class Initialized
DEBUG - 2012-11-17 22:15:14 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 22:15:14 --> URI Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Router Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Output Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Security Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Input Class Initialized
DEBUG - 2012-11-17 22:15:14 --> XSS Filtering completed
DEBUG - 2012-11-17 22:15:14 --> XSS Filtering completed
DEBUG - 2012-11-17 22:15:14 --> XSS Filtering completed
DEBUG - 2012-11-17 22:15:14 --> XSS Filtering completed
DEBUG - 2012-11-17 22:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 22:15:14 --> Language Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Loader Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Helper loaded: date_helper
DEBUG - 2012-11-17 22:15:14 --> Helper loaded: form_helper
DEBUG - 2012-11-17 22:15:14 --> Helper loaded: language_helper
DEBUG - 2012-11-17 22:15:14 --> Helper loaded: url_helper
DEBUG - 2012-11-17 22:15:14 --> Helper loaded: html_helper
DEBUG - 2012-11-17 22:15:14 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 22:15:14 --> Session Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Helper loaded: string_helper
DEBUG - 2012-11-17 22:15:14 --> Encrypt Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Session routines successfully run
DEBUG - 2012-11-17 22:15:14 --> Form Validation Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Controller Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Helper loaded: file_helper
DEBUG - 2012-11-17 22:15:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:15:14 --> Model Class Initialized
DEBUG - 2012-11-17 22:15:14 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 22:15:14 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 22:15:14 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:15:21 --> Database Driver Class Initialized
ERROR - 2012-11-17 22:15:27 --> Could not find the language line "voc.i18n_activity_hours"
ERROR - 2012-11-17 22:15:27 --> Could not find the language line "voc.i18n_activity_wday"
DEBUG - 2012-11-17 22:15:27 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 22:15:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 22:15:27 --> Final output sent to browser
DEBUG - 2012-11-17 22:15:27 --> Total execution time: 12.7290
DEBUG - 2012-11-17 22:17:51 --> Config Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Hooks Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Utf8 Class Initialized
DEBUG - 2012-11-17 22:17:51 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 22:17:51 --> URI Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Router Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Output Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Security Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Input Class Initialized
DEBUG - 2012-11-17 22:17:51 --> XSS Filtering completed
DEBUG - 2012-11-17 22:17:51 --> XSS Filtering completed
DEBUG - 2012-11-17 22:17:51 --> XSS Filtering completed
DEBUG - 2012-11-17 22:17:51 --> XSS Filtering completed
DEBUG - 2012-11-17 22:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 22:17:51 --> Language Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Loader Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Helper loaded: date_helper
DEBUG - 2012-11-17 22:17:51 --> Helper loaded: form_helper
DEBUG - 2012-11-17 22:17:51 --> Helper loaded: language_helper
DEBUG - 2012-11-17 22:17:51 --> Helper loaded: url_helper
DEBUG - 2012-11-17 22:17:51 --> Helper loaded: html_helper
DEBUG - 2012-11-17 22:17:51 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 22:17:51 --> Session Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Helper loaded: string_helper
DEBUG - 2012-11-17 22:17:51 --> Encrypt Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Session routines successfully run
DEBUG - 2012-11-17 22:17:51 --> Form Validation Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Controller Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Model Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Model Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Model Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Model Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Model Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Model Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Helper loaded: file_helper
DEBUG - 2012-11-17 22:17:51 --> Model Class Initialized
DEBUG - 2012-11-17 22:17:51 --> Model Class Initialized
DEBUG - 2012-11-17 22:17:51 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 22:17:51 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 22:17:51 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:17:57 --> Database Driver Class Initialized
ERROR - 2012-11-17 22:18:04 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-17 22:18:04 --> Could not find the language line "voc.i18n_activity_wday"
DEBUG - 2012-11-17 22:18:04 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 22:18:04 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 22:18:04 --> Final output sent to browser
DEBUG - 2012-11-17 22:18:04 --> Total execution time: 12.8470
DEBUG - 2012-11-17 22:18:43 --> Config Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Hooks Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Utf8 Class Initialized
DEBUG - 2012-11-17 22:18:43 --> UTF-8 Support Enabled
DEBUG - 2012-11-17 22:18:43 --> URI Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Router Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Output Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Security Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Input Class Initialized
DEBUG - 2012-11-17 22:18:43 --> XSS Filtering completed
DEBUG - 2012-11-17 22:18:43 --> XSS Filtering completed
DEBUG - 2012-11-17 22:18:43 --> XSS Filtering completed
DEBUG - 2012-11-17 22:18:43 --> XSS Filtering completed
DEBUG - 2012-11-17 22:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-17 22:18:43 --> Language Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Loader Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Helper loaded: date_helper
DEBUG - 2012-11-17 22:18:43 --> Helper loaded: form_helper
DEBUG - 2012-11-17 22:18:43 --> Helper loaded: language_helper
DEBUG - 2012-11-17 22:18:43 --> Helper loaded: url_helper
DEBUG - 2012-11-17 22:18:43 --> Helper loaded: html_helper
DEBUG - 2012-11-17 22:18:43 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-17 22:18:43 --> Session Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Helper loaded: string_helper
DEBUG - 2012-11-17 22:18:43 --> Encrypt Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Session routines successfully run
DEBUG - 2012-11-17 22:18:43 --> Form Validation Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Controller Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Model Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Model Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Model Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Model Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Model Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Model Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Helper loaded: file_helper
DEBUG - 2012-11-17 22:18:43 --> Model Class Initialized
DEBUG - 2012-11-17 22:18:43 --> Model Class Initialized
DEBUG - 2012-11-17 22:18:43 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-17 22:18:43 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-17 22:18:43 --> Database Driver Class Initialized
DEBUG - 2012-11-17 22:18:49 --> Database Driver Class Initialized
ERROR - 2012-11-17 22:18:56 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-17 22:18:56 --> Could not find the language line "voc.i18n_activity_wday"
DEBUG - 2012-11-17 22:18:56 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-17 22:18:56 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-17 22:18:56 --> Final output sent to browser
DEBUG - 2012-11-17 22:18:56 --> Total execution time: 12.6683
