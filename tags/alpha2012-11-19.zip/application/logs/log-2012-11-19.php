<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-11-19 00:00:00 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 00:00:00 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 00:00:00 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 00:00:00 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 00:00:00 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 00:00:00 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 00:00:00 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 00:00:00 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 00:00:00 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 00:00:00 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 00:00:00 --> Final output sent to browser
DEBUG - 2012-11-19 00:00:00 --> Total execution time: 17.3063
DEBUG - 2012-11-19 00:02:28 --> Config Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:02:28 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:02:28 --> URI Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Router Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Output Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Security Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Input Class Initialized
DEBUG - 2012-11-19 00:02:28 --> XSS Filtering completed
DEBUG - 2012-11-19 00:02:28 --> XSS Filtering completed
DEBUG - 2012-11-19 00:02:28 --> XSS Filtering completed
DEBUG - 2012-11-19 00:02:28 --> XSS Filtering completed
DEBUG - 2012-11-19 00:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:02:28 --> Language Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Loader Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:02:28 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:02:28 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:02:28 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:02:28 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:02:28 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:02:28 --> Session Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:02:28 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Session routines successfully run
DEBUG - 2012-11-19 00:02:28 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Controller Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Model Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Model Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Model Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Model Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Model Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Model Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:02:28 --> Model Class Initialized
DEBUG - 2012-11-19 00:02:28 --> Model Class Initialized
DEBUG - 2012-11-19 00:02:28 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:02:28 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 00:02:28 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:02:36 --> Database Driver Class Initialized
ERROR - 2012-11-19 00:02:46 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 00:02:46 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 00:02:46 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 00:02:46 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 00:02:46 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 00:02:46 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 00:02:46 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 00:02:46 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 00:02:46 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 00:02:46 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 00:02:46 --> Final output sent to browser
DEBUG - 2012-11-19 00:02:46 --> Total execution time: 18.0828
DEBUG - 2012-11-19 00:10:22 --> Config Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:10:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:10:22 --> URI Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Router Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Output Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Security Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Input Class Initialized
DEBUG - 2012-11-19 00:10:22 --> XSS Filtering completed
DEBUG - 2012-11-19 00:10:22 --> XSS Filtering completed
DEBUG - 2012-11-19 00:10:22 --> XSS Filtering completed
DEBUG - 2012-11-19 00:10:22 --> XSS Filtering completed
DEBUG - 2012-11-19 00:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:10:22 --> Language Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Loader Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:10:22 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:10:22 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:10:22 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:10:22 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:10:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:10:22 --> Session Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:10:22 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Session routines successfully run
DEBUG - 2012-11-19 00:10:22 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Controller Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Model Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Model Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Model Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Model Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Model Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Model Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:10:22 --> Model Class Initialized
DEBUG - 2012-11-19 00:10:22 --> Model Class Initialized
DEBUG - 2012-11-19 00:10:22 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:10:22 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 00:10:22 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:10:30 --> Database Driver Class Initialized
ERROR - 2012-11-19 00:10:40 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 00:10:40 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 00:10:40 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 00:10:40 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 00:10:40 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 00:10:40 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 00:10:40 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 00:10:40 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 00:10:40 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 00:10:40 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 00:10:40 --> Final output sent to browser
DEBUG - 2012-11-19 00:10:40 --> Total execution time: 17.8482
DEBUG - 2012-11-19 00:28:25 --> Config Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:28:25 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:28:25 --> URI Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Router Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Output Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Security Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Input Class Initialized
DEBUG - 2012-11-19 00:28:25 --> XSS Filtering completed
DEBUG - 2012-11-19 00:28:25 --> XSS Filtering completed
DEBUG - 2012-11-19 00:28:25 --> XSS Filtering completed
DEBUG - 2012-11-19 00:28:25 --> XSS Filtering completed
DEBUG - 2012-11-19 00:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:28:25 --> Language Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Loader Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:28:25 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:28:25 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:28:25 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:28:25 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:28:25 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:28:25 --> Session Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:28:25 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Session routines successfully run
DEBUG - 2012-11-19 00:28:25 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Controller Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Model Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Model Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Model Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Model Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Model Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Model Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:28:25 --> Model Class Initialized
DEBUG - 2012-11-19 00:28:25 --> Model Class Initialized
DEBUG - 2012-11-19 00:28:25 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:28:25 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 00:28:25 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:28:30 --> Database Driver Class Initialized
ERROR - 2012-11-19 00:28:39 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 00:28:39 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 00:28:39 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 00:28:39 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 00:28:39 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 00:28:39 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 00:28:39 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 00:28:39 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 00:28:39 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 00:28:39 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 00:28:39 --> Final output sent to browser
DEBUG - 2012-11-19 00:28:39 --> Total execution time: 14.1491
DEBUG - 2012-11-19 00:38:09 --> Config Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:38:09 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:38:09 --> URI Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Router Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Output Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Security Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Input Class Initialized
DEBUG - 2012-11-19 00:38:09 --> XSS Filtering completed
DEBUG - 2012-11-19 00:38:09 --> XSS Filtering completed
DEBUG - 2012-11-19 00:38:09 --> XSS Filtering completed
DEBUG - 2012-11-19 00:38:09 --> XSS Filtering completed
DEBUG - 2012-11-19 00:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:38:09 --> Language Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Loader Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:38:09 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:38:09 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:38:09 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:38:09 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:38:09 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:38:09 --> Session Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:38:09 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Session routines successfully run
DEBUG - 2012-11-19 00:38:09 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Controller Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Model Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Model Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Model Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Model Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Model Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Model Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:38:09 --> Model Class Initialized
DEBUG - 2012-11-19 00:38:09 --> Model Class Initialized
DEBUG - 2012-11-19 00:38:09 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:38:09 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 00:38:09 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:38:14 --> DB Transaction Failure
ERROR - 2012-11-19 00:38:14 --> Query error: Table 'cleverfigures.image' doesn't exist
DEBUG - 2012-11-19 00:38:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2012-11-19 00:38:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/analisis_form.php:68) /opt/lampp/htdocs/cleverfigures/trunk/system/core/Common.php 442
DEBUG - 2012-11-19 00:46:05 --> Config Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:46:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:46:05 --> URI Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Router Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Output Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Security Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Input Class Initialized
DEBUG - 2012-11-19 00:46:05 --> XSS Filtering completed
DEBUG - 2012-11-19 00:46:05 --> XSS Filtering completed
DEBUG - 2012-11-19 00:46:05 --> XSS Filtering completed
DEBUG - 2012-11-19 00:46:05 --> XSS Filtering completed
DEBUG - 2012-11-19 00:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:46:05 --> Language Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Loader Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:46:05 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:46:05 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:46:05 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:46:05 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:46:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:46:05 --> Session Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:46:05 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Session routines successfully run
DEBUG - 2012-11-19 00:46:05 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Controller Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:46:05 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:05 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:46:05 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 00:46:05 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:46:10 --> DB Transaction Failure
ERROR - 2012-11-19 00:46:10 --> Query error: Unknown column 'cl_to' in 'field list'
DEBUG - 2012-11-19 00:46:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2012-11-19 00:46:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/analisis_form.php:68) /opt/lampp/htdocs/cleverfigures/trunk/system/core/Common.php 442
DEBUG - 2012-11-19 00:46:33 --> Config Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:46:33 --> URI Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Router Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Output Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Security Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Input Class Initialized
DEBUG - 2012-11-19 00:46:33 --> XSS Filtering completed
DEBUG - 2012-11-19 00:46:33 --> XSS Filtering completed
DEBUG - 2012-11-19 00:46:33 --> XSS Filtering completed
DEBUG - 2012-11-19 00:46:33 --> XSS Filtering completed
DEBUG - 2012-11-19 00:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:46:33 --> Language Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Loader Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:46:33 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:46:33 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:46:33 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:46:33 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:46:33 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:46:33 --> Session Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:46:33 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Session routines successfully run
DEBUG - 2012-11-19 00:46:33 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Controller Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:46:33 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:33 --> Model Class Initialized
DEBUG - 2012-11-19 00:46:33 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:46:33 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 00:46:33 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:46:38 --> DB Transaction Failure
ERROR - 2012-11-19 00:46:38 --> Query error: Unknown column 'cl_from' in 'where clause'
DEBUG - 2012-11-19 00:46:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2012-11-19 00:46:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/analisis_form.php:68) /opt/lampp/htdocs/cleverfigures/trunk/system/core/Common.php 442
DEBUG - 2012-11-19 00:47:43 --> Config Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:47:43 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:47:43 --> URI Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Router Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Output Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Security Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Input Class Initialized
DEBUG - 2012-11-19 00:47:43 --> XSS Filtering completed
DEBUG - 2012-11-19 00:47:43 --> XSS Filtering completed
DEBUG - 2012-11-19 00:47:43 --> XSS Filtering completed
DEBUG - 2012-11-19 00:47:43 --> XSS Filtering completed
DEBUG - 2012-11-19 00:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:47:43 --> Language Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Loader Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:47:43 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:47:43 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:47:43 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:47:43 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:47:43 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:47:43 --> Session Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:47:43 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Session routines successfully run
DEBUG - 2012-11-19 00:47:43 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Controller Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Model Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Model Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Model Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Model Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Model Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Model Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:47:43 --> Model Class Initialized
DEBUG - 2012-11-19 00:47:43 --> Model Class Initialized
DEBUG - 2012-11-19 00:47:43 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:47:43 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 00:47:43 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:47:48 --> Database Driver Class Initialized
ERROR - 2012-11-19 00:47:57 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 00:47:57 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 00:47:57 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 00:47:57 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 00:47:57 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 00:47:57 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 00:47:57 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 00:47:57 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 00:47:57 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 00:47:57 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 00:47:57 --> Final output sent to browser
DEBUG - 2012-11-19 00:47:57 --> Total execution time: 14.0659
DEBUG - 2012-11-19 00:49:48 --> Config Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:49:48 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:49:48 --> URI Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Router Class Initialized
DEBUG - 2012-11-19 00:49:48 --> No URI present. Default controller set.
DEBUG - 2012-11-19 00:49:48 --> Output Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Security Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Input Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:49:48 --> Language Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Loader Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:49:48 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:49:48 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:49:48 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:49:48 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:49:48 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:49:48 --> Session Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:49:48 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:49:48 --> A session cookie was not found.
DEBUG - 2012-11-19 00:49:48 --> Session routines successfully run
DEBUG - 2012-11-19 00:49:48 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Controller Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:49:48 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Database Forge Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Database Forge Class Initialized
DEBUG - 2012-11-19 00:49:48 --> Database Utility Class Initialized
DEBUG - 2012-11-19 00:49:48 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:49:48 --> File loaded: application/views/content/login_view.php
DEBUG - 2012-11-19 00:49:48 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 00:49:48 --> Final output sent to browser
DEBUG - 2012-11-19 00:49:48 --> Total execution time: 0.0358
DEBUG - 2012-11-19 00:49:55 --> Config Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:49:55 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:49:55 --> URI Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Router Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Output Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Security Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Input Class Initialized
DEBUG - 2012-11-19 00:49:55 --> XSS Filtering completed
DEBUG - 2012-11-19 00:49:55 --> XSS Filtering completed
DEBUG - 2012-11-19 00:49:55 --> XSS Filtering completed
DEBUG - 2012-11-19 00:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:49:55 --> Language Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Loader Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:49:55 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:49:55 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:49:55 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:49:55 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:49:55 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:49:55 --> Session Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:49:55 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Session routines successfully run
DEBUG - 2012-11-19 00:49:55 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Controller Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:49:55 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:55 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:55 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:49:55 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2012-11-19 00:49:55 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 00:49:55 --> Final output sent to browser
DEBUG - 2012-11-19 00:49:55 --> Total execution time: 0.1283
DEBUG - 2012-11-19 00:49:57 --> Config Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:49:57 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:49:57 --> URI Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Router Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Output Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Security Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Input Class Initialized
DEBUG - 2012-11-19 00:49:57 --> XSS Filtering completed
DEBUG - 2012-11-19 00:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:49:57 --> Language Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Loader Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:49:57 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:49:57 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:49:57 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:49:57 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:49:57 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:49:57 --> Session Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:49:57 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Session routines successfully run
DEBUG - 2012-11-19 00:49:57 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Controller Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:57 --> Model Class Initialized
DEBUG - 2012-11-19 00:49:57 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:49:57 --> File loaded: application/views/content/analise_view.php
DEBUG - 2012-11-19 00:49:57 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 00:49:57 --> Final output sent to browser
DEBUG - 2012-11-19 00:49:57 --> Total execution time: 0.0327
DEBUG - 2012-11-19 00:50:04 --> Config Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:50:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:50:04 --> URI Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Router Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Output Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Security Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Input Class Initialized
DEBUG - 2012-11-19 00:50:04 --> XSS Filtering completed
DEBUG - 2012-11-19 00:50:04 --> XSS Filtering completed
DEBUG - 2012-11-19 00:50:04 --> XSS Filtering completed
DEBUG - 2012-11-19 00:50:04 --> XSS Filtering completed
DEBUG - 2012-11-19 00:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:50:04 --> Language Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Loader Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:50:04 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:50:04 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:50:04 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:50:04 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:50:04 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:50:04 --> Session Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:50:04 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Session routines successfully run
DEBUG - 2012-11-19 00:50:04 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Controller Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Model Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Model Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Model Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Model Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Model Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Model Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:50:04 --> Model Class Initialized
DEBUG - 2012-11-19 00:50:04 --> Model Class Initialized
DEBUG - 2012-11-19 00:50:04 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:50:04 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 00:50:04 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:50:08 --> Database Driver Class Initialized
ERROR - 2012-11-19 00:50:18 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 00:50:18 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 00:50:18 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 00:50:18 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 00:50:18 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 00:50:18 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 00:50:18 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 00:50:18 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 00:50:18 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 00:50:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 00:50:18 --> Final output sent to browser
DEBUG - 2012-11-19 00:50:18 --> Total execution time: 13.8895
DEBUG - 2012-11-19 00:56:24 --> Config Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Hooks Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Utf8 Class Initialized
DEBUG - 2012-11-19 00:56:24 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 00:56:24 --> URI Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Router Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Output Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Security Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Input Class Initialized
DEBUG - 2012-11-19 00:56:24 --> XSS Filtering completed
DEBUG - 2012-11-19 00:56:24 --> XSS Filtering completed
DEBUG - 2012-11-19 00:56:24 --> XSS Filtering completed
DEBUG - 2012-11-19 00:56:24 --> XSS Filtering completed
DEBUG - 2012-11-19 00:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 00:56:24 --> Language Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Loader Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Helper loaded: date_helper
DEBUG - 2012-11-19 00:56:24 --> Helper loaded: form_helper
DEBUG - 2012-11-19 00:56:24 --> Helper loaded: language_helper
DEBUG - 2012-11-19 00:56:24 --> Helper loaded: url_helper
DEBUG - 2012-11-19 00:56:24 --> Helper loaded: html_helper
DEBUG - 2012-11-19 00:56:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 00:56:24 --> Session Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Helper loaded: string_helper
DEBUG - 2012-11-19 00:56:24 --> Encrypt Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Session routines successfully run
DEBUG - 2012-11-19 00:56:24 --> Form Validation Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Controller Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Model Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Model Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Model Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Model Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Model Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Model Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Helper loaded: file_helper
DEBUG - 2012-11-19 00:56:24 --> Model Class Initialized
DEBUG - 2012-11-19 00:56:24 --> Model Class Initialized
DEBUG - 2012-11-19 00:56:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 00:56:24 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 00:56:24 --> Database Driver Class Initialized
DEBUG - 2012-11-19 00:56:29 --> Database Driver Class Initialized
ERROR - 2012-11-19 00:56:38 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 00:56:38 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 00:56:38 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 00:56:38 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 00:56:38 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 00:56:38 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 00:56:38 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 00:56:38 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 00:56:38 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 00:56:38 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 00:56:38 --> Final output sent to browser
DEBUG - 2012-11-19 00:56:38 --> Total execution time: 13.8461
DEBUG - 2012-11-19 01:00:05 --> Config Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:00:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:00:05 --> URI Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Router Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Output Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Security Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Input Class Initialized
DEBUG - 2012-11-19 01:00:05 --> XSS Filtering completed
DEBUG - 2012-11-19 01:00:05 --> XSS Filtering completed
DEBUG - 2012-11-19 01:00:05 --> XSS Filtering completed
DEBUG - 2012-11-19 01:00:05 --> XSS Filtering completed
DEBUG - 2012-11-19 01:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:00:05 --> Language Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Loader Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:00:05 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:00:05 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:00:05 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:00:05 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:00:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:00:05 --> Session Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:00:05 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Session routines successfully run
DEBUG - 2012-11-19 01:00:05 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Controller Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:00:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:00:05 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:00:05 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Config Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:00:07 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:00:07 --> URI Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Router Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Output Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Security Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Input Class Initialized
DEBUG - 2012-11-19 01:00:07 --> XSS Filtering completed
DEBUG - 2012-11-19 01:00:07 --> XSS Filtering completed
DEBUG - 2012-11-19 01:00:07 --> XSS Filtering completed
DEBUG - 2012-11-19 01:00:07 --> XSS Filtering completed
DEBUG - 2012-11-19 01:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:00:07 --> Language Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Loader Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:00:07 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:00:07 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:00:07 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:00:07 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:00:07 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:00:07 --> Session Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:00:07 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Session routines successfully run
DEBUG - 2012-11-19 01:00:07 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Controller Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:00:07 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:07 --> Model Class Initialized
DEBUG - 2012-11-19 01:00:07 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:00:07 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:00:07 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:00:09 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:00:12 --> Database Driver Class Initialized
ERROR - 2012-11-19 01:00:19 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 01:00:19 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 01:00:19 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 01:00:19 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 01:00:19 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 01:00:19 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 01:00:19 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 01:00:19 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 01:00:19 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:00:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:00:19 --> Final output sent to browser
DEBUG - 2012-11-19 01:00:19 --> Total execution time: 14.6356
ERROR - 2012-11-19 01:00:22 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 01:00:22 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 01:00:22 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 01:00:22 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 01:00:22 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 01:00:22 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 01:00:22 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 01:00:22 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 01:00:22 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:00:22 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:00:22 --> Final output sent to browser
DEBUG - 2012-11-19 01:00:22 --> Total execution time: 14.3294
DEBUG - 2012-11-19 01:01:23 --> Config Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:01:23 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:01:23 --> URI Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Router Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Output Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Security Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Input Class Initialized
DEBUG - 2012-11-19 01:01:23 --> XSS Filtering completed
DEBUG - 2012-11-19 01:01:23 --> XSS Filtering completed
DEBUG - 2012-11-19 01:01:23 --> XSS Filtering completed
DEBUG - 2012-11-19 01:01:23 --> XSS Filtering completed
DEBUG - 2012-11-19 01:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:01:23 --> Language Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Loader Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:01:23 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:01:23 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:01:23 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:01:23 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:01:23 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:01:23 --> Session Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:01:23 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Session routines successfully run
DEBUG - 2012-11-19 01:01:23 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Controller Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:01:23 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:23 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:23 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:01:23 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:01:23 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Config Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:01:26 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:01:26 --> URI Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Router Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Output Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Security Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Input Class Initialized
DEBUG - 2012-11-19 01:01:26 --> XSS Filtering completed
DEBUG - 2012-11-19 01:01:26 --> XSS Filtering completed
DEBUG - 2012-11-19 01:01:26 --> XSS Filtering completed
DEBUG - 2012-11-19 01:01:26 --> XSS Filtering completed
DEBUG - 2012-11-19 01:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:01:26 --> Language Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Loader Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:01:26 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:01:26 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:01:26 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:01:26 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:01:26 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:01:26 --> Session Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:01:26 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Session routines successfully run
DEBUG - 2012-11-19 01:01:26 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Controller Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:01:26 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:26 --> Model Class Initialized
DEBUG - 2012-11-19 01:01:26 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:01:26 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:01:26 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:01:28 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:01:31 --> Database Driver Class Initialized
ERROR - 2012-11-19 01:01:38 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 01:01:38 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 01:01:38 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 01:01:38 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 01:01:38 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 01:01:38 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 01:01:38 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 01:01:38 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 01:01:38 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:01:38 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:01:38 --> Final output sent to browser
DEBUG - 2012-11-19 01:01:38 --> Total execution time: 14.1382
ERROR - 2012-11-19 01:01:41 --> Could not find the language line "voc.i18n_activity_hour"
ERROR - 2012-11-19 01:01:41 --> Could not find the language line "voc.i18n_activity_wday"
ERROR - 2012-11-19 01:01:41 --> Could not find the language line "voc.i18n_activity_week"
ERROR - 2012-11-19 01:01:41 --> Could not find the language line "voc.i18n_activity_month"
ERROR - 2012-11-19 01:01:41 --> Could not find the language line "voc.i18n_activity_year"
ERROR - 2012-11-19 01:01:41 --> Could not find the language line "voc.i18n_uploads"
ERROR - 2012-11-19 01:01:41 --> Could not find the language line "voc.i18n_upsize"
ERROR - 2012-11-19 01:01:41 --> Could not find the language line "voc.i18n_uploads"
DEBUG - 2012-11-19 01:01:41 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:01:41 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:01:41 --> Final output sent to browser
DEBUG - 2012-11-19 01:01:41 --> Total execution time: 14.1915
DEBUG - 2012-11-19 01:05:22 --> Config Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:05:22 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:05:22 --> URI Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Router Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Output Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Security Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Input Class Initialized
DEBUG - 2012-11-19 01:05:22 --> XSS Filtering completed
DEBUG - 2012-11-19 01:05:22 --> XSS Filtering completed
DEBUG - 2012-11-19 01:05:22 --> XSS Filtering completed
DEBUG - 2012-11-19 01:05:22 --> XSS Filtering completed
DEBUG - 2012-11-19 01:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:05:22 --> Language Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Loader Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:05:22 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:05:22 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:05:22 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:05:22 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:05:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:05:22 --> Session Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:05:22 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Session routines successfully run
DEBUG - 2012-11-19 01:05:22 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Controller Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Model Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Model Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Model Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Model Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Model Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Model Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:05:22 --> Model Class Initialized
DEBUG - 2012-11-19 01:05:22 --> Model Class Initialized
DEBUG - 2012-11-19 01:05:22 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:05:22 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:05:22 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:05:27 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:05:36 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:05:36 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:05:36 --> Final output sent to browser
DEBUG - 2012-11-19 01:05:36 --> Total execution time: 14.0844
DEBUG - 2012-11-19 01:06:59 --> Config Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:06:59 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:06:59 --> URI Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Router Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Output Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Security Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Input Class Initialized
DEBUG - 2012-11-19 01:06:59 --> XSS Filtering completed
DEBUG - 2012-11-19 01:06:59 --> XSS Filtering completed
DEBUG - 2012-11-19 01:06:59 --> XSS Filtering completed
DEBUG - 2012-11-19 01:06:59 --> XSS Filtering completed
DEBUG - 2012-11-19 01:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:06:59 --> Language Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Loader Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:06:59 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:06:59 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:06:59 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:06:59 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:06:59 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:06:59 --> Session Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:06:59 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Session routines successfully run
DEBUG - 2012-11-19 01:06:59 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Controller Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:06:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:06:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:06:59 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:06:59 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:06:59 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:07:04 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:07:13 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:07:13 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:07:13 --> Final output sent to browser
DEBUG - 2012-11-19 01:07:13 --> Total execution time: 13.7362
DEBUG - 2012-11-19 01:08:32 --> Config Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:08:32 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:08:32 --> URI Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Router Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Output Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Security Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Input Class Initialized
DEBUG - 2012-11-19 01:08:32 --> XSS Filtering completed
DEBUG - 2012-11-19 01:08:32 --> XSS Filtering completed
DEBUG - 2012-11-19 01:08:32 --> XSS Filtering completed
DEBUG - 2012-11-19 01:08:32 --> XSS Filtering completed
DEBUG - 2012-11-19 01:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:08:32 --> Language Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Loader Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:08:32 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:08:32 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:08:32 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:08:32 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:08:32 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:08:32 --> Session Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:08:32 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Session routines successfully run
DEBUG - 2012-11-19 01:08:32 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Controller Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Model Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Model Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Model Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Model Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Model Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Model Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:08:32 --> Model Class Initialized
DEBUG - 2012-11-19 01:08:32 --> Model Class Initialized
DEBUG - 2012-11-19 01:08:32 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:08:32 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:08:32 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:08:37 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:08:46 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:08:46 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:08:46 --> Final output sent to browser
DEBUG - 2012-11-19 01:08:46 --> Total execution time: 13.9653
DEBUG - 2012-11-19 01:26:47 --> Config Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:26:47 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:26:47 --> URI Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Router Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Output Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Security Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Input Class Initialized
DEBUG - 2012-11-19 01:26:47 --> XSS Filtering completed
DEBUG - 2012-11-19 01:26:47 --> XSS Filtering completed
DEBUG - 2012-11-19 01:26:47 --> XSS Filtering completed
DEBUG - 2012-11-19 01:26:47 --> XSS Filtering completed
DEBUG - 2012-11-19 01:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:26:47 --> Language Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Loader Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:26:47 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:26:47 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:26:47 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:26:47 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:26:47 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:26:47 --> Session Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:26:47 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Session routines successfully run
DEBUG - 2012-11-19 01:26:47 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Controller Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Model Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Model Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Model Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Model Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Model Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Model Class Initialized
DEBUG - 2012-11-19 01:26:47 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:26:47 --> Model Class Initialized
DEBUG - 2012-11-19 01:26:48 --> Model Class Initialized
DEBUG - 2012-11-19 01:26:48 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:26:48 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:26:48 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:26:52 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Config Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:29:05 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:29:05 --> URI Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Router Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Output Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Security Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Input Class Initialized
DEBUG - 2012-11-19 01:29:05 --> XSS Filtering completed
DEBUG - 2012-11-19 01:29:05 --> XSS Filtering completed
DEBUG - 2012-11-19 01:29:05 --> XSS Filtering completed
DEBUG - 2012-11-19 01:29:05 --> XSS Filtering completed
DEBUG - 2012-11-19 01:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:29:05 --> Language Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Loader Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:29:05 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:29:05 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:29:05 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:29:05 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:29:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:29:05 --> Session Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:29:05 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Session routines successfully run
DEBUG - 2012-11-19 01:29:05 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Controller Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:29:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:29:05 --> Model Class Initialized
DEBUG - 2012-11-19 01:29:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:29:05 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:29:05 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:29:10 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:29:19 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:29:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:29:19 --> Final output sent to browser
DEBUG - 2012-11-19 01:29:19 --> Total execution time: 13.9967
DEBUG - 2012-11-19 01:30:52 --> Config Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:30:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:30:52 --> URI Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Router Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Output Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Security Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Input Class Initialized
DEBUG - 2012-11-19 01:30:52 --> XSS Filtering completed
DEBUG - 2012-11-19 01:30:52 --> XSS Filtering completed
DEBUG - 2012-11-19 01:30:52 --> XSS Filtering completed
DEBUG - 2012-11-19 01:30:52 --> XSS Filtering completed
DEBUG - 2012-11-19 01:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:30:52 --> Language Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Loader Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:30:52 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:30:52 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:30:52 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:30:52 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:30:52 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:30:52 --> Session Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:30:52 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Session routines successfully run
DEBUG - 2012-11-19 01:30:52 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Controller Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:30:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:30:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:30:52 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:30:52 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:30:52 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:30:57 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:31:06 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:31:06 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:31:06 --> Final output sent to browser
DEBUG - 2012-11-19 01:31:06 --> Total execution time: 14.0337
DEBUG - 2012-11-19 01:35:11 --> Config Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:35:11 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:35:11 --> URI Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Router Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Output Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Security Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Input Class Initialized
DEBUG - 2012-11-19 01:35:11 --> XSS Filtering completed
DEBUG - 2012-11-19 01:35:11 --> XSS Filtering completed
DEBUG - 2012-11-19 01:35:11 --> XSS Filtering completed
DEBUG - 2012-11-19 01:35:11 --> XSS Filtering completed
DEBUG - 2012-11-19 01:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:35:11 --> Language Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Loader Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:35:11 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:35:11 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:35:11 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:35:11 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:35:11 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:35:11 --> Session Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:35:11 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Session routines successfully run
DEBUG - 2012-11-19 01:35:11 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Controller Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Model Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Model Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Model Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Model Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Model Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Model Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:35:11 --> Model Class Initialized
DEBUG - 2012-11-19 01:35:11 --> Model Class Initialized
DEBUG - 2012-11-19 01:35:11 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:35:11 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:35:11 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:35:15 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:35:25 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:35:25 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:35:25 --> Final output sent to browser
DEBUG - 2012-11-19 01:35:25 --> Total execution time: 13.8807
DEBUG - 2012-11-19 01:36:52 --> Config Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:36:52 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:36:52 --> URI Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Router Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Output Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Security Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Input Class Initialized
DEBUG - 2012-11-19 01:36:52 --> XSS Filtering completed
DEBUG - 2012-11-19 01:36:52 --> XSS Filtering completed
DEBUG - 2012-11-19 01:36:52 --> XSS Filtering completed
DEBUG - 2012-11-19 01:36:52 --> XSS Filtering completed
DEBUG - 2012-11-19 01:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:36:52 --> Language Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Loader Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:36:52 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:36:52 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:36:52 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:36:52 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:36:52 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:36:52 --> Session Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:36:52 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Session routines successfully run
DEBUG - 2012-11-19 01:36:52 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Controller Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:36:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:36:52 --> Model Class Initialized
DEBUG - 2012-11-19 01:36:52 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:36:52 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:36:52 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:36:57 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:37:06 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:37:06 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:37:06 --> Final output sent to browser
DEBUG - 2012-11-19 01:37:06 --> Total execution time: 13.9377
DEBUG - 2012-11-19 01:41:00 --> Config Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:41:00 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:41:00 --> URI Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Router Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Output Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Security Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Input Class Initialized
DEBUG - 2012-11-19 01:41:00 --> XSS Filtering completed
DEBUG - 2012-11-19 01:41:00 --> XSS Filtering completed
DEBUG - 2012-11-19 01:41:00 --> XSS Filtering completed
DEBUG - 2012-11-19 01:41:00 --> XSS Filtering completed
DEBUG - 2012-11-19 01:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:41:00 --> Language Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Loader Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:41:00 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:41:00 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:41:00 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:41:00 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:41:00 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:41:00 --> Session Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:41:00 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Session routines successfully run
DEBUG - 2012-11-19 01:41:00 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Controller Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Model Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Model Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Model Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Model Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Model Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Model Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:41:00 --> Model Class Initialized
DEBUG - 2012-11-19 01:41:00 --> Model Class Initialized
DEBUG - 2012-11-19 01:41:00 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:41:00 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:41:00 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:41:05 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:41:14 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:41:14 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:41:14 --> Final output sent to browser
DEBUG - 2012-11-19 01:41:14 --> Total execution time: 13.8107
DEBUG - 2012-11-19 01:42:15 --> Config Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:42:15 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:42:15 --> URI Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Router Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Output Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Security Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Input Class Initialized
DEBUG - 2012-11-19 01:42:15 --> XSS Filtering completed
DEBUG - 2012-11-19 01:42:15 --> XSS Filtering completed
DEBUG - 2012-11-19 01:42:15 --> XSS Filtering completed
DEBUG - 2012-11-19 01:42:15 --> XSS Filtering completed
DEBUG - 2012-11-19 01:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:42:15 --> Language Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Loader Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:42:15 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:42:15 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:42:15 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:42:15 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:42:15 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:42:15 --> Session Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:42:15 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Session routines successfully run
DEBUG - 2012-11-19 01:42:15 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Controller Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:42:15 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:15 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:15 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:42:15 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:42:15 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:42:20 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Config Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:42:33 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:42:33 --> URI Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Router Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Output Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Security Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Input Class Initialized
DEBUG - 2012-11-19 01:42:33 --> XSS Filtering completed
DEBUG - 2012-11-19 01:42:33 --> XSS Filtering completed
DEBUG - 2012-11-19 01:42:33 --> XSS Filtering completed
DEBUG - 2012-11-19 01:42:33 --> XSS Filtering completed
DEBUG - 2012-11-19 01:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:42:33 --> Language Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Loader Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:42:33 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:42:33 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:42:33 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:42:33 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:42:33 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:42:33 --> Session Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:42:33 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Session routines successfully run
DEBUG - 2012-11-19 01:42:33 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Controller Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:42:33 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:33 --> Model Class Initialized
DEBUG - 2012-11-19 01:42:33 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:42:33 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:42:33 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:42:38 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:42:47 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:42:47 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:42:47 --> Final output sent to browser
DEBUG - 2012-11-19 01:42:47 --> Total execution time: 13.7561
DEBUG - 2012-11-19 01:45:37 --> Config Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:45:37 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:45:37 --> URI Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Router Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Output Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Security Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Input Class Initialized
DEBUG - 2012-11-19 01:45:37 --> XSS Filtering completed
DEBUG - 2012-11-19 01:45:37 --> XSS Filtering completed
DEBUG - 2012-11-19 01:45:37 --> XSS Filtering completed
DEBUG - 2012-11-19 01:45:37 --> XSS Filtering completed
DEBUG - 2012-11-19 01:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:45:37 --> Language Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Loader Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:45:37 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:45:37 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:45:37 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:45:37 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:45:37 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:45:37 --> Session Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:45:37 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Session routines successfully run
DEBUG - 2012-11-19 01:45:37 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Controller Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Model Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Model Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Model Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Model Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Model Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Model Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:45:37 --> Model Class Initialized
DEBUG - 2012-11-19 01:45:37 --> Model Class Initialized
DEBUG - 2012-11-19 01:45:37 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:45:37 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:45:37 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:45:42 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:45:51 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:45:51 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:45:51 --> Final output sent to browser
DEBUG - 2012-11-19 01:45:51 --> Total execution time: 13.7594
DEBUG - 2012-11-19 01:47:04 --> Config Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:47:04 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:47:04 --> URI Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Router Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Output Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Security Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Input Class Initialized
DEBUG - 2012-11-19 01:47:04 --> XSS Filtering completed
DEBUG - 2012-11-19 01:47:04 --> XSS Filtering completed
DEBUG - 2012-11-19 01:47:04 --> XSS Filtering completed
DEBUG - 2012-11-19 01:47:04 --> XSS Filtering completed
DEBUG - 2012-11-19 01:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:47:04 --> Language Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Loader Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:47:04 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:47:04 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:47:04 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:47:04 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:47:04 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:47:04 --> Session Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:47:04 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Session routines successfully run
DEBUG - 2012-11-19 01:47:04 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Controller Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Model Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Model Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Model Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Model Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Model Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Model Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:47:04 --> Model Class Initialized
DEBUG - 2012-11-19 01:47:04 --> Model Class Initialized
DEBUG - 2012-11-19 01:47:04 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:47:04 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:47:04 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:47:09 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:47:18 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:47:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:47:18 --> Final output sent to browser
DEBUG - 2012-11-19 01:47:18 --> Total execution time: 13.9133
DEBUG - 2012-11-19 01:49:59 --> Config Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Hooks Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Utf8 Class Initialized
DEBUG - 2012-11-19 01:49:59 --> UTF-8 Support Enabled
DEBUG - 2012-11-19 01:49:59 --> URI Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Router Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Output Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Security Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Input Class Initialized
DEBUG - 2012-11-19 01:49:59 --> XSS Filtering completed
DEBUG - 2012-11-19 01:49:59 --> XSS Filtering completed
DEBUG - 2012-11-19 01:49:59 --> XSS Filtering completed
DEBUG - 2012-11-19 01:49:59 --> XSS Filtering completed
DEBUG - 2012-11-19 01:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-11-19 01:49:59 --> Language Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Loader Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Helper loaded: date_helper
DEBUG - 2012-11-19 01:49:59 --> Helper loaded: form_helper
DEBUG - 2012-11-19 01:49:59 --> Helper loaded: language_helper
DEBUG - 2012-11-19 01:49:59 --> Helper loaded: url_helper
DEBUG - 2012-11-19 01:49:59 --> Helper loaded: html_helper
DEBUG - 2012-11-19 01:49:59 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2012-11-19 01:49:59 --> Session Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Helper loaded: string_helper
DEBUG - 2012-11-19 01:49:59 --> Encrypt Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Session routines successfully run
DEBUG - 2012-11-19 01:49:59 --> Form Validation Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Controller Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Helper loaded: file_helper
DEBUG - 2012-11-19 01:49:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:49:59 --> Model Class Initialized
DEBUG - 2012-11-19 01:49:59 --> File loaded: application/views/templates/header_view.php
DEBUG - 2012-11-19 01:49:59 --> File loaded: application/views/content/analising_view.php
DEBUG - 2012-11-19 01:49:59 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:50:04 --> Database Driver Class Initialized
DEBUG - 2012-11-19 01:50:13 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2012-11-19 01:50:13 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2012-11-19 01:50:13 --> Final output sent to browser
DEBUG - 2012-11-19 01:50:13 --> Total execution time: 14.1709
