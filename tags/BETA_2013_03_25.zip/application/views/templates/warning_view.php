<div id = "warning">
	<?=img("images/icons/Developer_Icons_PNG/PNG/warning.png");?>
</div>