<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-03-25 13:28:19 --> Config Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:28:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:28:19 --> URI Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Router Class Initialized
DEBUG - 2013-03-25 13:28:19 --> No URI present. Default controller set.
DEBUG - 2013-03-25 13:28:19 --> Output Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Security Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Input Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:28:19 --> Language Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Loader Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:28:19 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:28:19 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:28:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:28:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:28:19 --> Session Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:28:19 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:28:19 --> A session cookie was not found.
DEBUG - 2013-03-25 13:28:19 --> Session routines successfully run
DEBUG - 2013-03-25 13:28:19 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Controller Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:28:19 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Database Forge Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Database Forge Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Database Utility Class Initialized
DEBUG - 2013-03-25 13:28:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:28:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:28:19 --> File loaded: application/views/content/login_view.php
DEBUG - 2013-03-25 13:28:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:28:19 --> Final output sent to browser
DEBUG - 2013-03-25 13:28:19 --> Total execution time: 0.4733
DEBUG - 2013-03-25 13:28:23 --> Config Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:28:23 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:28:23 --> URI Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Router Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Output Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Security Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Input Class Initialized
DEBUG - 2013-03-25 13:28:23 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:23 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:23 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:23 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:28:23 --> Language Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Loader Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:28:23 --> Session Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:28:23 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Session routines successfully run
DEBUG - 2013-03-25 13:28:23 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Controller Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 13:28:23 --> Config Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:28:23 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:28:23 --> URI Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Router Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Output Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Security Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Input Class Initialized
DEBUG - 2013-03-25 13:28:23 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:28:23 --> Language Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Loader Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:28:23 --> Session Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:28:23 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Session routines successfully run
DEBUG - 2013-03-25 13:28:23 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Controller Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:23 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:28:23 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:28:23 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 13:28:23 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:28:23 --> Final output sent to browser
DEBUG - 2013-03-25 13:28:23 --> Total execution time: 0.0740
DEBUG - 2013-03-25 13:28:26 --> Config Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:28:26 --> URI Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Router Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Output Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Security Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Input Class Initialized
DEBUG - 2013-03-25 13:28:26 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:28:26 --> Language Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Loader Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:28:26 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:28:26 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:28:26 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:28:26 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:28:26 --> Session Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:28:26 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Session routines successfully run
DEBUG - 2013-03-25 13:28:26 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Controller Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:28:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:26 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:28:26 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:28:26 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 13:28:26 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:28:26 --> Final output sent to browser
DEBUG - 2013-03-25 13:28:26 --> Total execution time: 0.1060
DEBUG - 2013-03-25 13:28:29 --> Config Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:28:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:28:29 --> URI Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Router Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Output Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Security Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Input Class Initialized
DEBUG - 2013-03-25 13:28:29 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:29 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:29 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:29 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:28:29 --> Language Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Loader Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:28:29 --> Session Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:28:29 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Session routines successfully run
DEBUG - 2013-03-25 13:28:29 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Controller Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:28:29 --> Config Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:28:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:28:29 --> URI Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Router Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Output Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Security Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Input Class Initialized
DEBUG - 2013-03-25 13:28:29 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:28:29 --> Language Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Loader Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:28:29 --> Session Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:28:29 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Session routines successfully run
DEBUG - 2013-03-25 13:28:29 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Controller Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:28:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:29 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:28:29 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:28:29 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 13:28:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:28:29 --> Final output sent to browser
DEBUG - 2013-03-25 13:28:29 --> Total execution time: 0.0329
DEBUG - 2013-03-25 13:28:36 --> Config Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:28:36 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:28:36 --> URI Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Router Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Output Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Security Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Input Class Initialized
DEBUG - 2013-03-25 13:28:36 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:28:36 --> Language Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Loader Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:28:36 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:28:36 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:28:36 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:28:36 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:28:36 --> Session Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:28:36 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Session routines successfully run
DEBUG - 2013-03-25 13:28:36 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Controller Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:28:36 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:36 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:28:36 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:28:36 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 13:28:36 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:28:36 --> Final output sent to browser
DEBUG - 2013-03-25 13:28:36 --> Total execution time: 0.0566
DEBUG - 2013-03-25 13:28:56 --> Config Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:28:56 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:28:56 --> URI Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Router Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Output Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Security Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Input Class Initialized
DEBUG - 2013-03-25 13:28:56 --> XSS Filtering completed
DEBUG - 2013-03-25 13:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:28:56 --> Language Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Loader Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:28:56 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:28:56 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:28:56 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:28:56 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:28:56 --> Session Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:28:56 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Session routines successfully run
DEBUG - 2013-03-25 13:28:56 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Controller Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:28:56 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Model Class Initialized
DEBUG - 2013-03-25 13:28:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:28:56 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:28:56 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 13:28:56 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:28:56 --> Final output sent to browser
DEBUG - 2013-03-25 13:28:56 --> Total execution time: 0.0490
DEBUG - 2013-03-25 13:29:26 --> Config Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:29:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:29:26 --> URI Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Router Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Output Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Security Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Input Class Initialized
DEBUG - 2013-03-25 13:29:26 --> XSS Filtering completed
DEBUG - 2013-03-25 13:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:29:26 --> Language Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Loader Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:29:26 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:29:26 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:29:26 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:29:26 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:29:26 --> Session Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:29:26 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Session routines successfully run
DEBUG - 2013-03-25 13:29:26 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Controller Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:29:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:26 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:29:26 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:29:26 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 13:29:26 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:29:26 --> Final output sent to browser
DEBUG - 2013-03-25 13:29:26 --> Total execution time: 0.0469
DEBUG - 2013-03-25 13:29:47 --> Config Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:29:47 --> URI Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Router Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Output Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Security Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Input Class Initialized
DEBUG - 2013-03-25 13:29:47 --> XSS Filtering completed
DEBUG - 2013-03-25 13:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:29:47 --> Language Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Loader Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:29:47 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:29:47 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:29:47 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:29:47 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:29:47 --> Session Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:29:47 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Session routines successfully run
DEBUG - 2013-03-25 13:29:47 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Controller Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:29:47 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Model Class Initialized
DEBUG - 2013-03-25 13:29:47 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:29:47 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:29:47 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 13:29:47 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:29:47 --> Final output sent to browser
DEBUG - 2013-03-25 13:29:47 --> Total execution time: 0.0510
DEBUG - 2013-03-25 13:30:00 --> Config Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:30:00 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:30:00 --> URI Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Router Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Output Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Security Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Input Class Initialized
DEBUG - 2013-03-25 13:30:00 --> XSS Filtering completed
DEBUG - 2013-03-25 13:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:30:00 --> Language Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Loader Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:30:00 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:30:00 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:30:00 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:30:00 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:30:00 --> Session Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:30:00 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Session routines successfully run
DEBUG - 2013-03-25 13:30:00 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Controller Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:30:00 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:00 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:30:00 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:30:00 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 13:30:00 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:30:00 --> Final output sent to browser
DEBUG - 2013-03-25 13:30:00 --> Total execution time: 0.0364
DEBUG - 2013-03-25 13:30:02 --> Config Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:30:02 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:30:02 --> URI Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Router Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Output Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Security Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Input Class Initialized
DEBUG - 2013-03-25 13:30:02 --> XSS Filtering completed
DEBUG - 2013-03-25 13:30:02 --> XSS Filtering completed
DEBUG - 2013-03-25 13:30:02 --> XSS Filtering completed
DEBUG - 2013-03-25 13:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:30:02 --> Language Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Loader Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:30:02 --> Session Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:30:02 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Session routines successfully run
DEBUG - 2013-03-25 13:30:02 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Controller Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:30:02 --> Config Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:30:02 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:30:02 --> URI Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Router Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Output Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Security Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Input Class Initialized
DEBUG - 2013-03-25 13:30:02 --> XSS Filtering completed
DEBUG - 2013-03-25 13:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:30:02 --> Language Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Loader Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:30:02 --> Session Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:30:02 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Session routines successfully run
DEBUG - 2013-03-25 13:30:02 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Controller Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 13:30:02 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:30:02 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:30:02 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 13:30:02 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:30:02 --> Final output sent to browser
DEBUG - 2013-03-25 13:30:02 --> Total execution time: 0.0354
DEBUG - 2013-03-25 13:31:24 --> Config Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:31:24 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:31:24 --> URI Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Router Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Output Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Security Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Input Class Initialized
DEBUG - 2013-03-25 13:31:24 --> XSS Filtering completed
DEBUG - 2013-03-25 13:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:31:24 --> Language Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Loader Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:31:24 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:31:24 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:31:24 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:31:24 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:31:24 --> Session Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:31:24 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Session routines successfully run
DEBUG - 2013-03-25 13:31:24 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Controller Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:31:24 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:31:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:31:24 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 13:31:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:31:24 --> Final output sent to browser
DEBUG - 2013-03-25 13:31:24 --> Total execution time: 0.0441
DEBUG - 2013-03-25 13:31:26 --> Config Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:31:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:31:26 --> URI Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Router Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Output Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Security Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Input Class Initialized
DEBUG - 2013-03-25 13:31:26 --> XSS Filtering completed
DEBUG - 2013-03-25 13:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:31:26 --> Language Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Loader Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:31:26 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:31:26 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:31:26 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:31:26 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:31:26 --> Session Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:31:26 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Session routines successfully run
DEBUG - 2013-03-25 13:31:26 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Controller Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:31:26 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:27 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:27 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:31:27 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:31:27 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 13:31:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:31:27 --> Final output sent to browser
DEBUG - 2013-03-25 13:31:27 --> Total execution time: 0.0703
DEBUG - 2013-03-25 13:31:29 --> Config Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:31:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:31:29 --> URI Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Router Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Output Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Security Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Input Class Initialized
DEBUG - 2013-03-25 13:31:29 --> XSS Filtering completed
DEBUG - 2013-03-25 13:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:31:29 --> Language Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Loader Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:31:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:31:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:31:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:31:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:31:29 --> Session Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:31:29 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Session routines successfully run
DEBUG - 2013-03-25 13:31:29 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Controller Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:31:29 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:31:29 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:31:29 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 13:31:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:31:29 --> Final output sent to browser
DEBUG - 2013-03-25 13:31:29 --> Total execution time: 0.0433
DEBUG - 2013-03-25 13:32:01 --> Config Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:32:01 --> URI Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Router Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Output Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Security Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Input Class Initialized
DEBUG - 2013-03-25 13:32:01 --> XSS Filtering completed
DEBUG - 2013-03-25 13:32:01 --> XSS Filtering completed
DEBUG - 2013-03-25 13:32:01 --> XSS Filtering completed
DEBUG - 2013-03-25 13:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:32:01 --> Language Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Loader Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:32:01 --> Session Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:32:01 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Session routines successfully run
DEBUG - 2013-03-25 13:32:01 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Controller Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 13:32:01 --> Config Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:32:01 --> URI Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Router Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Output Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Security Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Input Class Initialized
DEBUG - 2013-03-25 13:32:01 --> XSS Filtering completed
DEBUG - 2013-03-25 13:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:32:01 --> Language Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Loader Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:32:01 --> Session Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:32:01 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Session routines successfully run
DEBUG - 2013-03-25 13:32:01 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Controller Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:32:01 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:01 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 13:32:01 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:32:01 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 13:32:01 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:32:01 --> Final output sent to browser
DEBUG - 2013-03-25 13:32:01 --> Total execution time: 0.0417
DEBUG - 2013-03-25 13:32:03 --> Config Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:32:03 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:32:03 --> URI Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Router Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Output Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Security Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Input Class Initialized
DEBUG - 2013-03-25 13:32:03 --> XSS Filtering completed
DEBUG - 2013-03-25 13:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:32:03 --> Language Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Loader Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:32:03 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:32:03 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:32:03 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:32:03 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:32:03 --> Session Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:32:03 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Session routines successfully run
DEBUG - 2013-03-25 13:32:03 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Controller Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:32:03 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Model Class Initialized
DEBUG - 2013-03-25 13:32:03 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 13:32:03 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:32:03 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 13:32:03 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:32:03 --> Final output sent to browser
DEBUG - 2013-03-25 13:32:03 --> Total execution time: 0.0557
DEBUG - 2013-03-25 13:38:18 --> Config Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:38:18 --> URI Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Router Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Output Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Security Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Input Class Initialized
DEBUG - 2013-03-25 13:38:18 --> XSS Filtering completed
DEBUG - 2013-03-25 13:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:38:18 --> Language Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Loader Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:38:18 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:38:18 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:38:18 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:38:18 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:38:18 --> Session Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:38:18 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Session routines successfully run
DEBUG - 2013-03-25 13:38:18 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Controller Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Model Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Model Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Helper loaded: file_helper
DEBUG - 2013-03-25 13:38:18 --> Model Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Model Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Model Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Model Class Initialized
DEBUG - 2013-03-25 13:38:18 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 13:38:18 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:38:18 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 13:38:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:38:18 --> Final output sent to browser
DEBUG - 2013-03-25 13:38:18 --> Total execution time: 0.0627
DEBUG - 2013-03-25 13:38:29 --> Config Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 13:38:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 13:38:29 --> URI Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Router Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Output Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Security Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Input Class Initialized
DEBUG - 2013-03-25 13:38:29 --> XSS Filtering completed
DEBUG - 2013-03-25 13:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 13:38:29 --> Language Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Loader Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 13:38:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 13:38:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 13:38:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 13:38:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 13:38:29 --> Session Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Helper loaded: string_helper
DEBUG - 2013-03-25 13:38:29 --> Encrypt Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Session routines successfully run
DEBUG - 2013-03-25 13:38:29 --> Form Validation Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Controller Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Model Class Initialized
DEBUG - 2013-03-25 13:38:29 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 13:38:29 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 13:38:29 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 13:38:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 13:38:29 --> Final output sent to browser
DEBUG - 2013-03-25 13:38:29 --> Total execution time: 0.0454
DEBUG - 2013-03-25 18:15:39 --> Config Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:15:39 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:15:39 --> URI Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Router Class Initialized
DEBUG - 2013-03-25 18:15:39 --> No URI present. Default controller set.
DEBUG - 2013-03-25 18:15:39 --> Output Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Security Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Input Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:15:39 --> Language Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Loader Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:15:39 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:15:39 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:15:39 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:15:39 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:15:39 --> Session Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:15:39 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:15:39 --> A session cookie was not found.
DEBUG - 2013-03-25 18:15:39 --> Session routines successfully run
DEBUG - 2013-03-25 18:15:39 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Controller Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Helper loaded: file_helper
DEBUG - 2013-03-25 18:15:39 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Database Forge Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Database Forge Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Database Utility Class Initialized
DEBUG - 2013-03-25 18:15:39 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 18:15:39 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:15:39 --> File loaded: application/views/content/login_view.php
DEBUG - 2013-03-25 18:15:39 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:15:39 --> Final output sent to browser
DEBUG - 2013-03-25 18:15:39 --> Total execution time: 0.5285
DEBUG - 2013-03-25 18:15:43 --> Config Class Initialized
DEBUG - 2013-03-25 18:15:43 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:15:43 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:15:43 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:15:43 --> URI Class Initialized
DEBUG - 2013-03-25 18:15:43 --> Router Class Initialized
DEBUG - 2013-03-25 18:15:43 --> Output Class Initialized
DEBUG - 2013-03-25 18:15:43 --> Security Class Initialized
DEBUG - 2013-03-25 18:15:43 --> Input Class Initialized
DEBUG - 2013-03-25 18:15:43 --> XSS Filtering completed
DEBUG - 2013-03-25 18:15:43 --> XSS Filtering completed
DEBUG - 2013-03-25 18:15:43 --> XSS Filtering completed
DEBUG - 2013-03-25 18:15:43 --> XSS Filtering completed
DEBUG - 2013-03-25 18:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:15:43 --> Language Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Loader Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:15:44 --> Session Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:15:44 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Session routines successfully run
DEBUG - 2013-03-25 18:15:44 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Controller Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: file_helper
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 18:15:44 --> Config Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:15:44 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:15:44 --> URI Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Router Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Output Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Security Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Input Class Initialized
DEBUG - 2013-03-25 18:15:44 --> XSS Filtering completed
DEBUG - 2013-03-25 18:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:15:44 --> Language Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Loader Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:15:44 --> Session Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:15:44 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Session routines successfully run
DEBUG - 2013-03-25 18:15:44 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Controller Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Helper loaded: file_helper
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:44 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 18:15:44 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:15:44 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 18:15:44 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:15:44 --> Final output sent to browser
DEBUG - 2013-03-25 18:15:44 --> Total execution time: 0.0758
DEBUG - 2013-03-25 18:15:47 --> Config Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:15:47 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:15:47 --> URI Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Router Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Output Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Security Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Input Class Initialized
DEBUG - 2013-03-25 18:15:47 --> XSS Filtering completed
DEBUG - 2013-03-25 18:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:15:47 --> Language Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Loader Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:15:47 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:15:47 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:15:47 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:15:47 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:15:47 --> Session Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:15:47 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Session routines successfully run
DEBUG - 2013-03-25 18:15:47 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Controller Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Helper loaded: file_helper
DEBUG - 2013-03-25 18:15:47 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Model Class Initialized
DEBUG - 2013-03-25 18:15:47 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 18:15:47 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:15:47 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 18:15:47 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:15:47 --> Final output sent to browser
DEBUG - 2013-03-25 18:15:47 --> Total execution time: 0.1503
DEBUG - 2013-03-25 18:39:33 --> Config Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:39:33 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:39:33 --> URI Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Router Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Output Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Security Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Input Class Initialized
DEBUG - 2013-03-25 18:39:33 --> XSS Filtering completed
DEBUG - 2013-03-25 18:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:39:33 --> Language Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Loader Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:39:33 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:39:33 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:39:33 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:39:33 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:39:33 --> Session Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:39:33 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Session routines successfully run
DEBUG - 2013-03-25 18:39:33 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Controller Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Model Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Model Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Helper loaded: file_helper
DEBUG - 2013-03-25 18:39:33 --> Model Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Model Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Model Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Model Class Initialized
DEBUG - 2013-03-25 18:39:33 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 18:39:33 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 18:39:33 --> Could not find the language line "voc.i18n_change_password"
ERROR - 2013-03-25 18:39:33 --> Could not find the language line "voc.i18n_change_password"
DEBUG - 2013-03-25 18:39:33 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 18:39:33 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:39:33 --> Final output sent to browser
DEBUG - 2013-03-25 18:39:33 --> Total execution time: 0.0405
DEBUG - 2013-03-25 18:40:24 --> Config Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:40:24 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:40:24 --> URI Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Router Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Output Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Security Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Input Class Initialized
DEBUG - 2013-03-25 18:40:24 --> XSS Filtering completed
DEBUG - 2013-03-25 18:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:40:24 --> Language Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Loader Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:40:24 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:40:24 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:40:24 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:40:24 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:40:24 --> Session Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:40:24 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Session routines successfully run
DEBUG - 2013-03-25 18:40:24 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Controller Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Helper loaded: file_helper
DEBUG - 2013-03-25 18:40:24 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:24 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 18:40:24 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 18:40:24 --> Could not find the language line "voc.i18n_change_password"
ERROR - 2013-03-25 18:40:24 --> Could not find the language line "voc.i18n_change_password"
DEBUG - 2013-03-25 18:40:24 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 18:40:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:40:24 --> Final output sent to browser
DEBUG - 2013-03-25 18:40:24 --> Total execution time: 0.0487
DEBUG - 2013-03-25 18:40:28 --> Config Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:40:28 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:40:28 --> URI Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Router Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Output Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Security Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Input Class Initialized
DEBUG - 2013-03-25 18:40:28 --> XSS Filtering completed
DEBUG - 2013-03-25 18:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:40:28 --> Language Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Loader Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:40:28 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:40:28 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:40:28 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:40:28 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:40:28 --> Session Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:40:28 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Session routines successfully run
DEBUG - 2013-03-25 18:40:28 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Controller Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Helper loaded: file_helper
DEBUG - 2013-03-25 18:40:28 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Model Class Initialized
DEBUG - 2013-03-25 18:40:28 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 18:40:28 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 18:40:28 --> Could not find the language line "voc.i18n_change_password"
ERROR - 2013-03-25 18:40:28 --> Could not find the language line "voc.i18n_change_password"
DEBUG - 2013-03-25 18:40:28 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 18:40:28 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:40:28 --> Final output sent to browser
DEBUG - 2013-03-25 18:40:28 --> Total execution time: 0.0378
DEBUG - 2013-03-25 18:41:12 --> Config Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:41:12 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:41:12 --> URI Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Router Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Output Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Security Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Input Class Initialized
DEBUG - 2013-03-25 18:41:12 --> XSS Filtering completed
DEBUG - 2013-03-25 18:41:12 --> XSS Filtering completed
DEBUG - 2013-03-25 18:41:12 --> XSS Filtering completed
DEBUG - 2013-03-25 18:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:41:12 --> Language Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Loader Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:41:12 --> Session Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:41:12 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Session routines successfully run
DEBUG - 2013-03-25 18:41:12 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Controller Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Model Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Model Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 18:41:12 --> Config Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:41:12 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:41:12 --> URI Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Router Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Output Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Security Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Input Class Initialized
DEBUG - 2013-03-25 18:41:12 --> XSS Filtering completed
DEBUG - 2013-03-25 18:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:41:12 --> Language Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Loader Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:41:12 --> Session Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:41:12 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Session routines successfully run
DEBUG - 2013-03-25 18:41:12 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Controller Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Model Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Model Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Helper loaded: file_helper
DEBUG - 2013-03-25 18:41:12 --> Model Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Model Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Model Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Model Class Initialized
DEBUG - 2013-03-25 18:41:12 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 18:41:12 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:41:12 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 18:41:12 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:41:12 --> Final output sent to browser
DEBUG - 2013-03-25 18:41:12 --> Total execution time: 0.0340
DEBUG - 2013-03-25 18:41:18 --> Config Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:41:18 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:41:18 --> URI Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Router Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Output Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Security Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Input Class Initialized
DEBUG - 2013-03-25 18:41:18 --> XSS Filtering completed
DEBUG - 2013-03-25 18:41:18 --> XSS Filtering completed
DEBUG - 2013-03-25 18:41:18 --> XSS Filtering completed
DEBUG - 2013-03-25 18:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:41:18 --> Language Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Loader Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:41:18 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:41:18 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:41:18 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:41:18 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:41:18 --> Session Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:41:18 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Session routines successfully run
DEBUG - 2013-03-25 18:41:18 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Controller Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Model Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Model Class Initialized
DEBUG - 2013-03-25 18:41:18 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 18:41:18 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 18:41:18 --> Severity: Notice  --> Array to string conversion /opt/lampp/htdocs/cleverfigures/trunk/system/helpers/language_helper.php 49
DEBUG - 2013-03-25 18:41:18 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 18:41:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:41:18 --> Final output sent to browser
DEBUG - 2013-03-25 18:41:18 --> Total execution time: 0.0498
DEBUG - 2013-03-25 18:43:33 --> Config Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:43:33 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:43:33 --> URI Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Router Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Output Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Security Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Input Class Initialized
DEBUG - 2013-03-25 18:43:33 --> XSS Filtering completed
DEBUG - 2013-03-25 18:43:33 --> XSS Filtering completed
DEBUG - 2013-03-25 18:43:33 --> XSS Filtering completed
DEBUG - 2013-03-25 18:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:43:33 --> Language Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Loader Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:43:33 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:43:33 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:43:33 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:43:33 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:43:33 --> Session Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:43:33 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Session routines successfully run
DEBUG - 2013-03-25 18:43:33 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Controller Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Model Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Model Class Initialized
DEBUG - 2013-03-25 18:43:33 --> Language file loaded: language/english/voc_lang.php
ERROR - 2013-03-25 18:43:33 --> Could not find the language line "voc.i18n_change_pasword"
DEBUG - 2013-03-25 18:43:33 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:43:33 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 18:43:33 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:43:33 --> Final output sent to browser
DEBUG - 2013-03-25 18:43:33 --> Total execution time: 0.0492
DEBUG - 2013-03-25 18:45:45 --> Config Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:45:45 --> URI Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Router Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Output Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Security Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Input Class Initialized
DEBUG - 2013-03-25 18:45:45 --> XSS Filtering completed
DEBUG - 2013-03-25 18:45:45 --> XSS Filtering completed
DEBUG - 2013-03-25 18:45:45 --> XSS Filtering completed
DEBUG - 2013-03-25 18:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:45:45 --> Language Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Loader Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:45:45 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:45:45 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:45:45 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:45:45 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:45:45 --> Session Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:45:45 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Session routines successfully run
DEBUG - 2013-03-25 18:45:45 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Controller Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Model Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Model Class Initialized
DEBUG - 2013-03-25 18:45:45 --> Language file loaded: language/english/voc_lang.php
ERROR - 2013-03-25 18:45:45 --> Could not find the language line "voc.i18n_change_pasword"
DEBUG - 2013-03-25 18:45:45 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:45:45 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 18:45:45 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:45:45 --> Final output sent to browser
DEBUG - 2013-03-25 18:45:45 --> Total execution time: 0.0312
DEBUG - 2013-03-25 18:47:30 --> Config Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:47:30 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:47:30 --> URI Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Router Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Output Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Security Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Input Class Initialized
DEBUG - 2013-03-25 18:47:30 --> XSS Filtering completed
DEBUG - 2013-03-25 18:47:30 --> XSS Filtering completed
DEBUG - 2013-03-25 18:47:30 --> XSS Filtering completed
DEBUG - 2013-03-25 18:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:47:30 --> Language Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Loader Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:47:30 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:47:30 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:47:30 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:47:30 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:47:30 --> Session Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:47:30 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Session routines successfully run
DEBUG - 2013-03-25 18:47:30 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Controller Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Model Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Model Class Initialized
DEBUG - 2013-03-25 18:47:30 --> Language file loaded: language/english/voc_lang.php
ERROR - 2013-03-25 18:47:30 --> Could not find the language line "voc.i18n_change_pasword"
DEBUG - 2013-03-25 18:47:30 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:47:30 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 18:47:30 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:47:30 --> Final output sent to browser
DEBUG - 2013-03-25 18:47:30 --> Total execution time: 0.0324
DEBUG - 2013-03-25 18:47:46 --> Config Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:47:46 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:47:46 --> URI Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Router Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Output Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Security Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Input Class Initialized
DEBUG - 2013-03-25 18:47:46 --> XSS Filtering completed
DEBUG - 2013-03-25 18:47:46 --> XSS Filtering completed
DEBUG - 2013-03-25 18:47:46 --> XSS Filtering completed
DEBUG - 2013-03-25 18:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:47:46 --> Language Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Loader Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:47:46 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:47:46 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:47:46 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:47:46 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:47:46 --> Session Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:47:46 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Session routines successfully run
DEBUG - 2013-03-25 18:47:46 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Controller Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Model Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Model Class Initialized
DEBUG - 2013-03-25 18:47:46 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 18:47:46 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:47:46 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 18:47:46 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:47:46 --> Final output sent to browser
DEBUG - 2013-03-25 18:47:46 --> Total execution time: 0.0348
DEBUG - 2013-03-25 18:47:50 --> Config Class Initialized
DEBUG - 2013-03-25 18:47:50 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:47:50 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:47:50 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:47:50 --> URI Class Initialized
DEBUG - 2013-03-25 18:47:50 --> Router Class Initialized
ERROR - 2013-03-25 18:47:50 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 18:47:55 --> Config Class Initialized
DEBUG - 2013-03-25 18:47:55 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:47:55 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:47:55 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:47:55 --> URI Class Initialized
DEBUG - 2013-03-25 18:47:55 --> Router Class Initialized
ERROR - 2013-03-25 18:47:55 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 18:48:31 --> Config Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:48:31 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:48:31 --> URI Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Router Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Output Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Security Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Input Class Initialized
DEBUG - 2013-03-25 18:48:31 --> XSS Filtering completed
DEBUG - 2013-03-25 18:48:31 --> XSS Filtering completed
DEBUG - 2013-03-25 18:48:31 --> XSS Filtering completed
DEBUG - 2013-03-25 18:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:48:31 --> Language Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Loader Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:48:31 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:48:31 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:48:31 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:48:31 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:48:31 --> Session Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:48:31 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Session routines successfully run
DEBUG - 2013-03-25 18:48:31 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Controller Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Model Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Model Class Initialized
DEBUG - 2013-03-25 18:48:31 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 18:48:31 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:48:31 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 18:48:31 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:48:31 --> Final output sent to browser
DEBUG - 2013-03-25 18:48:31 --> Total execution time: 0.0302
DEBUG - 2013-03-25 18:48:33 --> Config Class Initialized
DEBUG - 2013-03-25 18:48:33 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:48:33 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:48:33 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:48:33 --> URI Class Initialized
DEBUG - 2013-03-25 18:48:33 --> Router Class Initialized
ERROR - 2013-03-25 18:48:33 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 18:51:01 --> Config Class Initialized
DEBUG - 2013-03-25 18:51:01 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:51:01 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:51:01 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:51:02 --> URI Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Router Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Output Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Security Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Input Class Initialized
DEBUG - 2013-03-25 18:51:02 --> XSS Filtering completed
DEBUG - 2013-03-25 18:51:02 --> XSS Filtering completed
DEBUG - 2013-03-25 18:51:02 --> XSS Filtering completed
DEBUG - 2013-03-25 18:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:51:02 --> Language Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Loader Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:51:02 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:51:02 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:51:02 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:51:02 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:51:02 --> Session Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:51:02 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Session routines successfully run
DEBUG - 2013-03-25 18:51:02 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Controller Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Model Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Model Class Initialized
DEBUG - 2013-03-25 18:51:02 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 18:51:02 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:51:02 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 18:51:02 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:51:02 --> Final output sent to browser
DEBUG - 2013-03-25 18:51:02 --> Total execution time: 0.0394
DEBUG - 2013-03-25 18:51:04 --> Config Class Initialized
DEBUG - 2013-03-25 18:51:04 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:51:04 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:51:04 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:51:04 --> URI Class Initialized
DEBUG - 2013-03-25 18:51:04 --> Router Class Initialized
ERROR - 2013-03-25 18:51:04 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 18:54:34 --> Config Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:54:34 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:54:34 --> URI Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Router Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Output Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Security Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Input Class Initialized
DEBUG - 2013-03-25 18:54:34 --> XSS Filtering completed
DEBUG - 2013-03-25 18:54:34 --> XSS Filtering completed
DEBUG - 2013-03-25 18:54:34 --> XSS Filtering completed
DEBUG - 2013-03-25 18:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:54:34 --> Language Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Loader Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:54:34 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:54:34 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:54:34 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:54:34 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:54:34 --> Session Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:54:34 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Session routines successfully run
DEBUG - 2013-03-25 18:54:34 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Controller Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Model Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Model Class Initialized
DEBUG - 2013-03-25 18:54:34 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 18:54:34 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:54:34 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 18:54:34 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:54:34 --> Final output sent to browser
DEBUG - 2013-03-25 18:54:34 --> Total execution time: 0.0292
DEBUG - 2013-03-25 18:54:37 --> Config Class Initialized
DEBUG - 2013-03-25 18:54:37 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:54:37 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:54:37 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:54:37 --> URI Class Initialized
DEBUG - 2013-03-25 18:54:37 --> Router Class Initialized
ERROR - 2013-03-25 18:54:37 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 18:54:53 --> Config Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:54:53 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:54:53 --> URI Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Router Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Output Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Security Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Input Class Initialized
DEBUG - 2013-03-25 18:54:53 --> XSS Filtering completed
DEBUG - 2013-03-25 18:54:53 --> XSS Filtering completed
DEBUG - 2013-03-25 18:54:53 --> XSS Filtering completed
DEBUG - 2013-03-25 18:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:54:53 --> Language Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Loader Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:54:53 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:54:53 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:54:53 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:54:53 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:54:53 --> Session Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:54:53 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Session routines successfully run
DEBUG - 2013-03-25 18:54:53 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Controller Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Model Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Model Class Initialized
DEBUG - 2013-03-25 18:54:53 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 18:54:53 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:54:53 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 18:54:53 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:54:53 --> Final output sent to browser
DEBUG - 2013-03-25 18:54:53 --> Total execution time: 0.0368
DEBUG - 2013-03-25 18:54:55 --> Config Class Initialized
DEBUG - 2013-03-25 18:54:55 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:54:55 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:54:55 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:54:55 --> URI Class Initialized
DEBUG - 2013-03-25 18:54:55 --> Router Class Initialized
ERROR - 2013-03-25 18:54:55 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 18:56:58 --> Config Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:56:58 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:56:58 --> URI Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Router Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Output Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Security Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Input Class Initialized
DEBUG - 2013-03-25 18:56:58 --> XSS Filtering completed
DEBUG - 2013-03-25 18:56:58 --> XSS Filtering completed
DEBUG - 2013-03-25 18:56:58 --> XSS Filtering completed
DEBUG - 2013-03-25 18:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 18:56:58 --> Language Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Loader Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Helper loaded: date_helper
DEBUG - 2013-03-25 18:56:58 --> Helper loaded: form_helper
DEBUG - 2013-03-25 18:56:58 --> Helper loaded: language_helper
DEBUG - 2013-03-25 18:56:58 --> Helper loaded: url_helper
DEBUG - 2013-03-25 18:56:58 --> Helper loaded: html_helper
DEBUG - 2013-03-25 18:56:58 --> Session Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Helper loaded: string_helper
DEBUG - 2013-03-25 18:56:58 --> Encrypt Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Session routines successfully run
DEBUG - 2013-03-25 18:56:58 --> Form Validation Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Controller Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Database Driver Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 18:56:58 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 18:56:58 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 18:56:58 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 18:56:58 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 18:56:58 --> Final output sent to browser
DEBUG - 2013-03-25 18:56:58 --> Total execution time: 0.0290
DEBUG - 2013-03-25 18:57:00 --> Config Class Initialized
DEBUG - 2013-03-25 18:57:00 --> Hooks Class Initialized
DEBUG - 2013-03-25 18:57:00 --> Utf8 Class Initialized
DEBUG - 2013-03-25 18:57:00 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 18:57:00 --> URI Class Initialized
DEBUG - 2013-03-25 18:57:00 --> Router Class Initialized
ERROR - 2013-03-25 18:57:00 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 19:00:05 --> Config Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:00:05 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:00:05 --> URI Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Router Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Output Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Security Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Input Class Initialized
DEBUG - 2013-03-25 19:00:05 --> XSS Filtering completed
DEBUG - 2013-03-25 19:00:05 --> XSS Filtering completed
DEBUG - 2013-03-25 19:00:05 --> XSS Filtering completed
DEBUG - 2013-03-25 19:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:00:05 --> Language Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Loader Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:00:05 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:00:05 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:00:05 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:00:05 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:00:05 --> Session Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:00:05 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Session routines successfully run
DEBUG - 2013-03-25 19:00:05 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Controller Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Model Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Model Class Initialized
DEBUG - 2013-03-25 19:00:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:00:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:00:05 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:00:05 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:00:05 --> Final output sent to browser
DEBUG - 2013-03-25 19:00:05 --> Total execution time: 0.0336
DEBUG - 2013-03-25 19:00:07 --> Config Class Initialized
DEBUG - 2013-03-25 19:00:07 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:00:07 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:00:07 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:00:07 --> URI Class Initialized
DEBUG - 2013-03-25 19:00:07 --> Router Class Initialized
ERROR - 2013-03-25 19:00:07 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 19:05:06 --> Config Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:05:06 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:05:06 --> URI Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Router Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Output Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Security Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Input Class Initialized
DEBUG - 2013-03-25 19:05:06 --> XSS Filtering completed
DEBUG - 2013-03-25 19:05:06 --> XSS Filtering completed
DEBUG - 2013-03-25 19:05:06 --> XSS Filtering completed
DEBUG - 2013-03-25 19:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:05:06 --> Language Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Loader Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:05:06 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:05:06 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:05:06 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:05:06 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:05:06 --> Session Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:05:06 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Session routines successfully run
DEBUG - 2013-03-25 19:05:06 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Controller Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Model Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Model Class Initialized
DEBUG - 2013-03-25 19:05:06 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:05:06 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:05:06 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:05:06 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:05:06 --> Final output sent to browser
DEBUG - 2013-03-25 19:05:06 --> Total execution time: 0.0325
DEBUG - 2013-03-25 19:05:09 --> Config Class Initialized
DEBUG - 2013-03-25 19:05:09 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:05:09 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:05:09 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:05:09 --> URI Class Initialized
DEBUG - 2013-03-25 19:05:09 --> Router Class Initialized
ERROR - 2013-03-25 19:05:09 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 19:05:41 --> Config Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:05:41 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:05:41 --> URI Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Router Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Output Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Security Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Input Class Initialized
DEBUG - 2013-03-25 19:05:41 --> XSS Filtering completed
DEBUG - 2013-03-25 19:05:41 --> XSS Filtering completed
DEBUG - 2013-03-25 19:05:41 --> XSS Filtering completed
DEBUG - 2013-03-25 19:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:05:41 --> Language Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Loader Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:05:41 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:05:41 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:05:41 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:05:41 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:05:41 --> Session Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:05:41 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Session routines successfully run
DEBUG - 2013-03-25 19:05:41 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Controller Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Model Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Model Class Initialized
DEBUG - 2013-03-25 19:05:41 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:05:41 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:05:41 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:05:41 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:05:41 --> Final output sent to browser
DEBUG - 2013-03-25 19:05:41 --> Total execution time: 0.0309
DEBUG - 2013-03-25 19:05:43 --> Config Class Initialized
DEBUG - 2013-03-25 19:05:43 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:05:43 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:05:43 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:05:43 --> URI Class Initialized
DEBUG - 2013-03-25 19:05:43 --> Router Class Initialized
ERROR - 2013-03-25 19:05:43 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 19:06:14 --> Config Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:06:14 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:06:14 --> URI Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Router Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Output Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Security Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Input Class Initialized
DEBUG - 2013-03-25 19:06:14 --> XSS Filtering completed
DEBUG - 2013-03-25 19:06:14 --> XSS Filtering completed
DEBUG - 2013-03-25 19:06:14 --> XSS Filtering completed
DEBUG - 2013-03-25 19:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:06:14 --> Language Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Loader Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:06:14 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:06:14 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:06:14 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:06:14 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:06:14 --> Session Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:06:14 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Session routines successfully run
DEBUG - 2013-03-25 19:06:14 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Controller Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Model Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Model Class Initialized
DEBUG - 2013-03-25 19:06:14 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:06:14 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:06:14 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:06:14 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:06:14 --> Final output sent to browser
DEBUG - 2013-03-25 19:06:14 --> Total execution time: 0.0293
DEBUG - 2013-03-25 19:06:17 --> Config Class Initialized
DEBUG - 2013-03-25 19:06:17 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:06:17 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:06:17 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:06:17 --> URI Class Initialized
DEBUG - 2013-03-25 19:06:17 --> Router Class Initialized
ERROR - 2013-03-25 19:06:17 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 19:06:34 --> Config Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:06:34 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:06:34 --> URI Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Router Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Output Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Security Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Input Class Initialized
DEBUG - 2013-03-25 19:06:34 --> XSS Filtering completed
DEBUG - 2013-03-25 19:06:34 --> XSS Filtering completed
DEBUG - 2013-03-25 19:06:34 --> XSS Filtering completed
DEBUG - 2013-03-25 19:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:06:34 --> Language Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Loader Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:06:34 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:06:34 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:06:34 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:06:34 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:06:34 --> Session Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:06:34 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Session routines successfully run
DEBUG - 2013-03-25 19:06:34 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Controller Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Model Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Model Class Initialized
DEBUG - 2013-03-25 19:06:34 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:06:34 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:06:34 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:06:34 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:06:34 --> Final output sent to browser
DEBUG - 2013-03-25 19:06:34 --> Total execution time: 0.0298
DEBUG - 2013-03-25 19:06:37 --> Config Class Initialized
DEBUG - 2013-03-25 19:06:37 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:06:37 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:06:37 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:06:37 --> URI Class Initialized
DEBUG - 2013-03-25 19:06:37 --> Router Class Initialized
ERROR - 2013-03-25 19:06:37 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 19:07:26 --> Config Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:07:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:07:26 --> URI Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Router Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Output Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Security Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Input Class Initialized
DEBUG - 2013-03-25 19:07:26 --> XSS Filtering completed
DEBUG - 2013-03-25 19:07:26 --> XSS Filtering completed
DEBUG - 2013-03-25 19:07:26 --> XSS Filtering completed
DEBUG - 2013-03-25 19:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:07:26 --> Language Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Loader Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:07:26 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:07:26 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:07:26 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:07:26 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:07:26 --> Session Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:07:26 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Session routines successfully run
DEBUG - 2013-03-25 19:07:26 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Controller Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Model Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Model Class Initialized
DEBUG - 2013-03-25 19:07:26 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:07:26 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:07:26 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:07:26 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:07:26 --> Final output sent to browser
DEBUG - 2013-03-25 19:07:26 --> Total execution time: 0.0420
DEBUG - 2013-03-25 19:07:29 --> Config Class Initialized
DEBUG - 2013-03-25 19:07:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:07:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:07:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:07:29 --> URI Class Initialized
DEBUG - 2013-03-25 19:07:29 --> Router Class Initialized
ERROR - 2013-03-25 19:07:29 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 19:11:41 --> Config Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:11:41 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:11:41 --> URI Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Router Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Output Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Security Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Input Class Initialized
DEBUG - 2013-03-25 19:11:41 --> XSS Filtering completed
DEBUG - 2013-03-25 19:11:41 --> XSS Filtering completed
DEBUG - 2013-03-25 19:11:41 --> XSS Filtering completed
DEBUG - 2013-03-25 19:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:11:41 --> Language Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Loader Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:11:41 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:11:41 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:11:41 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:11:41 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:11:41 --> Session Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:11:41 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Session routines successfully run
DEBUG - 2013-03-25 19:11:41 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Controller Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Model Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Model Class Initialized
DEBUG - 2013-03-25 19:11:41 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:11:41 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:11:41 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:11:41 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:11:41 --> Final output sent to browser
DEBUG - 2013-03-25 19:11:41 --> Total execution time: 0.0286
DEBUG - 2013-03-25 19:11:43 --> Config Class Initialized
DEBUG - 2013-03-25 19:11:43 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:11:43 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:11:43 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:11:43 --> URI Class Initialized
DEBUG - 2013-03-25 19:11:43 --> Router Class Initialized
ERROR - 2013-03-25 19:11:43 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 19:12:59 --> Config Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:12:59 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:12:59 --> URI Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Router Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Output Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Security Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Input Class Initialized
DEBUG - 2013-03-25 19:12:59 --> XSS Filtering completed
DEBUG - 2013-03-25 19:12:59 --> XSS Filtering completed
DEBUG - 2013-03-25 19:12:59 --> XSS Filtering completed
DEBUG - 2013-03-25 19:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:12:59 --> Language Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Loader Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:12:59 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:12:59 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:12:59 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:12:59 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:12:59 --> Session Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:12:59 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Session routines successfully run
DEBUG - 2013-03-25 19:12:59 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Controller Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Model Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Model Class Initialized
DEBUG - 2013-03-25 19:12:59 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:12:59 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:12:59 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:12:59 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:12:59 --> Final output sent to browser
DEBUG - 2013-03-25 19:12:59 --> Total execution time: 0.0273
DEBUG - 2013-03-25 19:13:02 --> Config Class Initialized
DEBUG - 2013-03-25 19:13:02 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:13:02 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:13:02 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:13:02 --> URI Class Initialized
DEBUG - 2013-03-25 19:13:02 --> Router Class Initialized
ERROR - 2013-03-25 19:13:02 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 19:13:24 --> Config Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:13:24 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:13:24 --> URI Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Router Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Output Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Security Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Input Class Initialized
DEBUG - 2013-03-25 19:13:24 --> XSS Filtering completed
DEBUG - 2013-03-25 19:13:24 --> XSS Filtering completed
DEBUG - 2013-03-25 19:13:24 --> XSS Filtering completed
DEBUG - 2013-03-25 19:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:13:24 --> Language Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Loader Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:13:24 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:13:24 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:13:24 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:13:24 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:13:24 --> Session Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:13:24 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Session routines successfully run
DEBUG - 2013-03-25 19:13:24 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Controller Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Model Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Model Class Initialized
DEBUG - 2013-03-25 19:13:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:13:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:13:24 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:13:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:13:24 --> Final output sent to browser
DEBUG - 2013-03-25 19:13:24 --> Total execution time: 0.0287
DEBUG - 2013-03-25 19:13:26 --> Config Class Initialized
DEBUG - 2013-03-25 19:13:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:13:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:13:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:13:26 --> URI Class Initialized
DEBUG - 2013-03-25 19:13:26 --> Router Class Initialized
ERROR - 2013-03-25 19:13:26 --> 404 Page Not Found --> password_change
DEBUG - 2013-03-25 19:15:15 --> Config Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:15:15 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:15:15 --> URI Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Router Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Output Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Security Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Input Class Initialized
DEBUG - 2013-03-25 19:15:15 --> XSS Filtering completed
DEBUG - 2013-03-25 19:15:15 --> XSS Filtering completed
DEBUG - 2013-03-25 19:15:15 --> XSS Filtering completed
DEBUG - 2013-03-25 19:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:15:15 --> Language Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Loader Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:15:15 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:15:15 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:15:15 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:15:15 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:15:15 --> Session Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:15:15 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Session routines successfully run
DEBUG - 2013-03-25 19:15:15 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Controller Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Model Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Model Class Initialized
DEBUG - 2013-03-25 19:15:15 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:15:15 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:15:15 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:15:15 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:15:15 --> Final output sent to browser
DEBUG - 2013-03-25 19:15:15 --> Total execution time: 0.0270
DEBUG - 2013-03-25 19:15:57 --> Config Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:15:57 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:15:57 --> URI Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Router Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Output Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Security Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Input Class Initialized
DEBUG - 2013-03-25 19:15:57 --> XSS Filtering completed
DEBUG - 2013-03-25 19:15:57 --> XSS Filtering completed
DEBUG - 2013-03-25 19:15:57 --> XSS Filtering completed
DEBUG - 2013-03-25 19:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:15:57 --> Language Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Loader Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:15:57 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:15:57 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:15:57 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:15:57 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:15:57 --> Session Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:15:57 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Session routines successfully run
DEBUG - 2013-03-25 19:15:57 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Controller Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Model Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Model Class Initialized
DEBUG - 2013-03-25 19:15:57 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:15:57 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:15:57 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:15:57 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:15:57 --> Final output sent to browser
DEBUG - 2013-03-25 19:15:57 --> Total execution time: 0.0306
DEBUG - 2013-03-25 19:23:17 --> Config Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:23:17 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:23:17 --> URI Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Router Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Output Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Security Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Input Class Initialized
DEBUG - 2013-03-25 19:23:17 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:23:17 --> Language Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Loader Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:23:17 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:23:17 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:23:17 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:23:17 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:23:17 --> Session Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:23:17 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Session routines successfully run
DEBUG - 2013-03-25 19:23:17 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Controller Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:23:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:17 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:23:17 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:23:17 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 19:23:17 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:23:17 --> Final output sent to browser
DEBUG - 2013-03-25 19:23:17 --> Total execution time: 0.0439
DEBUG - 2013-03-25 19:23:18 --> Config Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:23:18 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:23:18 --> URI Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Router Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Output Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Security Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Input Class Initialized
DEBUG - 2013-03-25 19:23:18 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:18 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:18 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:23:18 --> Language Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Loader Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:23:18 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:23:18 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:23:18 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:23:18 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:23:18 --> Session Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:23:18 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Session routines successfully run
DEBUG - 2013-03-25 19:23:18 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Controller Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:18 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:23:18 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:23:18 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:23:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:23:18 --> Final output sent to browser
DEBUG - 2013-03-25 19:23:18 --> Total execution time: 0.0278
DEBUG - 2013-03-25 19:23:28 --> Config Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:23:28 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:23:28 --> URI Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Router Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Output Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Security Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Input Class Initialized
DEBUG - 2013-03-25 19:23:28 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:28 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:28 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:28 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:23:28 --> Language Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Loader Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:23:28 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:23:28 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:23:28 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:23:28 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:23:28 --> Session Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:23:28 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Session routines successfully run
DEBUG - 2013-03-25 19:23:28 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Controller Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:23:28 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:23:28 --> Final output sent to browser
DEBUG - 2013-03-25 19:23:28 --> Total execution time: 0.0570
DEBUG - 2013-03-25 19:23:38 --> Config Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:23:38 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:23:38 --> URI Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Router Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Output Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Security Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Input Class Initialized
DEBUG - 2013-03-25 19:23:38 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:23:38 --> Language Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Loader Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:23:38 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:23:38 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:23:38 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:23:38 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:23:38 --> Session Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:23:38 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Session routines successfully run
DEBUG - 2013-03-25 19:23:38 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Controller Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:23:38 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:38 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:23:38 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:23:38 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 19:23:38 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:23:38 --> Final output sent to browser
DEBUG - 2013-03-25 19:23:38 --> Total execution time: 0.0365
DEBUG - 2013-03-25 19:23:41 --> Config Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:23:41 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:23:41 --> URI Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Router Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Output Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Security Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Input Class Initialized
DEBUG - 2013-03-25 19:23:41 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:23:41 --> Language Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Loader Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:23:41 --> Session Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:23:41 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Session routines successfully run
DEBUG - 2013-03-25 19:23:41 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Controller Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:23:41 --> Config Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:23:41 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:23:41 --> URI Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Router Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Output Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Security Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Input Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:23:41 --> Language Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Loader Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:23:41 --> Session Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:23:41 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:23:41 --> A session cookie was not found.
DEBUG - 2013-03-25 19:23:41 --> Session routines successfully run
DEBUG - 2013-03-25 19:23:41 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Controller Class Initialized
DEBUG - 2013-03-25 19:23:41 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 19:23:41 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:23:41 --> File loaded: application/views/content/login_view.php
DEBUG - 2013-03-25 19:23:41 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:23:41 --> Final output sent to browser
DEBUG - 2013-03-25 19:23:41 --> Total execution time: 0.0240
DEBUG - 2013-03-25 19:23:46 --> Config Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:23:46 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:23:46 --> URI Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Router Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Output Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Security Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Input Class Initialized
DEBUG - 2013-03-25 19:23:46 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:46 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:46 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:46 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:23:46 --> Language Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Loader Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:23:46 --> Session Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:23:46 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Session routines successfully run
DEBUG - 2013-03-25 19:23:46 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Controller Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 19:23:46 --> Config Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:23:46 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:23:46 --> URI Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Router Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Output Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Security Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Input Class Initialized
DEBUG - 2013-03-25 19:23:46 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:23:46 --> Language Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Loader Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:23:46 --> Session Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:23:46 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Session routines successfully run
DEBUG - 2013-03-25 19:23:46 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Controller Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:46 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:23:46 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:23:46 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 19:23:46 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:23:46 --> Final output sent to browser
DEBUG - 2013-03-25 19:23:46 --> Total execution time: 0.0322
DEBUG - 2013-03-25 19:23:49 --> Config Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:23:49 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:23:49 --> URI Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Router Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Output Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Security Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Input Class Initialized
DEBUG - 2013-03-25 19:23:49 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:23:49 --> Language Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Loader Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:23:49 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:23:49 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:23:49 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:23:49 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:23:49 --> Session Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:23:49 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Session routines successfully run
DEBUG - 2013-03-25 19:23:49 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Controller Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:23:49 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:49 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:23:49 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:23:49 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 19:23:49 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:23:49 --> Final output sent to browser
DEBUG - 2013-03-25 19:23:49 --> Total execution time: 0.0330
DEBUG - 2013-03-25 19:23:50 --> Config Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:23:50 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:23:50 --> URI Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Router Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Output Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Security Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Input Class Initialized
DEBUG - 2013-03-25 19:23:50 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:50 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:50 --> XSS Filtering completed
DEBUG - 2013-03-25 19:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:23:50 --> Language Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Loader Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:23:50 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:23:50 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:23:50 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:23:50 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:23:50 --> Session Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:23:50 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Session routines successfully run
DEBUG - 2013-03-25 19:23:50 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Controller Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Model Class Initialized
DEBUG - 2013-03-25 19:23:50 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:23:50 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:23:50 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:23:50 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:23:50 --> Final output sent to browser
DEBUG - 2013-03-25 19:23:50 --> Total execution time: 0.0267
DEBUG - 2013-03-25 19:28:47 --> Config Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:28:47 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:28:47 --> URI Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Router Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Output Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Security Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Input Class Initialized
DEBUG - 2013-03-25 19:28:47 --> XSS Filtering completed
DEBUG - 2013-03-25 19:28:47 --> XSS Filtering completed
DEBUG - 2013-03-25 19:28:47 --> XSS Filtering completed
DEBUG - 2013-03-25 19:28:47 --> XSS Filtering completed
DEBUG - 2013-03-25 19:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:28:47 --> Language Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Loader Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:28:47 --> Session Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:28:47 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Session routines successfully run
DEBUG - 2013-03-25 19:28:47 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Controller Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Model Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Model Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:28:47 --> Config Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:28:47 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:28:47 --> URI Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Router Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Output Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Security Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Input Class Initialized
DEBUG - 2013-03-25 19:28:47 --> XSS Filtering completed
DEBUG - 2013-03-25 19:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:28:47 --> Language Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Loader Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:28:47 --> Session Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:28:47 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Session routines successfully run
DEBUG - 2013-03-25 19:28:47 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Controller Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Model Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Model Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:28:47 --> Model Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Model Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Model Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Model Class Initialized
DEBUG - 2013-03-25 19:28:47 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:28:47 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:28:47 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 19:28:47 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:28:47 --> Final output sent to browser
DEBUG - 2013-03-25 19:28:47 --> Total execution time: 0.0414
DEBUG - 2013-03-25 19:29:32 --> Config Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:29:32 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:29:32 --> URI Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Router Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Output Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Security Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Input Class Initialized
DEBUG - 2013-03-25 19:29:32 --> XSS Filtering completed
DEBUG - 2013-03-25 19:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:29:32 --> Language Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Loader Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:29:32 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:29:32 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:29:32 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:29:32 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:29:32 --> Session Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:29:32 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Session routines successfully run
DEBUG - 2013-03-25 19:29:32 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Controller Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:29:32 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:32 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:29:32 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:29:32 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 19:29:32 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:29:32 --> Final output sent to browser
DEBUG - 2013-03-25 19:29:32 --> Total execution time: 0.0367
DEBUG - 2013-03-25 19:29:35 --> Config Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:29:35 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:29:35 --> URI Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Router Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Output Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Security Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Input Class Initialized
DEBUG - 2013-03-25 19:29:35 --> XSS Filtering completed
DEBUG - 2013-03-25 19:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:29:35 --> Language Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Loader Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:29:35 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:29:35 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:29:35 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:29:35 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:29:35 --> Session Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:29:35 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Session routines successfully run
DEBUG - 2013-03-25 19:29:35 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Controller Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:29:35 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:35 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:29:35 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:29:35 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 19:29:35 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:29:35 --> Final output sent to browser
DEBUG - 2013-03-25 19:29:35 --> Total execution time: 0.0429
DEBUG - 2013-03-25 19:29:39 --> Config Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:29:39 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:29:39 --> URI Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Router Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Output Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Security Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Input Class Initialized
DEBUG - 2013-03-25 19:29:39 --> XSS Filtering completed
DEBUG - 2013-03-25 19:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:29:39 --> Language Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Loader Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:29:39 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:29:39 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:29:39 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:29:39 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:29:39 --> Session Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:29:39 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Session routines successfully run
DEBUG - 2013-03-25 19:29:39 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Controller Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Model Class Initialized
DEBUG - 2013-03-25 19:29:39 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:29:39 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:29:39 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:29:39 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:29:39 --> Final output sent to browser
DEBUG - 2013-03-25 19:29:39 --> Total execution time: 0.1295
DEBUG - 2013-03-25 19:31:02 --> Config Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:31:02 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:31:02 --> URI Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Router Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Output Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Security Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Input Class Initialized
DEBUG - 2013-03-25 19:31:02 --> XSS Filtering completed
DEBUG - 2013-03-25 19:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:31:02 --> Language Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Loader Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:31:02 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:31:02 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:31:02 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:31:02 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:31:02 --> Session Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:31:02 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Session routines successfully run
DEBUG - 2013-03-25 19:31:02 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Controller Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:31:02 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:02 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:31:02 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:31:02 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 19:31:02 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:31:02 --> Final output sent to browser
DEBUG - 2013-03-25 19:31:02 --> Total execution time: 0.0391
DEBUG - 2013-03-25 19:31:03 --> Config Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:31:03 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:31:03 --> URI Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Router Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Output Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Security Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Input Class Initialized
DEBUG - 2013-03-25 19:31:03 --> XSS Filtering completed
DEBUG - 2013-03-25 19:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:31:03 --> Language Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Loader Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:31:03 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:31:03 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:31:03 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:31:03 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:31:03 --> Session Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:31:03 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Session routines successfully run
DEBUG - 2013-03-25 19:31:03 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Controller Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:31:03 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:03 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:31:03 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:31:03 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 19:31:03 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:31:03 --> Final output sent to browser
DEBUG - 2013-03-25 19:31:03 --> Total execution time: 0.0330
DEBUG - 2013-03-25 19:31:05 --> Config Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:31:05 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:31:05 --> URI Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Router Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Output Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Security Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Input Class Initialized
DEBUG - 2013-03-25 19:31:05 --> XSS Filtering completed
DEBUG - 2013-03-25 19:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:31:05 --> Language Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Loader Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:31:05 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:31:05 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:31:05 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:31:05 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:31:05 --> Session Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:31:05 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Session routines successfully run
DEBUG - 2013-03-25 19:31:05 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Controller Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:31:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:31:05 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:31:05 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:31:05 --> Final output sent to browser
DEBUG - 2013-03-25 19:31:05 --> Total execution time: 0.0513
DEBUG - 2013-03-25 19:31:09 --> Config Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:31:09 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:31:09 --> URI Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Router Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Output Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Security Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Input Class Initialized
DEBUG - 2013-03-25 19:31:09 --> XSS Filtering completed
DEBUG - 2013-03-25 19:31:09 --> XSS Filtering completed
DEBUG - 2013-03-25 19:31:09 --> XSS Filtering completed
DEBUG - 2013-03-25 19:31:09 --> XSS Filtering completed
DEBUG - 2013-03-25 19:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:31:09 --> Language Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Loader Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:31:09 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:31:09 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:31:09 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:31:09 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:31:09 --> Session Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:31:09 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Session routines successfully run
DEBUG - 2013-03-25 19:31:09 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Controller Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:31:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:09 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:31:17 --> Config Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:31:17 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:31:17 --> URI Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Router Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Output Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Security Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Input Class Initialized
DEBUG - 2013-03-25 19:31:17 --> XSS Filtering completed
DEBUG - 2013-03-25 19:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:31:17 --> Language Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Loader Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:31:17 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:31:17 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:31:17 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:31:17 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:31:17 --> Session Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:31:17 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Session routines successfully run
DEBUG - 2013-03-25 19:31:17 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Controller Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:31:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:17 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:31:17 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:31:17 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 19:31:17 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:31:17 --> Final output sent to browser
DEBUG - 2013-03-25 19:31:17 --> Total execution time: 0.0505
DEBUG - 2013-03-25 19:31:18 --> Config Class Initialized
DEBUG - 2013-03-25 19:31:18 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:31:18 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:31:18 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:31:18 --> URI Class Initialized
DEBUG - 2013-03-25 19:31:18 --> Router Class Initialized
DEBUG - 2013-03-25 19:31:18 --> Output Class Initialized
DEBUG - 2013-03-25 19:31:18 --> Security Class Initialized
DEBUG - 2013-03-25 19:31:18 --> Input Class Initialized
DEBUG - 2013-03-25 19:31:18 --> XSS Filtering completed
DEBUG - 2013-03-25 19:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:31:18 --> Language Class Initialized
DEBUG - 2013-03-25 19:31:18 --> Loader Class Initialized
DEBUG - 2013-03-25 19:31:18 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:31:18 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:31:18 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:31:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:31:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:31:19 --> Session Class Initialized
DEBUG - 2013-03-25 19:31:19 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:31:19 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:31:19 --> Session routines successfully run
DEBUG - 2013-03-25 19:31:19 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:31:19 --> Controller Class Initialized
DEBUG - 2013-03-25 19:31:19 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:19 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:19 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:31:19 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:19 --> Model Class Initialized
DEBUG - 2013-03-25 19:31:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:31:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:31:19 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:31:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:31:19 --> Final output sent to browser
DEBUG - 2013-03-25 19:31:19 --> Total execution time: 0.0399
DEBUG - 2013-03-25 19:36:17 --> Config Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:36:17 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:36:17 --> URI Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Router Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Output Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Security Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Input Class Initialized
DEBUG - 2013-03-25 19:36:17 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:36:17 --> Language Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Loader Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:36:17 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:36:17 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:36:17 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:36:17 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:36:17 --> Session Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:36:17 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Session routines successfully run
DEBUG - 2013-03-25 19:36:17 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Controller Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:17 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:36:17 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:36:17 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:36:17 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:36:17 --> Final output sent to browser
DEBUG - 2013-03-25 19:36:17 --> Total execution time: 0.0311
DEBUG - 2013-03-25 19:36:20 --> Config Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:36:20 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:36:20 --> URI Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Router Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Output Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Security Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Input Class Initialized
DEBUG - 2013-03-25 19:36:20 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:20 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:20 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:20 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:36:20 --> Language Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Loader Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:36:20 --> Session Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:36:20 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Session routines successfully run
DEBUG - 2013-03-25 19:36:20 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Controller Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:36:20 --> Config Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:36:20 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:36:20 --> URI Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Router Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Output Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Security Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Input Class Initialized
DEBUG - 2013-03-25 19:36:20 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:36:20 --> Language Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Loader Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:36:20 --> Session Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:36:20 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Session routines successfully run
DEBUG - 2013-03-25 19:36:20 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Controller Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:36:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:36:20 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:36:20 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:36:20 --> Final output sent to browser
DEBUG - 2013-03-25 19:36:20 --> Total execution time: 0.0453
DEBUG - 2013-03-25 19:36:22 --> Config Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:36:22 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:36:22 --> URI Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Router Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Output Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Security Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Input Class Initialized
DEBUG - 2013-03-25 19:36:22 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:22 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:22 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:22 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:36:22 --> Language Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Loader Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:36:22 --> Session Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:36:22 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Session routines successfully run
DEBUG - 2013-03-25 19:36:22 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Controller Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:36:22 --> Config Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:36:22 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:36:22 --> URI Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Router Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Output Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Security Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Input Class Initialized
DEBUG - 2013-03-25 19:36:22 --> XSS Filtering completed
DEBUG - 2013-03-25 19:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:36:22 --> Language Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Loader Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:36:22 --> Session Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:36:22 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Session routines successfully run
DEBUG - 2013-03-25 19:36:22 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Controller Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Model Class Initialized
DEBUG - 2013-03-25 19:36:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:36:22 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:36:22 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:36:22 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:36:22 --> Final output sent to browser
DEBUG - 2013-03-25 19:36:22 --> Total execution time: 0.0810
DEBUG - 2013-03-25 19:41:45 --> Config Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:41:45 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:41:45 --> URI Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Router Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Output Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Security Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Input Class Initialized
DEBUG - 2013-03-25 19:41:45 --> XSS Filtering completed
DEBUG - 2013-03-25 19:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:41:45 --> Language Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Loader Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:41:45 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:41:45 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:41:45 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:41:45 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:41:45 --> Session Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:41:45 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Session routines successfully run
DEBUG - 2013-03-25 19:41:45 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Controller Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:45 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:41:45 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:41:45 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:41:45 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:41:45 --> Final output sent to browser
DEBUG - 2013-03-25 19:41:45 --> Total execution time: 0.0474
DEBUG - 2013-03-25 19:41:48 --> Config Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:41:48 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:41:48 --> URI Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Router Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Output Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Security Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Input Class Initialized
DEBUG - 2013-03-25 19:41:48 --> XSS Filtering completed
DEBUG - 2013-03-25 19:41:48 --> XSS Filtering completed
DEBUG - 2013-03-25 19:41:48 --> XSS Filtering completed
DEBUG - 2013-03-25 19:41:48 --> XSS Filtering completed
DEBUG - 2013-03-25 19:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:41:48 --> Language Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Loader Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:41:48 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:41:48 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:41:48 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:41:48 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:41:48 --> Session Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:41:48 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Session routines successfully run
DEBUG - 2013-03-25 19:41:48 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Controller Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:41:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:41:48 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:41:48 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:41:48 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 19:44:09 --> Config Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:44:09 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:44:09 --> URI Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Router Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Output Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Security Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Input Class Initialized
DEBUG - 2013-03-25 19:44:09 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:09 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:09 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:09 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:44:09 --> Language Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Loader Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:44:09 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:44:09 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:44:09 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:44:09 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:44:09 --> Session Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:44:09 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Session routines successfully run
DEBUG - 2013-03-25 19:44:09 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Controller Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:44:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:09 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:44:09 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:44:09 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 19:44:14 --> Config Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:44:14 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:44:14 --> URI Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Router Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Output Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Security Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Input Class Initialized
DEBUG - 2013-03-25 19:44:14 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:44:14 --> Language Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Loader Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:44:14 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:44:14 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:44:14 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:44:14 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:44:14 --> Session Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:44:14 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Session routines successfully run
DEBUG - 2013-03-25 19:44:14 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Controller Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:14 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:44:14 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:44:14 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:44:14 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:44:14 --> Final output sent to browser
DEBUG - 2013-03-25 19:44:14 --> Total execution time: 0.0353
DEBUG - 2013-03-25 19:44:15 --> Config Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:44:15 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:44:15 --> URI Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Router Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Output Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Security Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Input Class Initialized
DEBUG - 2013-03-25 19:44:15 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:15 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:15 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:15 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:44:15 --> Language Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Loader Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:44:15 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:44:15 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:44:15 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:44:15 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:44:15 --> Session Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:44:15 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Session routines successfully run
DEBUG - 2013-03-25 19:44:15 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Controller Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:44:15 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:15 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:44:15 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:44:15 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 19:44:17 --> Config Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:44:17 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:44:17 --> URI Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Router Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Output Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Security Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Input Class Initialized
DEBUG - 2013-03-25 19:44:17 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:44:17 --> Language Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Loader Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:44:17 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:44:17 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:44:17 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:44:17 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:44:17 --> Session Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:44:17 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Session routines successfully run
DEBUG - 2013-03-25 19:44:17 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Controller Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:44:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:17 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:44:17 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:44:17 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 19:44:17 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:44:17 --> Final output sent to browser
DEBUG - 2013-03-25 19:44:17 --> Total execution time: 0.0519
DEBUG - 2013-03-25 19:44:18 --> Config Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:44:18 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:44:18 --> URI Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Router Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Output Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Security Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Input Class Initialized
DEBUG - 2013-03-25 19:44:18 --> XSS Filtering completed
DEBUG - 2013-03-25 19:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:44:18 --> Language Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Loader Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:44:18 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:44:18 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:44:18 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:44:18 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:44:18 --> Session Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:44:18 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Session routines successfully run
DEBUG - 2013-03-25 19:44:18 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Controller Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Model Class Initialized
DEBUG - 2013-03-25 19:44:18 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:44:18 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:44:18 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:44:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:44:19 --> Final output sent to browser
DEBUG - 2013-03-25 19:44:19 --> Total execution time: 0.0365
DEBUG - 2013-03-25 19:49:55 --> Config Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:49:55 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:49:55 --> URI Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Router Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Output Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Security Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Input Class Initialized
DEBUG - 2013-03-25 19:49:55 --> XSS Filtering completed
DEBUG - 2013-03-25 19:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:49:55 --> Language Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Loader Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:49:55 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:49:55 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:49:55 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:49:55 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:49:55 --> Session Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:49:55 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Session routines successfully run
DEBUG - 2013-03-25 19:49:55 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Controller Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:55 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:49:55 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:49:55 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:49:55 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:49:55 --> Final output sent to browser
DEBUG - 2013-03-25 19:49:55 --> Total execution time: 0.0408
DEBUG - 2013-03-25 19:49:56 --> Config Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:49:56 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:49:56 --> URI Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Router Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Output Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Security Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Input Class Initialized
DEBUG - 2013-03-25 19:49:56 --> XSS Filtering completed
DEBUG - 2013-03-25 19:49:56 --> XSS Filtering completed
DEBUG - 2013-03-25 19:49:56 --> XSS Filtering completed
DEBUG - 2013-03-25 19:49:56 --> XSS Filtering completed
DEBUG - 2013-03-25 19:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:49:56 --> Language Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Loader Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:49:56 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:49:56 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:49:56 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:49:56 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:49:56 --> Session Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:49:56 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Session routines successfully run
DEBUG - 2013-03-25 19:49:56 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Controller Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:49:56 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Model Class Initialized
DEBUG - 2013-03-25 19:49:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:49:56 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:49:56 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 19:51:07 --> Config Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:51:07 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:51:07 --> URI Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Router Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Output Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Security Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Input Class Initialized
DEBUG - 2013-03-25 19:51:07 --> XSS Filtering completed
DEBUG - 2013-03-25 19:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:51:07 --> Language Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Loader Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:51:07 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:51:07 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:51:07 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:51:07 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:51:07 --> Session Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:51:07 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Session routines successfully run
DEBUG - 2013-03-25 19:51:07 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Controller Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:07 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:51:07 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:51:07 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:51:07 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:51:07 --> Final output sent to browser
DEBUG - 2013-03-25 19:51:07 --> Total execution time: 0.0408
DEBUG - 2013-03-25 19:51:08 --> Config Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:51:08 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:51:08 --> URI Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Router Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Output Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Security Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Input Class Initialized
DEBUG - 2013-03-25 19:51:08 --> XSS Filtering completed
DEBUG - 2013-03-25 19:51:08 --> XSS Filtering completed
DEBUG - 2013-03-25 19:51:08 --> XSS Filtering completed
DEBUG - 2013-03-25 19:51:08 --> XSS Filtering completed
DEBUG - 2013-03-25 19:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:51:08 --> Language Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Loader Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:51:08 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:51:08 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:51:08 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:51:08 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:51:08 --> Session Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:51:08 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Session routines successfully run
DEBUG - 2013-03-25 19:51:08 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Controller Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:51:08 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Model Class Initialized
DEBUG - 2013-03-25 19:51:08 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:51:08 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:51:08 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 19:53:34 --> Config Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:53:34 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:53:34 --> URI Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Router Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Output Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Security Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Input Class Initialized
DEBUG - 2013-03-25 19:53:34 --> XSS Filtering completed
DEBUG - 2013-03-25 19:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:53:34 --> Language Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Loader Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:53:34 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:53:34 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:53:34 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:53:34 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:53:34 --> Session Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:53:34 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Session routines successfully run
DEBUG - 2013-03-25 19:53:34 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Controller Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:34 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:53:34 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:53:34 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:53:34 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:53:34 --> Final output sent to browser
DEBUG - 2013-03-25 19:53:34 --> Total execution time: 0.0394
DEBUG - 2013-03-25 19:53:36 --> Config Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:53:36 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:53:36 --> URI Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Router Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Output Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Security Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Input Class Initialized
DEBUG - 2013-03-25 19:53:36 --> XSS Filtering completed
DEBUG - 2013-03-25 19:53:36 --> XSS Filtering completed
DEBUG - 2013-03-25 19:53:36 --> XSS Filtering completed
DEBUG - 2013-03-25 19:53:36 --> XSS Filtering completed
DEBUG - 2013-03-25 19:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:53:36 --> Language Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Loader Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:53:36 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:53:36 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:53:36 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:53:36 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:53:36 --> Session Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:53:36 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Session routines successfully run
DEBUG - 2013-03-25 19:53:36 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Controller Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:53:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:53:36 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:53:36 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:53:36 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 19:55:36 --> Config Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:55:36 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:55:36 --> URI Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Router Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Output Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Security Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Input Class Initialized
DEBUG - 2013-03-25 19:55:36 --> XSS Filtering completed
DEBUG - 2013-03-25 19:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:55:36 --> Language Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Loader Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:55:36 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:55:36 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:55:36 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:55:36 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:55:36 --> Session Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:55:36 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Session routines successfully run
DEBUG - 2013-03-25 19:55:36 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Controller Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:55:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:36 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:55:36 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:55:36 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 19:55:36 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:55:36 --> Final output sent to browser
DEBUG - 2013-03-25 19:55:36 --> Total execution time: 0.0369
DEBUG - 2013-03-25 19:55:37 --> Config Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:55:37 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:55:37 --> URI Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Router Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Output Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Security Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Input Class Initialized
DEBUG - 2013-03-25 19:55:37 --> XSS Filtering completed
DEBUG - 2013-03-25 19:55:37 --> XSS Filtering completed
DEBUG - 2013-03-25 19:55:37 --> XSS Filtering completed
DEBUG - 2013-03-25 19:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:55:37 --> Language Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Loader Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:55:37 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:55:37 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:55:37 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:55:37 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:55:37 --> Session Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:55:37 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Session routines successfully run
DEBUG - 2013-03-25 19:55:37 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Controller Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:37 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:55:37 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:55:37 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:55:37 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:55:37 --> Final output sent to browser
DEBUG - 2013-03-25 19:55:37 --> Total execution time: 0.0282
DEBUG - 2013-03-25 19:55:57 --> Config Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:55:57 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:55:57 --> URI Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Router Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Output Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Security Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Input Class Initialized
DEBUG - 2013-03-25 19:55:57 --> XSS Filtering completed
DEBUG - 2013-03-25 19:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:55:57 --> Language Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Loader Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:55:57 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:55:57 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:55:57 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:55:57 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:55:57 --> Session Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:55:57 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Session routines successfully run
DEBUG - 2013-03-25 19:55:57 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Controller Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Model Class Initialized
DEBUG - 2013-03-25 19:55:57 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:55:57 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:55:57 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:55:57 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:55:57 --> Final output sent to browser
DEBUG - 2013-03-25 19:55:57 --> Total execution time: 0.0456
DEBUG - 2013-03-25 19:57:53 --> Config Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:57:53 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:57:53 --> URI Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Router Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Output Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Security Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Input Class Initialized
DEBUG - 2013-03-25 19:57:53 --> XSS Filtering completed
DEBUG - 2013-03-25 19:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:57:53 --> Language Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Loader Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:57:53 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:57:53 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:57:53 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:57:53 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:57:53 --> Session Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:57:53 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Session routines successfully run
DEBUG - 2013-03-25 19:57:53 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Controller Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:53 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:57:53 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:57:53 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:57:53 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:57:53 --> Final output sent to browser
DEBUG - 2013-03-25 19:57:53 --> Total execution time: 0.0284
DEBUG - 2013-03-25 19:57:55 --> Config Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:57:55 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:57:55 --> URI Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Router Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Output Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Security Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Input Class Initialized
DEBUG - 2013-03-25 19:57:55 --> XSS Filtering completed
DEBUG - 2013-03-25 19:57:55 --> XSS Filtering completed
DEBUG - 2013-03-25 19:57:55 --> XSS Filtering completed
DEBUG - 2013-03-25 19:57:55 --> XSS Filtering completed
DEBUG - 2013-03-25 19:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:57:55 --> Language Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Loader Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:57:55 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:57:55 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:57:55 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:57:55 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:57:55 --> Session Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:57:55 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Session routines successfully run
DEBUG - 2013-03-25 19:57:55 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Controller Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:57:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Model Class Initialized
DEBUG - 2013-03-25 19:57:55 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:57:55 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:57:55 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 19:58:45 --> Config Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:58:45 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:58:45 --> URI Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Router Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Output Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Security Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Input Class Initialized
DEBUG - 2013-03-25 19:58:45 --> XSS Filtering completed
DEBUG - 2013-03-25 19:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:58:45 --> Language Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Loader Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:58:45 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:58:45 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:58:45 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:58:45 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:58:45 --> Session Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:58:45 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Session routines successfully run
DEBUG - 2013-03-25 19:58:45 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Controller Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:45 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:58:45 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:58:45 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:58:45 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:58:45 --> Final output sent to browser
DEBUG - 2013-03-25 19:58:45 --> Total execution time: 0.0390
DEBUG - 2013-03-25 19:58:48 --> Config Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:58:48 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:58:48 --> URI Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Router Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Output Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Security Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Input Class Initialized
DEBUG - 2013-03-25 19:58:48 --> XSS Filtering completed
DEBUG - 2013-03-25 19:58:48 --> XSS Filtering completed
DEBUG - 2013-03-25 19:58:48 --> XSS Filtering completed
DEBUG - 2013-03-25 19:58:48 --> XSS Filtering completed
DEBUG - 2013-03-25 19:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:58:48 --> Language Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Loader Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:58:48 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:58:48 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:58:48 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:58:48 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:58:48 --> Session Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:58:48 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Session routines successfully run
DEBUG - 2013-03-25 19:58:48 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Controller Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:58:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:48 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:58:48 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:58:48 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 19:58:50 --> Config Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:58:50 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:58:50 --> URI Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Router Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Output Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Security Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Input Class Initialized
DEBUG - 2013-03-25 19:58:50 --> XSS Filtering completed
DEBUG - 2013-03-25 19:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:58:50 --> Language Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Loader Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:58:50 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:58:50 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:58:50 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:58:50 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:58:50 --> Session Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:58:50 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Session routines successfully run
DEBUG - 2013-03-25 19:58:50 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Controller Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:58:50 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:50 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:58:50 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:58:50 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 19:58:50 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:58:50 --> Final output sent to browser
DEBUG - 2013-03-25 19:58:50 --> Total execution time: 0.0346
DEBUG - 2013-03-25 19:58:51 --> Config Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:58:51 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:58:51 --> URI Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Router Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Output Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Security Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Input Class Initialized
DEBUG - 2013-03-25 19:58:51 --> XSS Filtering completed
DEBUG - 2013-03-25 19:58:51 --> XSS Filtering completed
DEBUG - 2013-03-25 19:58:51 --> XSS Filtering completed
DEBUG - 2013-03-25 19:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:58:51 --> Language Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Loader Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:58:51 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:58:51 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:58:51 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:58:51 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:58:51 --> Session Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:58:51 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Session routines successfully run
DEBUG - 2013-03-25 19:58:51 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Controller Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Model Class Initialized
DEBUG - 2013-03-25 19:58:51 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:58:51 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:58:51 --> File loaded: application/views/content/password_change_view.php
DEBUG - 2013-03-25 19:58:51 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:58:51 --> Final output sent to browser
DEBUG - 2013-03-25 19:58:51 --> Total execution time: 0.0311
DEBUG - 2013-03-25 19:59:25 --> Config Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:59:25 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:59:25 --> URI Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Router Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Output Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Security Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Input Class Initialized
DEBUG - 2013-03-25 19:59:25 --> XSS Filtering completed
DEBUG - 2013-03-25 19:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:59:25 --> Language Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Loader Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:59:25 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:59:25 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:59:25 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:59:25 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:59:25 --> Session Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:59:25 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Session routines successfully run
DEBUG - 2013-03-25 19:59:25 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Controller Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:25 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:59:25 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:59:25 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 19:59:25 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 19:59:25 --> Final output sent to browser
DEBUG - 2013-03-25 19:59:25 --> Total execution time: 0.0292
DEBUG - 2013-03-25 19:59:26 --> Config Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 19:59:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 19:59:26 --> URI Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Router Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Output Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Security Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Input Class Initialized
DEBUG - 2013-03-25 19:59:26 --> XSS Filtering completed
DEBUG - 2013-03-25 19:59:26 --> XSS Filtering completed
DEBUG - 2013-03-25 19:59:26 --> XSS Filtering completed
DEBUG - 2013-03-25 19:59:26 --> XSS Filtering completed
DEBUG - 2013-03-25 19:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 19:59:26 --> Language Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Loader Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Helper loaded: date_helper
DEBUG - 2013-03-25 19:59:26 --> Helper loaded: form_helper
DEBUG - 2013-03-25 19:59:26 --> Helper loaded: language_helper
DEBUG - 2013-03-25 19:59:26 --> Helper loaded: url_helper
DEBUG - 2013-03-25 19:59:26 --> Helper loaded: html_helper
DEBUG - 2013-03-25 19:59:26 --> Session Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Helper loaded: string_helper
DEBUG - 2013-03-25 19:59:26 --> Encrypt Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Session routines successfully run
DEBUG - 2013-03-25 19:59:26 --> Form Validation Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Controller Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Helper loaded: file_helper
DEBUG - 2013-03-25 19:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 19:59:26 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 19:59:26 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 19:59:26 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 20:00:31 --> Config Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:00:31 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:00:31 --> URI Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Router Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Output Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Security Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Input Class Initialized
DEBUG - 2013-03-25 20:00:31 --> XSS Filtering completed
DEBUG - 2013-03-25 20:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:00:31 --> Language Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Loader Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:00:31 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:00:31 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:00:31 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:00:31 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:00:31 --> Session Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:00:31 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Session routines successfully run
DEBUG - 2013-03-25 20:00:31 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Controller Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:31 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:00:31 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:00:31 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:00:31 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:00:31 --> Final output sent to browser
DEBUG - 2013-03-25 20:00:31 --> Total execution time: 0.0306
DEBUG - 2013-03-25 20:00:32 --> Config Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:00:32 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:00:32 --> URI Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Router Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Output Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Security Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Input Class Initialized
DEBUG - 2013-03-25 20:00:32 --> XSS Filtering completed
DEBUG - 2013-03-25 20:00:32 --> XSS Filtering completed
DEBUG - 2013-03-25 20:00:32 --> XSS Filtering completed
DEBUG - 2013-03-25 20:00:32 --> XSS Filtering completed
DEBUG - 2013-03-25 20:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:00:32 --> Language Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Loader Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:00:32 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:00:32 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:00:32 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:00:32 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:00:32 --> Session Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:00:32 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Session routines successfully run
DEBUG - 2013-03-25 20:00:32 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Controller Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:00:32 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Model Class Initialized
DEBUG - 2013-03-25 20:00:32 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:00:32 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:00:32 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 20:01:27 --> Config Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:01:27 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:01:27 --> URI Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Router Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Output Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Security Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Input Class Initialized
DEBUG - 2013-03-25 20:01:27 --> XSS Filtering completed
DEBUG - 2013-03-25 20:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:01:27 --> Language Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Loader Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:01:27 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:01:27 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:01:27 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:01:27 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:01:27 --> Session Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:01:27 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Session routines successfully run
DEBUG - 2013-03-25 20:01:27 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Controller Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:01:27 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:01:27 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:01:27 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:01:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:01:27 --> Final output sent to browser
DEBUG - 2013-03-25 20:01:27 --> Total execution time: 0.0360
DEBUG - 2013-03-25 20:01:52 --> Config Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:01:52 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:01:52 --> URI Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Router Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Output Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Security Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Input Class Initialized
DEBUG - 2013-03-25 20:01:52 --> XSS Filtering completed
DEBUG - 2013-03-25 20:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:01:52 --> Language Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Loader Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:01:52 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:01:52 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:01:52 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:01:52 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:01:52 --> Session Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:01:52 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Session routines successfully run
DEBUG - 2013-03-25 20:01:52 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Controller Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:01:52 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:01:52 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:01:52 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:01:52 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:01:52 --> Final output sent to browser
DEBUG - 2013-03-25 20:01:52 --> Total execution time: 0.0292
DEBUG - 2013-03-25 20:02:29 --> Config Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:02:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:02:29 --> URI Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Router Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Output Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Security Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Input Class Initialized
DEBUG - 2013-03-25 20:02:29 --> XSS Filtering completed
DEBUG - 2013-03-25 20:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:02:29 --> Language Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Loader Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:02:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:02:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:02:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:02:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:02:29 --> Session Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:02:29 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Session routines successfully run
DEBUG - 2013-03-25 20:02:29 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Controller Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:29 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:02:29 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:02:29 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:02:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:02:29 --> Final output sent to browser
DEBUG - 2013-03-25 20:02:29 --> Total execution time: 0.0372
DEBUG - 2013-03-25 20:02:31 --> Config Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:02:31 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:02:31 --> URI Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Router Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Output Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Security Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Input Class Initialized
DEBUG - 2013-03-25 20:02:31 --> XSS Filtering completed
DEBUG - 2013-03-25 20:02:31 --> XSS Filtering completed
DEBUG - 2013-03-25 20:02:31 --> XSS Filtering completed
DEBUG - 2013-03-25 20:02:31 --> XSS Filtering completed
DEBUG - 2013-03-25 20:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:02:31 --> Language Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Loader Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:02:31 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:02:31 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:02:31 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:02:31 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:02:31 --> Session Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:02:31 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Session routines successfully run
DEBUG - 2013-03-25 20:02:31 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Controller Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:02:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Model Class Initialized
DEBUG - 2013-03-25 20:02:31 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:02:31 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:02:31 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 20:03:37 --> Config Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:03:37 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:03:37 --> URI Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Router Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Output Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Security Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Input Class Initialized
DEBUG - 2013-03-25 20:03:37 --> XSS Filtering completed
DEBUG - 2013-03-25 20:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:03:37 --> Language Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Loader Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:03:37 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:03:37 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:03:37 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:03:37 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:03:37 --> Session Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:03:37 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Session routines successfully run
DEBUG - 2013-03-25 20:03:37 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Controller Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:03:37 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:03:37 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:03:37 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:03:37 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:03:37 --> Final output sent to browser
DEBUG - 2013-03-25 20:03:37 --> Total execution time: 0.0564
DEBUG - 2013-03-25 20:09:08 --> Config Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:09:08 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:09:08 --> URI Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Router Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Output Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Security Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Input Class Initialized
DEBUG - 2013-03-25 20:09:08 --> XSS Filtering completed
DEBUG - 2013-03-25 20:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:09:08 --> Language Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Loader Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:09:08 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:09:08 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:09:08 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:09:08 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:09:08 --> Session Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:09:08 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Session routines successfully run
DEBUG - 2013-03-25 20:09:08 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Controller Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:08 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:09:08 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:09:08 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:09:08 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:09:08 --> Final output sent to browser
DEBUG - 2013-03-25 20:09:08 --> Total execution time: 0.0363
DEBUG - 2013-03-25 20:09:29 --> Config Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:09:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:09:29 --> URI Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Router Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Output Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Security Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Input Class Initialized
DEBUG - 2013-03-25 20:09:29 --> XSS Filtering completed
DEBUG - 2013-03-25 20:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:09:29 --> Language Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Loader Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:09:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:09:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:09:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:09:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:09:29 --> Session Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:09:29 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Session routines successfully run
DEBUG - 2013-03-25 20:09:29 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Controller Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:29 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:09:29 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:09:29 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:09:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:09:29 --> Final output sent to browser
DEBUG - 2013-03-25 20:09:29 --> Total execution time: 0.0426
DEBUG - 2013-03-25 20:09:45 --> Config Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:09:45 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:09:45 --> URI Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Router Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Output Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Security Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Input Class Initialized
DEBUG - 2013-03-25 20:09:45 --> XSS Filtering completed
DEBUG - 2013-03-25 20:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:09:45 --> Language Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Loader Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:09:45 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:09:45 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:09:45 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:09:45 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:09:45 --> Session Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:09:45 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Session routines successfully run
DEBUG - 2013-03-25 20:09:45 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Controller Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Model Class Initialized
DEBUG - 2013-03-25 20:09:45 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:09:45 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:09:45 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:09:45 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:09:45 --> Final output sent to browser
DEBUG - 2013-03-25 20:09:45 --> Total execution time: 0.0286
DEBUG - 2013-03-25 20:10:01 --> Config Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:10:01 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:10:01 --> URI Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Router Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Output Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Security Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Input Class Initialized
DEBUG - 2013-03-25 20:10:01 --> XSS Filtering completed
DEBUG - 2013-03-25 20:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:10:01 --> Language Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Loader Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:10:01 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:10:01 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:10:01 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:10:01 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:10:01 --> Session Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:10:01 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Session routines successfully run
DEBUG - 2013-03-25 20:10:01 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Controller Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:01 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:10:01 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:10:01 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:10:01 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:10:01 --> Final output sent to browser
DEBUG - 2013-03-25 20:10:01 --> Total execution time: 0.0392
DEBUG - 2013-03-25 20:10:05 --> Config Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:10:05 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:10:05 --> URI Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Router Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Output Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Security Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Input Class Initialized
DEBUG - 2013-03-25 20:10:05 --> XSS Filtering completed
DEBUG - 2013-03-25 20:10:05 --> XSS Filtering completed
DEBUG - 2013-03-25 20:10:05 --> XSS Filtering completed
DEBUG - 2013-03-25 20:10:05 --> XSS Filtering completed
DEBUG - 2013-03-25 20:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:10:05 --> Language Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Loader Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:10:05 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:10:05 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:10:05 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:10:05 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:10:05 --> Session Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:10:05 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Session routines successfully run
DEBUG - 2013-03-25 20:10:05 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Controller Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:10:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:10:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:10:05 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-25 20:10:05 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:10:12 --> Final output sent to browser
DEBUG - 2013-03-25 20:10:12 --> Total execution time: 6.6447
DEBUG - 2013-03-25 20:10:19 --> Config Class Initialized
DEBUG - 2013-03-25 20:10:19 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:10:19 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:10:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:10:19 --> URI Class Initialized
DEBUG - 2013-03-25 20:10:19 --> Router Class Initialized
DEBUG - 2013-03-25 20:10:19 --> Output Class Initialized
DEBUG - 2013-03-25 20:10:19 --> Security Class Initialized
DEBUG - 2013-03-25 20:10:19 --> Input Class Initialized
DEBUG - 2013-03-25 20:10:19 --> XSS Filtering completed
DEBUG - 2013-03-25 20:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:10:19 --> Language Class Initialized
DEBUG - 2013-03-25 20:10:19 --> Loader Class Initialized
DEBUG - 2013-03-25 20:10:19 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:10:19 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:10:19 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:10:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:10:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:10:19 --> Session Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:10:20 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Session routines successfully run
DEBUG - 2013-03-25 20:10:20 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Controller Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:10:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:10:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:10:20 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 20:10:20 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:10:20 --> Final output sent to browser
DEBUG - 2013-03-25 20:10:20 --> Total execution time: 0.0636
DEBUG - 2013-03-25 20:10:45 --> Config Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:10:45 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:10:45 --> URI Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Router Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Output Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Security Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Input Class Initialized
DEBUG - 2013-03-25 20:10:45 --> XSS Filtering completed
DEBUG - 2013-03-25 20:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:10:45 --> Language Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Loader Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:10:45 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:10:45 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:10:45 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:10:45 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:10:45 --> Session Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:10:45 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Session routines successfully run
DEBUG - 2013-03-25 20:10:45 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Controller Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:45 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:10:45 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:10:45 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:10:45 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:10:45 --> Final output sent to browser
DEBUG - 2013-03-25 20:10:45 --> Total execution time: 0.0461
DEBUG - 2013-03-25 20:10:52 --> Config Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:10:52 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:10:52 --> URI Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Router Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Output Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Security Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Input Class Initialized
DEBUG - 2013-03-25 20:10:52 --> XSS Filtering completed
DEBUG - 2013-03-25 20:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:10:52 --> Language Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Loader Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:10:52 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:10:52 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:10:52 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:10:52 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:10:52 --> Session Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:10:52 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Session routines successfully run
DEBUG - 2013-03-25 20:10:52 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Controller Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:10:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Model Class Initialized
DEBUG - 2013-03-25 20:10:52 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:10:52 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:10:52 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 20:10:52 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:10:52 --> Final output sent to browser
DEBUG - 2013-03-25 20:10:52 --> Total execution time: 0.0345
DEBUG - 2013-03-25 20:12:35 --> Config Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:12:35 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:12:35 --> URI Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Router Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Output Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Security Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Input Class Initialized
DEBUG - 2013-03-25 20:12:35 --> XSS Filtering completed
DEBUG - 2013-03-25 20:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:12:35 --> Language Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Loader Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:12:35 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:12:35 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:12:35 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:12:35 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:12:35 --> Session Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:12:35 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Session routines successfully run
DEBUG - 2013-03-25 20:12:35 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Controller Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:35 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:12:35 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:12:35 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-25 20:12:35 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:12:35 --> Final output sent to browser
DEBUG - 2013-03-25 20:12:35 --> Total execution time: 0.0456
DEBUG - 2013-03-25 20:12:37 --> Config Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:12:37 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:12:37 --> URI Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Router Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Output Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Security Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Input Class Initialized
DEBUG - 2013-03-25 20:12:37 --> XSS Filtering completed
DEBUG - 2013-03-25 20:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:12:37 --> Language Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Loader Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:12:37 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:12:37 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:12:37 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:12:37 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:12:37 --> Session Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:12:37 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Session routines successfully run
DEBUG - 2013-03-25 20:12:37 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Controller Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:12:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:37 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:12:37 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:12:37 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 20:12:37 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:12:37 --> Final output sent to browser
DEBUG - 2013-03-25 20:12:37 --> Total execution time: 0.0551
DEBUG - 2013-03-25 20:12:39 --> Config Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:12:39 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:12:39 --> URI Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Router Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Output Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Security Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Input Class Initialized
DEBUG - 2013-03-25 20:12:39 --> XSS Filtering completed
DEBUG - 2013-03-25 20:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:12:39 --> Language Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Loader Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:12:39 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:12:39 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:12:39 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:12:39 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:12:39 --> Session Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:12:39 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Session routines successfully run
DEBUG - 2013-03-25 20:12:39 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Controller Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:12:39 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Model Class Initialized
DEBUG - 2013-03-25 20:12:39 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:12:39 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:12:39 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-25 20:12:39 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:12:39 --> Final output sent to browser
DEBUG - 2013-03-25 20:12:39 --> Total execution time: 0.0449
DEBUG - 2013-03-25 20:13:22 --> Config Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:13:22 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:13:22 --> URI Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Router Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Output Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Security Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Input Class Initialized
DEBUG - 2013-03-25 20:13:22 --> XSS Filtering completed
DEBUG - 2013-03-25 20:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:13:22 --> Language Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Loader Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:13:22 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:13:22 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:13:22 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:13:22 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:13:22 --> Session Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:13:22 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Session routines successfully run
DEBUG - 2013-03-25 20:13:22 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Controller Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:13:22 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:13:22 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:13:22 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 20:13:22 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:13:22 --> Final output sent to browser
DEBUG - 2013-03-25 20:13:22 --> Total execution time: 0.0529
DEBUG - 2013-03-25 20:13:24 --> Config Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:13:24 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:13:24 --> URI Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Router Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Output Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Security Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Input Class Initialized
DEBUG - 2013-03-25 20:13:24 --> XSS Filtering completed
DEBUG - 2013-03-25 20:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:13:24 --> Language Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Loader Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:13:24 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:13:24 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:13:24 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:13:24 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:13:24 --> Session Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:13:24 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Session routines successfully run
DEBUG - 2013-03-25 20:13:24 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Controller Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:13:24 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:13:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:13:25 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:13:25 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:13:25 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:13:25 --> Final output sent to browser
DEBUG - 2013-03-25 20:13:25 --> Total execution time: 0.2711
DEBUG - 2013-03-25 20:13:25 --> Config Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:13:25 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:13:25 --> URI Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Router Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Output Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Security Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Input Class Initialized
DEBUG - 2013-03-25 20:13:25 --> XSS Filtering completed
DEBUG - 2013-03-25 20:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:13:25 --> Language Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Loader Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:13:25 --> Session Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:13:25 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Session routines successfully run
DEBUG - 2013-03-25 20:13:25 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Controller Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:13:25 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:13:25 --> Config Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:13:25 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:13:25 --> URI Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Router Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Output Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Security Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Input Class Initialized
DEBUG - 2013-03-25 20:13:25 --> XSS Filtering completed
DEBUG - 2013-03-25 20:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:13:25 --> Language Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Loader Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:13:25 --> Session Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:13:25 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Session routines successfully run
DEBUG - 2013-03-25 20:13:25 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Controller Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Model Class Initialized
DEBUG - 2013-03-25 20:13:25 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:13:25 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:30:40 --> Config Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:30:40 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:30:40 --> URI Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Router Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Output Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Security Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Input Class Initialized
DEBUG - 2013-03-25 20:30:40 --> XSS Filtering completed
DEBUG - 2013-03-25 20:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:30:40 --> Language Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Loader Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:30:40 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:30:40 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:30:40 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:30:40 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:30:40 --> Session Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:30:40 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Session routines successfully run
DEBUG - 2013-03-25 20:30:40 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Controller Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:30:40 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:40 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:30:40 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:30:40 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 20:30:40 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:30:40 --> Final output sent to browser
DEBUG - 2013-03-25 20:30:40 --> Total execution time: 0.2081
DEBUG - 2013-03-25 20:30:42 --> Config Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:30:42 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:30:42 --> URI Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Router Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Output Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Security Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Input Class Initialized
DEBUG - 2013-03-25 20:30:42 --> XSS Filtering completed
DEBUG - 2013-03-25 20:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:30:42 --> Language Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Loader Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:30:42 --> Session Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:30:42 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Session routines successfully run
DEBUG - 2013-03-25 20:30:42 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Controller Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:30:42 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:30:42 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:30:42 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:30:42 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:30:42 --> Final output sent to browser
DEBUG - 2013-03-25 20:30:42 --> Total execution time: 0.3186
DEBUG - 2013-03-25 20:30:42 --> Config Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:30:42 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:30:42 --> URI Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Router Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Output Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Security Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Input Class Initialized
DEBUG - 2013-03-25 20:30:42 --> XSS Filtering completed
DEBUG - 2013-03-25 20:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:30:42 --> Language Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Loader Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:30:42 --> Session Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:30:42 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Session routines successfully run
DEBUG - 2013-03-25 20:30:42 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Controller Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:30:42 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:30:42 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:31:27 --> Config Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:31:27 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:31:27 --> URI Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Router Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Output Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Security Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Input Class Initialized
DEBUG - 2013-03-25 20:31:27 --> XSS Filtering completed
DEBUG - 2013-03-25 20:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:31:27 --> Language Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Loader Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:31:27 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:31:27 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:31:27 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:31:27 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:31:27 --> Session Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:31:27 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Session routines successfully run
DEBUG - 2013-03-25 20:31:27 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Controller Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:31:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:27 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:31:27 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:31:27 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 20:31:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:31:27 --> Final output sent to browser
DEBUG - 2013-03-25 20:31:27 --> Total execution time: 0.0348
DEBUG - 2013-03-25 20:31:29 --> Config Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:31:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:31:29 --> URI Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Router Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Output Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Security Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Input Class Initialized
DEBUG - 2013-03-25 20:31:29 --> XSS Filtering completed
DEBUG - 2013-03-25 20:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:31:29 --> Language Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Loader Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:31:29 --> Session Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:31:29 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Session routines successfully run
DEBUG - 2013-03-25 20:31:29 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Controller Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:31:29 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:31:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:31:29 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:31:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:31:29 --> Final output sent to browser
DEBUG - 2013-03-25 20:31:29 --> Total execution time: 0.2218
DEBUG - 2013-03-25 20:31:29 --> Config Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:31:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:31:29 --> URI Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Router Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Output Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Security Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Input Class Initialized
DEBUG - 2013-03-25 20:31:29 --> XSS Filtering completed
DEBUG - 2013-03-25 20:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:31:29 --> Language Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Loader Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:31:29 --> Session Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:31:29 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Session routines successfully run
DEBUG - 2013-03-25 20:31:29 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Controller Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:31:29 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:31:29 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:32:14 --> Config Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:32:14 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:32:14 --> URI Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Router Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Output Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Security Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Input Class Initialized
DEBUG - 2013-03-25 20:32:14 --> XSS Filtering completed
DEBUG - 2013-03-25 20:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:32:14 --> Language Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Loader Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:32:14 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:32:14 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:32:14 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:32:14 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:32:14 --> Session Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:32:14 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Session routines successfully run
DEBUG - 2013-03-25 20:32:14 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Controller Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:32:14 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:14 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:32:14 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:32:14 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:32:15 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:32:15 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:32:15 --> Final output sent to browser
DEBUG - 2013-03-25 20:32:15 --> Total execution time: 0.3841
DEBUG - 2013-03-25 20:32:15 --> Config Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:32:15 --> URI Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Router Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Output Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Security Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Input Class Initialized
DEBUG - 2013-03-25 20:32:15 --> XSS Filtering completed
DEBUG - 2013-03-25 20:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:32:15 --> Language Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Loader Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:32:15 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:32:15 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:32:15 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:32:15 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:32:15 --> Session Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:32:15 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Session routines successfully run
DEBUG - 2013-03-25 20:32:15 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Controller Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:32:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:15 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:32:15 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:32:29 --> Config Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:32:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:32:29 --> URI Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Router Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Output Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Security Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Input Class Initialized
DEBUG - 2013-03-25 20:32:29 --> XSS Filtering completed
DEBUG - 2013-03-25 20:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:32:29 --> Language Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Loader Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:32:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:32:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:32:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:32:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:32:29 --> Session Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:32:29 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Session routines successfully run
DEBUG - 2013-03-25 20:32:29 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Controller Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:32:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:29 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:32:29 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:32:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:32:29 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:32:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:32:29 --> Final output sent to browser
DEBUG - 2013-03-25 20:32:29 --> Total execution time: 0.3197
DEBUG - 2013-03-25 20:32:30 --> Config Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:32:30 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:32:30 --> URI Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Router Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Output Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Security Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Input Class Initialized
DEBUG - 2013-03-25 20:32:30 --> XSS Filtering completed
DEBUG - 2013-03-25 20:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:32:30 --> Language Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Loader Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:32:30 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:32:30 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:32:30 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:32:30 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:32:30 --> Session Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:32:30 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Session routines successfully run
DEBUG - 2013-03-25 20:32:30 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Controller Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:32:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:30 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:32:30 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:32:42 --> Config Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:32:42 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:32:42 --> URI Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Router Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Output Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Security Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Input Class Initialized
DEBUG - 2013-03-25 20:32:42 --> XSS Filtering completed
DEBUG - 2013-03-25 20:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:32:42 --> Language Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Loader Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:32:42 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:32:42 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:32:42 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:32:42 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:32:42 --> Session Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:32:42 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Session routines successfully run
DEBUG - 2013-03-25 20:32:42 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Controller Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:32:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:42 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:32:42 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:32:42 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:32:43 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:32:43 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:32:43 --> Final output sent to browser
DEBUG - 2013-03-25 20:32:43 --> Total execution time: 0.3144
DEBUG - 2013-03-25 20:32:43 --> Config Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:32:43 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:32:43 --> URI Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Router Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Output Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Security Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Input Class Initialized
DEBUG - 2013-03-25 20:32:43 --> XSS Filtering completed
DEBUG - 2013-03-25 20:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:32:43 --> Language Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Loader Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:32:43 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:32:43 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:32:43 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:32:43 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:32:43 --> Session Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:32:43 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Session routines successfully run
DEBUG - 2013-03-25 20:32:43 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Controller Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:32:43 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Model Class Initialized
DEBUG - 2013-03-25 20:32:43 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:32:43 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:33:26 --> Config Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:33:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:33:26 --> URI Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Router Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Output Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Security Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Input Class Initialized
DEBUG - 2013-03-25 20:33:26 --> XSS Filtering completed
DEBUG - 2013-03-25 20:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:33:26 --> Language Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Loader Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:33:26 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:33:26 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:33:26 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:33:26 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:33:26 --> Session Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:33:26 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Session routines successfully run
DEBUG - 2013-03-25 20:33:26 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Controller Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:33:26 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:26 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:33:26 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:33:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:33:27 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:33:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:33:27 --> Final output sent to browser
DEBUG - 2013-03-25 20:33:27 --> Total execution time: 0.3197
DEBUG - 2013-03-25 20:33:27 --> Config Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:33:27 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:33:27 --> URI Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Router Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Output Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Security Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Input Class Initialized
DEBUG - 2013-03-25 20:33:27 --> XSS Filtering completed
DEBUG - 2013-03-25 20:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:33:27 --> Language Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Loader Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:33:27 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:33:27 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:33:27 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:33:27 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:33:27 --> Session Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:33:27 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Session routines successfully run
DEBUG - 2013-03-25 20:33:27 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Controller Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:33:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Model Class Initialized
DEBUG - 2013-03-25 20:33:27 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:33:27 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:34:03 --> Config Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:34:03 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:34:03 --> URI Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Router Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Output Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Security Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Input Class Initialized
DEBUG - 2013-03-25 20:34:03 --> XSS Filtering completed
DEBUG - 2013-03-25 20:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:34:03 --> Language Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Loader Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:34:03 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:34:03 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:34:03 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:34:03 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:34:03 --> Session Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:34:03 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Session routines successfully run
DEBUG - 2013-03-25 20:34:03 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Controller Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:34:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:03 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:34:03 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:34:03 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:34:03 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:34:03 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:34:03 --> Final output sent to browser
DEBUG - 2013-03-25 20:34:03 --> Total execution time: 0.3327
DEBUG - 2013-03-25 20:34:04 --> Config Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:34:04 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:34:04 --> URI Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Router Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Output Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Security Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Input Class Initialized
DEBUG - 2013-03-25 20:34:04 --> XSS Filtering completed
DEBUG - 2013-03-25 20:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:34:04 --> Language Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Loader Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:34:04 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:34:04 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:34:04 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:34:04 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:34:04 --> Session Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:34:04 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Session routines successfully run
DEBUG - 2013-03-25 20:34:04 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Controller Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:34:04 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Model Class Initialized
DEBUG - 2013-03-25 20:34:04 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:34:04 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:39:15 --> Config Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:39:15 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:39:15 --> URI Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Router Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Output Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Security Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Input Class Initialized
DEBUG - 2013-03-25 20:39:15 --> XSS Filtering completed
DEBUG - 2013-03-25 20:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:39:15 --> Language Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Loader Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:39:15 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:39:15 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:39:15 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:39:15 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:39:15 --> Session Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:39:15 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Session routines successfully run
DEBUG - 2013-03-25 20:39:15 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Controller Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:39:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:15 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:39:15 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 20:39:15 --> Could not find the language line "voc.i18n_check_all"
ERROR - 2013-03-25 20:39:15 --> Could not find the language line "voc.i18n_uncheck_all"
DEBUG - 2013-03-25 20:39:15 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:39:15 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:39:15 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:39:15 --> Final output sent to browser
DEBUG - 2013-03-25 20:39:15 --> Total execution time: 0.3209
DEBUG - 2013-03-25 20:39:16 --> Config Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:39:16 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:39:16 --> URI Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Router Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Output Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Security Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Input Class Initialized
DEBUG - 2013-03-25 20:39:16 --> XSS Filtering completed
DEBUG - 2013-03-25 20:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:39:16 --> Language Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Loader Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:39:16 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:39:16 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:39:16 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:39:16 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:39:16 --> Session Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:39:16 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Session routines successfully run
DEBUG - 2013-03-25 20:39:16 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Controller Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:39:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:16 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:39:16 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 20:39:16 --> Could not find the language line "voc.i18n_check_all"
ERROR - 2013-03-25 20:39:16 --> Could not find the language line "voc.i18n_uncheck_all"
DEBUG - 2013-03-25 20:39:34 --> Config Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:39:34 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:39:34 --> URI Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Router Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Output Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Security Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Input Class Initialized
DEBUG - 2013-03-25 20:39:34 --> XSS Filtering completed
DEBUG - 2013-03-25 20:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:39:34 --> Language Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Loader Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:39:34 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:39:34 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:39:34 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:39:34 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:39:34 --> Session Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:39:34 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Session routines successfully run
DEBUG - 2013-03-25 20:39:34 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Controller Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:39:34 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:34 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:39:34 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 20:39:34 --> Could not find the language line "voc.i18n_check_all"
ERROR - 2013-03-25 20:39:34 --> Could not find the language line "voc.i18n_uncheck_all"
DEBUG - 2013-03-25 20:39:34 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:39:34 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:39:35 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:39:35 --> Final output sent to browser
DEBUG - 2013-03-25 20:39:35 --> Total execution time: 0.3410
DEBUG - 2013-03-25 20:39:35 --> Config Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:39:35 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:39:35 --> URI Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Router Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Output Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Security Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Input Class Initialized
DEBUG - 2013-03-25 20:39:35 --> XSS Filtering completed
DEBUG - 2013-03-25 20:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:39:35 --> Language Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Loader Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:39:35 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:39:35 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:39:35 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:39:35 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:39:35 --> Session Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:39:35 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Session routines successfully run
DEBUG - 2013-03-25 20:39:35 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Controller Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:39:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Model Class Initialized
DEBUG - 2013-03-25 20:39:35 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:39:35 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 20:39:35 --> Could not find the language line "voc.i18n_check_all"
ERROR - 2013-03-25 20:39:35 --> Could not find the language line "voc.i18n_uncheck_all"
DEBUG - 2013-03-25 20:41:10 --> Config Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:41:10 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:41:10 --> URI Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Router Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Output Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Security Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Input Class Initialized
DEBUG - 2013-03-25 20:41:10 --> XSS Filtering completed
DEBUG - 2013-03-25 20:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:41:10 --> Language Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Loader Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:41:10 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:41:10 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:41:10 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:41:10 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:41:10 --> Session Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:41:10 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Session routines successfully run
DEBUG - 2013-03-25 20:41:10 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Controller Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:41:10 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:10 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:41:10 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:41:10 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:41:11 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:41:11 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:41:11 --> Final output sent to browser
DEBUG - 2013-03-25 20:41:11 --> Total execution time: 0.3853
DEBUG - 2013-03-25 20:41:11 --> Config Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:41:11 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:41:11 --> URI Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Router Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Output Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Security Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Input Class Initialized
DEBUG - 2013-03-25 20:41:11 --> XSS Filtering completed
DEBUG - 2013-03-25 20:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:41:11 --> Language Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Loader Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:41:11 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:41:11 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:41:11 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:41:11 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:41:11 --> Session Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:41:11 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Session routines successfully run
DEBUG - 2013-03-25 20:41:11 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Controller Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:41:11 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Model Class Initialized
DEBUG - 2013-03-25 20:41:11 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:41:11 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:42:01 --> Config Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:42:01 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:42:01 --> URI Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Router Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Output Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Security Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Input Class Initialized
DEBUG - 2013-03-25 20:42:01 --> XSS Filtering completed
DEBUG - 2013-03-25 20:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:42:01 --> Language Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Loader Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:42:01 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:42:01 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:42:01 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:42:01 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:42:01 --> Session Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:42:01 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Session routines successfully run
DEBUG - 2013-03-25 20:42:01 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Controller Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:42:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:01 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:42:01 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:42:01 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:42:01 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:42:01 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:42:01 --> Final output sent to browser
DEBUG - 2013-03-25 20:42:01 --> Total execution time: 0.3332
DEBUG - 2013-03-25 20:42:02 --> Config Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:42:02 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:42:02 --> URI Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Router Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Output Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Security Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Input Class Initialized
DEBUG - 2013-03-25 20:42:02 --> XSS Filtering completed
DEBUG - 2013-03-25 20:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:42:02 --> Language Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Loader Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:42:02 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:42:02 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:42:02 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:42:02 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:42:02 --> Session Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:42:02 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Session routines successfully run
DEBUG - 2013-03-25 20:42:02 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Controller Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:42:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:42:02 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:42:02 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:45:18 --> Config Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:45:18 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:45:18 --> URI Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Router Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Output Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Security Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Input Class Initialized
DEBUG - 2013-03-25 20:45:18 --> XSS Filtering completed
DEBUG - 2013-03-25 20:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:45:18 --> Language Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Loader Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:45:18 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:45:18 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:45:18 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:45:18 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:45:18 --> Session Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:45:18 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Session routines successfully run
DEBUG - 2013-03-25 20:45:18 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Controller Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:45:18 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:18 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:45:18 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:45:18 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:45:19 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:45:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:45:19 --> Final output sent to browser
DEBUG - 2013-03-25 20:45:19 --> Total execution time: 0.3073
DEBUG - 2013-03-25 20:45:19 --> Config Class Initialized
DEBUG - 2013-03-25 20:45:19 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:45:19 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:45:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:45:19 --> URI Class Initialized
DEBUG - 2013-03-25 20:45:19 --> Router Class Initialized
DEBUG - 2013-03-25 20:45:19 --> Output Class Initialized
DEBUG - 2013-03-25 20:45:19 --> Security Class Initialized
DEBUG - 2013-03-25 20:45:19 --> Input Class Initialized
DEBUG - 2013-03-25 20:45:19 --> XSS Filtering completed
DEBUG - 2013-03-25 20:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:45:19 --> Language Class Initialized
DEBUG - 2013-03-25 20:45:19 --> Loader Class Initialized
DEBUG - 2013-03-25 20:45:19 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:45:19 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:45:19 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:45:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:45:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:45:20 --> Session Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:45:20 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Session routines successfully run
DEBUG - 2013-03-25 20:45:20 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Controller Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:45:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Model Class Initialized
DEBUG - 2013-03-25 20:45:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:45:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:47:02 --> Config Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:47:02 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:47:02 --> URI Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Router Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Output Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Security Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Input Class Initialized
DEBUG - 2013-03-25 20:47:02 --> XSS Filtering completed
DEBUG - 2013-03-25 20:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:47:02 --> Language Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Loader Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:47:02 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:47:02 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:47:02 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:47:02 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:47:02 --> Session Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:47:02 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Session routines successfully run
DEBUG - 2013-03-25 20:47:02 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Controller Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:47:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:02 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:47:02 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:47:02 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:47:02 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:47:02 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:47:02 --> Final output sent to browser
DEBUG - 2013-03-25 20:47:02 --> Total execution time: 0.3207
DEBUG - 2013-03-25 20:47:03 --> Config Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:47:03 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:47:03 --> URI Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Router Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Output Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Security Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Input Class Initialized
DEBUG - 2013-03-25 20:47:03 --> XSS Filtering completed
DEBUG - 2013-03-25 20:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:47:03 --> Language Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Loader Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:47:03 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:47:03 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:47:03 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:47:03 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:47:03 --> Session Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:47:03 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Session routines successfully run
DEBUG - 2013-03-25 20:47:03 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Controller Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:47:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:03 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:47:03 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:47:16 --> Config Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:47:16 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:47:16 --> URI Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Router Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Output Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Security Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Input Class Initialized
DEBUG - 2013-03-25 20:47:16 --> XSS Filtering completed
DEBUG - 2013-03-25 20:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:47:16 --> Language Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Loader Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:47:16 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:47:16 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:47:16 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:47:16 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:47:16 --> Session Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:47:16 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Session routines successfully run
DEBUG - 2013-03-25 20:47:16 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Controller Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:47:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:16 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:47:16 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:47:16 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:47:16 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:47:16 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:47:16 --> Final output sent to browser
DEBUG - 2013-03-25 20:47:16 --> Total execution time: 0.1355
DEBUG - 2013-03-25 20:47:17 --> Config Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:47:17 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:47:17 --> URI Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Router Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Output Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Security Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Input Class Initialized
DEBUG - 2013-03-25 20:47:17 --> XSS Filtering completed
DEBUG - 2013-03-25 20:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:47:17 --> Language Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Loader Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:47:17 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:47:17 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:47:17 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:47:17 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:47:17 --> Session Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:47:17 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Session routines successfully run
DEBUG - 2013-03-25 20:47:17 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Controller Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:47:17 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:17 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:47:17 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:47:28 --> Config Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:47:28 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:47:28 --> URI Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Router Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Output Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Security Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Input Class Initialized
DEBUG - 2013-03-25 20:47:28 --> XSS Filtering completed
DEBUG - 2013-03-25 20:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:47:28 --> Language Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Loader Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:47:28 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:47:28 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:47:28 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:47:28 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:47:28 --> Session Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:47:28 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Session routines successfully run
DEBUG - 2013-03-25 20:47:28 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Controller Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:47:28 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:28 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:47:28 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:47:28 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:47:29 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:47:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:47:29 --> Final output sent to browser
DEBUG - 2013-03-25 20:47:29 --> Total execution time: 0.3023
DEBUG - 2013-03-25 20:47:29 --> Config Class Initialized
DEBUG - 2013-03-25 20:47:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:47:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:47:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:47:29 --> URI Class Initialized
DEBUG - 2013-03-25 20:47:29 --> Router Class Initialized
DEBUG - 2013-03-25 20:47:29 --> Output Class Initialized
DEBUG - 2013-03-25 20:47:29 --> Security Class Initialized
DEBUG - 2013-03-25 20:47:29 --> Input Class Initialized
DEBUG - 2013-03-25 20:47:29 --> XSS Filtering completed
DEBUG - 2013-03-25 20:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:47:29 --> Language Class Initialized
DEBUG - 2013-03-25 20:47:29 --> Loader Class Initialized
DEBUG - 2013-03-25 20:47:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:47:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:47:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:47:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:47:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:47:30 --> Session Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:47:30 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Session routines successfully run
DEBUG - 2013-03-25 20:47:30 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Controller Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:47:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Model Class Initialized
DEBUG - 2013-03-25 20:47:30 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:47:30 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:48:05 --> Config Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:48:05 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:48:05 --> URI Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Router Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Output Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Security Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Input Class Initialized
DEBUG - 2013-03-25 20:48:05 --> XSS Filtering completed
DEBUG - 2013-03-25 20:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:48:05 --> Language Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Loader Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:48:05 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:48:05 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:48:05 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:48:05 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:48:05 --> Session Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:48:05 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Session routines successfully run
DEBUG - 2013-03-25 20:48:05 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Controller Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:48:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:05 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:48:05 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:48:05 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:48:05 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:48:05 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:48:05 --> Final output sent to browser
DEBUG - 2013-03-25 20:48:05 --> Total execution time: 0.3298
DEBUG - 2013-03-25 20:48:06 --> Config Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:48:06 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:48:06 --> URI Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Router Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Output Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Security Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Input Class Initialized
DEBUG - 2013-03-25 20:48:06 --> XSS Filtering completed
DEBUG - 2013-03-25 20:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:48:06 --> Language Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Loader Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:48:06 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:48:06 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:48:06 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:48:06 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:48:06 --> Session Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:48:06 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Session routines successfully run
DEBUG - 2013-03-25 20:48:06 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Controller Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:48:06 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:06 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:48:06 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:48:46 --> Config Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:48:46 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:48:46 --> URI Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Router Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Output Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Security Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Input Class Initialized
DEBUG - 2013-03-25 20:48:46 --> XSS Filtering completed
DEBUG - 2013-03-25 20:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:48:46 --> Language Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Loader Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:48:46 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:48:46 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:48:46 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:48:46 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:48:46 --> Session Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:48:46 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Session routines successfully run
DEBUG - 2013-03-25 20:48:46 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Controller Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:48:46 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:46 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:48:46 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 20:48:46 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:48:47 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 20:48:47 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 20:48:47 --> Final output sent to browser
DEBUG - 2013-03-25 20:48:47 --> Total execution time: 0.3013
DEBUG - 2013-03-25 20:48:47 --> Config Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Hooks Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Utf8 Class Initialized
DEBUG - 2013-03-25 20:48:47 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 20:48:47 --> URI Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Router Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Output Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Security Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Input Class Initialized
DEBUG - 2013-03-25 20:48:47 --> XSS Filtering completed
DEBUG - 2013-03-25 20:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 20:48:47 --> Language Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Loader Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Helper loaded: date_helper
DEBUG - 2013-03-25 20:48:47 --> Helper loaded: form_helper
DEBUG - 2013-03-25 20:48:47 --> Helper loaded: language_helper
DEBUG - 2013-03-25 20:48:47 --> Helper loaded: url_helper
DEBUG - 2013-03-25 20:48:47 --> Helper loaded: html_helper
DEBUG - 2013-03-25 20:48:47 --> Session Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Helper loaded: string_helper
DEBUG - 2013-03-25 20:48:47 --> Encrypt Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Session routines successfully run
DEBUG - 2013-03-25 20:48:47 --> Form Validation Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Controller Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Database Driver Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Helper loaded: file_helper
DEBUG - 2013-03-25 20:48:47 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Model Class Initialized
DEBUG - 2013-03-25 20:48:47 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 20:48:47 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:09:25 --> Config Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:09:25 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:09:25 --> URI Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Router Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Output Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Security Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Input Class Initialized
DEBUG - 2013-03-25 21:09:25 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:09:25 --> Language Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Loader Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:09:25 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:09:25 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:09:25 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:09:25 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:09:25 --> Session Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:09:25 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Session routines successfully run
DEBUG - 2013-03-25 21:09:25 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Controller Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:09:25 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:25 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:09:25 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:09:25 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 21:09:25 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:09:25 --> Final output sent to browser
DEBUG - 2013-03-25 21:09:25 --> Total execution time: 0.0628
DEBUG - 2013-03-25 21:09:27 --> Config Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:09:27 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:09:27 --> URI Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Router Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Output Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Security Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Input Class Initialized
DEBUG - 2013-03-25 21:09:27 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:09:27 --> Language Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Loader Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:09:27 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:09:27 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:09:27 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:09:27 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:09:27 --> Session Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:09:27 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Session routines successfully run
DEBUG - 2013-03-25 21:09:27 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Controller Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:09:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:27 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:09:27 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:09:27 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:09:27 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 21:09:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:09:27 --> Final output sent to browser
DEBUG - 2013-03-25 21:09:27 --> Total execution time: 0.3207
DEBUG - 2013-03-25 21:09:28 --> Config Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:09:28 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:09:28 --> URI Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Router Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Output Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Security Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Input Class Initialized
DEBUG - 2013-03-25 21:09:28 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:09:28 --> Language Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Loader Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:09:28 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:09:28 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:09:28 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:09:28 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:09:28 --> Session Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:09:28 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Session routines successfully run
DEBUG - 2013-03-25 21:09:28 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Controller Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:09:28 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:28 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:09:28 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:09:35 --> Config Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:09:35 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:09:35 --> URI Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Router Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Output Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Security Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Input Class Initialized
DEBUG - 2013-03-25 21:09:35 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:35 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:35 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:35 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:35 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:09:35 --> Language Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Loader Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:09:35 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:09:35 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:09:35 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:09:35 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:09:35 --> Session Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:09:35 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Session routines successfully run
DEBUG - 2013-03-25 21:09:35 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Controller Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:09:35 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:09:35 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:09:35 --> Final output sent to browser
DEBUG - 2013-03-25 21:09:35 --> Total execution time: 0.2190
DEBUG - 2013-03-25 21:09:44 --> Config Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:09:44 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:09:44 --> URI Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Router Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Output Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Security Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Input Class Initialized
DEBUG - 2013-03-25 21:09:44 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:09:44 --> Language Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Loader Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:09:44 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:09:44 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:09:44 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:09:44 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:09:44 --> Session Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:09:44 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Session routines successfully run
DEBUG - 2013-03-25 21:09:44 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Controller Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:09:44 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:44 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:09:44 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:09:44 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 21:09:44 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:09:44 --> Final output sent to browser
DEBUG - 2013-03-25 21:09:44 --> Total execution time: 0.0386
DEBUG - 2013-03-25 21:09:46 --> Config Class Initialized
DEBUG - 2013-03-25 21:09:46 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:09:46 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:09:46 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:09:46 --> URI Class Initialized
DEBUG - 2013-03-25 21:09:46 --> Router Class Initialized
DEBUG - 2013-03-25 21:09:46 --> Output Class Initialized
DEBUG - 2013-03-25 21:09:46 --> Security Class Initialized
DEBUG - 2013-03-25 21:09:46 --> Input Class Initialized
DEBUG - 2013-03-25 21:09:46 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:09:46 --> Language Class Initialized
DEBUG - 2013-03-25 21:09:46 --> Loader Class Initialized
DEBUG - 2013-03-25 21:09:46 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:09:46 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:09:46 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:09:46 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:09:46 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:09:47 --> Session Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:09:47 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Session routines successfully run
DEBUG - 2013-03-25 21:09:47 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Controller Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:09:47 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:09:47 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:09:47 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 21:09:47 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:09:47 --> Final output sent to browser
DEBUG - 2013-03-25 21:09:47 --> Total execution time: 0.3419
DEBUG - 2013-03-25 21:09:47 --> Config Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:09:47 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:09:47 --> URI Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Router Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Output Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Security Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Input Class Initialized
DEBUG - 2013-03-25 21:09:47 --> XSS Filtering completed
DEBUG - 2013-03-25 21:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:09:47 --> Language Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Loader Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:09:47 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:09:47 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:09:47 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:09:47 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:09:47 --> Session Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:09:47 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Session routines successfully run
DEBUG - 2013-03-25 21:09:47 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Controller Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Model Class Initialized
DEBUG - 2013-03-25 21:09:47 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:09:47 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:11:58 --> Config Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:11:58 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:11:58 --> URI Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Router Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Output Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Security Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Input Class Initialized
DEBUG - 2013-03-25 21:11:58 --> XSS Filtering completed
DEBUG - 2013-03-25 21:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:11:58 --> Language Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Loader Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:11:58 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:11:58 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:11:58 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:11:58 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:11:58 --> Session Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:11:58 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Session routines successfully run
DEBUG - 2013-03-25 21:11:58 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Controller Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:11:58 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:11:58 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:11:58 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:11:58 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 21:11:58 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:11:58 --> Final output sent to browser
DEBUG - 2013-03-25 21:11:58 --> Total execution time: 0.2699
DEBUG - 2013-03-25 21:11:58 --> Config Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:11:58 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:11:58 --> URI Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Router Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Output Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Security Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Input Class Initialized
DEBUG - 2013-03-25 21:11:58 --> XSS Filtering completed
DEBUG - 2013-03-25 21:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:11:58 --> Language Class Initialized
DEBUG - 2013-03-25 21:11:58 --> Loader Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:11:59 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:11:59 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:11:59 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:11:59 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:11:59 --> Session Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:11:59 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Session routines successfully run
DEBUG - 2013-03-25 21:11:59 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Controller Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:11:59 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Model Class Initialized
DEBUG - 2013-03-25 21:11:59 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:11:59 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:12:12 --> Config Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:12:12 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:12:12 --> URI Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Router Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Output Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Security Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Input Class Initialized
DEBUG - 2013-03-25 21:12:12 --> XSS Filtering completed
DEBUG - 2013-03-25 21:12:12 --> XSS Filtering completed
DEBUG - 2013-03-25 21:12:12 --> XSS Filtering completed
DEBUG - 2013-03-25 21:12:12 --> XSS Filtering completed
DEBUG - 2013-03-25 21:12:12 --> XSS Filtering completed
DEBUG - 2013-03-25 21:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:12:12 --> Language Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Loader Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:12:12 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:12:12 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:12:12 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:12:12 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:12:12 --> Session Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:12:12 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Session routines successfully run
DEBUG - 2013-03-25 21:12:12 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Controller Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Model Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Model Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:12:12 --> Model Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Model Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Model Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Model Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Model Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Model Class Initialized
DEBUG - 2013-03-25 21:12:12 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:12:12 --> Database Driver Class Initialized
ERROR - 2013-03-25 21:12:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/share.php:48) /opt/lampp/htdocs/cleverfigures/trunk/system/helpers/url_helper.php 542
DEBUG - 2013-03-25 21:17:27 --> Config Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:17:27 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:17:27 --> URI Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Router Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Output Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Security Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Input Class Initialized
DEBUG - 2013-03-25 21:17:27 --> XSS Filtering completed
DEBUG - 2013-03-25 21:17:27 --> XSS Filtering completed
DEBUG - 2013-03-25 21:17:27 --> XSS Filtering completed
DEBUG - 2013-03-25 21:17:27 --> XSS Filtering completed
DEBUG - 2013-03-25 21:17:27 --> XSS Filtering completed
DEBUG - 2013-03-25 21:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:17:27 --> Language Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Loader Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:17:27 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:17:27 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:17:27 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:17:27 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:17:27 --> Session Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:17:27 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Session routines successfully run
DEBUG - 2013-03-25 21:17:27 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Controller Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:17:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:27 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:17:27 --> Database Driver Class Initialized
ERROR - 2013-03-25 21:17:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/share.php:48) /opt/lampp/htdocs/cleverfigures/trunk/system/helpers/url_helper.php 542
DEBUG - 2013-03-25 21:17:38 --> Config Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:17:38 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:17:38 --> URI Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Router Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Output Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Security Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Input Class Initialized
DEBUG - 2013-03-25 21:17:38 --> XSS Filtering completed
DEBUG - 2013-03-25 21:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:17:38 --> Language Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Loader Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:17:38 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:17:38 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:17:38 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:17:38 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:17:38 --> Session Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:17:38 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Session routines successfully run
DEBUG - 2013-03-25 21:17:38 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Controller Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:17:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:38 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:17:38 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:17:38 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 21:17:38 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:17:38 --> Final output sent to browser
DEBUG - 2013-03-25 21:17:38 --> Total execution time: 0.0353
DEBUG - 2013-03-25 21:17:39 --> Config Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:17:39 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:17:39 --> URI Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Router Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Output Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Security Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Input Class Initialized
DEBUG - 2013-03-25 21:17:39 --> XSS Filtering completed
DEBUG - 2013-03-25 21:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:17:39 --> Language Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Loader Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:17:39 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:17:39 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:17:39 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:17:39 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:17:39 --> Session Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:17:39 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Session routines successfully run
DEBUG - 2013-03-25 21:17:39 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Controller Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:17:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:39 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:17:39 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:17:39 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:17:39 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 21:17:39 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:17:39 --> Final output sent to browser
DEBUG - 2013-03-25 21:17:39 --> Total execution time: 0.3019
DEBUG - 2013-03-25 21:17:40 --> Config Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:17:40 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:17:40 --> URI Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Router Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Output Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Security Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Input Class Initialized
DEBUG - 2013-03-25 21:17:40 --> XSS Filtering completed
DEBUG - 2013-03-25 21:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:17:40 --> Language Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Loader Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:17:40 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:17:40 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:17:40 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:17:40 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:17:40 --> Session Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:17:40 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Session routines successfully run
DEBUG - 2013-03-25 21:17:40 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Controller Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:17:40 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Model Class Initialized
DEBUG - 2013-03-25 21:17:40 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:17:40 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:20:06 --> Config Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:20:06 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:20:06 --> URI Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Router Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Output Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Security Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Input Class Initialized
DEBUG - 2013-03-25 21:20:06 --> XSS Filtering completed
DEBUG - 2013-03-25 21:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:20:06 --> Language Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Loader Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:20:06 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:20:06 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:20:06 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:20:06 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:20:06 --> Session Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:20:06 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Session routines successfully run
DEBUG - 2013-03-25 21:20:06 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Controller Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:20:06 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:06 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Config Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:20:17 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:20:17 --> URI Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Router Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Output Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Security Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Input Class Initialized
DEBUG - 2013-03-25 21:20:17 --> XSS Filtering completed
DEBUG - 2013-03-25 21:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:20:17 --> Language Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Loader Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:20:17 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:20:17 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:20:17 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:20:17 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:20:17 --> Session Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:20:17 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Session routines successfully run
DEBUG - 2013-03-25 21:20:17 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Controller Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:20:17 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:17 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:20:17 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:20:17 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 21:20:17 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:20:17 --> Final output sent to browser
DEBUG - 2013-03-25 21:20:17 --> Total execution time: 0.0492
DEBUG - 2013-03-25 21:20:19 --> Config Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:20:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:20:19 --> URI Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Router Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Output Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Security Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Input Class Initialized
DEBUG - 2013-03-25 21:20:19 --> XSS Filtering completed
DEBUG - 2013-03-25 21:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:20:19 --> Language Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Loader Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:20:19 --> Session Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:20:19 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Session routines successfully run
DEBUG - 2013-03-25 21:20:19 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Controller Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:20:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:20:19 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:20:19 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 21:20:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:20:19 --> Final output sent to browser
DEBUG - 2013-03-25 21:20:19 --> Total execution time: 0.2006
DEBUG - 2013-03-25 21:20:19 --> Config Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:20:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:20:19 --> URI Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Router Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Output Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Security Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Input Class Initialized
DEBUG - 2013-03-25 21:20:19 --> XSS Filtering completed
DEBUG - 2013-03-25 21:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:20:19 --> Language Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Loader Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:20:19 --> Session Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:20:19 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Session routines successfully run
DEBUG - 2013-03-25 21:20:19 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Controller Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:20:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:20:30 --> Config Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:20:30 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:20:30 --> URI Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Router Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Output Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Security Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Input Class Initialized
DEBUG - 2013-03-25 21:20:30 --> XSS Filtering completed
DEBUG - 2013-03-25 21:20:30 --> XSS Filtering completed
DEBUG - 2013-03-25 21:20:30 --> XSS Filtering completed
DEBUG - 2013-03-25 21:20:30 --> XSS Filtering completed
DEBUG - 2013-03-25 21:20:30 --> XSS Filtering completed
DEBUG - 2013-03-25 21:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:20:30 --> Language Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Loader Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:20:30 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:20:30 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:20:30 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:20:30 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:20:30 --> Session Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:20:30 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Session routines successfully run
DEBUG - 2013-03-25 21:20:30 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Controller Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:20:30 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Model Class Initialized
DEBUG - 2013-03-25 21:20:30 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:20:30 --> Database Driver Class Initialized
ERROR - 2013-03-25 21:20:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/share.php:48) /opt/lampp/htdocs/cleverfigures/trunk/system/helpers/url_helper.php 542
DEBUG - 2013-03-25 21:21:10 --> Config Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:21:10 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:21:10 --> URI Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Router Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Output Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Security Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Input Class Initialized
DEBUG - 2013-03-25 21:21:10 --> XSS Filtering completed
DEBUG - 2013-03-25 21:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:21:10 --> Language Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Loader Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:21:10 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:21:10 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:21:10 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:21:10 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:21:10 --> Session Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:21:10 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Session routines successfully run
DEBUG - 2013-03-25 21:21:10 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Controller Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:21:10 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:10 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:21:10 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:21:10 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:21:11 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 21:21:11 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:21:11 --> Final output sent to browser
DEBUG - 2013-03-25 21:21:11 --> Total execution time: 0.3549
DEBUG - 2013-03-25 21:21:11 --> Config Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:21:11 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:21:11 --> URI Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Router Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Output Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Security Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Input Class Initialized
DEBUG - 2013-03-25 21:21:11 --> XSS Filtering completed
DEBUG - 2013-03-25 21:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:21:11 --> Language Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Loader Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:21:11 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:21:11 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:21:11 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:21:11 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:21:11 --> Session Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:21:11 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Session routines successfully run
DEBUG - 2013-03-25 21:21:11 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Controller Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:21:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:11 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:21:11 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:21:18 --> Config Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:21:18 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:21:18 --> URI Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Router Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Output Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Security Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Input Class Initialized
DEBUG - 2013-03-25 21:21:18 --> XSS Filtering completed
DEBUG - 2013-03-25 21:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:21:18 --> Language Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Loader Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:21:18 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:21:18 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:21:18 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:21:18 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:21:18 --> Session Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:21:18 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Session routines successfully run
DEBUG - 2013-03-25 21:21:18 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Controller Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:21:18 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:18 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:21:18 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:21:18 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 21:21:18 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:21:18 --> Final output sent to browser
DEBUG - 2013-03-25 21:21:18 --> Total execution time: 0.0385
DEBUG - 2013-03-25 21:21:20 --> Config Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:21:20 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:21:20 --> URI Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Router Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Output Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Security Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Input Class Initialized
DEBUG - 2013-03-25 21:21:20 --> XSS Filtering completed
DEBUG - 2013-03-25 21:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:21:20 --> Language Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Loader Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:21:20 --> Session Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:21:20 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Session routines successfully run
DEBUG - 2013-03-25 21:21:20 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Controller Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:21:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:21:20 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:21:20 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 21:21:20 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:21:20 --> Final output sent to browser
DEBUG - 2013-03-25 21:21:20 --> Total execution time: 0.3386
DEBUG - 2013-03-25 21:21:20 --> Config Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:21:20 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:21:20 --> URI Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Router Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Output Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Security Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Input Class Initialized
DEBUG - 2013-03-25 21:21:20 --> XSS Filtering completed
DEBUG - 2013-03-25 21:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:21:20 --> Language Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Loader Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:21:20 --> Session Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:21:20 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Session routines successfully run
DEBUG - 2013-03-25 21:21:20 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Controller Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Model Class Initialized
DEBUG - 2013-03-25 21:21:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:21:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:25:32 --> Config Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:25:32 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:25:32 --> URI Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Router Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Output Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Security Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Input Class Initialized
DEBUG - 2013-03-25 21:25:32 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:25:32 --> Language Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Loader Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:25:32 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:25:32 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:25:32 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:25:32 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:25:32 --> Session Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:25:32 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Session routines successfully run
DEBUG - 2013-03-25 21:25:32 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Controller Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:25:32 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:32 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:25:32 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:25:32 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 21:25:32 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:25:32 --> Final output sent to browser
DEBUG - 2013-03-25 21:25:32 --> Total execution time: 0.0517
DEBUG - 2013-03-25 21:25:33 --> Config Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:25:33 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:25:33 --> URI Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Router Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Output Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Security Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Input Class Initialized
DEBUG - 2013-03-25 21:25:33 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:25:33 --> Language Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Loader Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:25:33 --> Session Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:25:33 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Session routines successfully run
DEBUG - 2013-03-25 21:25:33 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Controller Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:25:33 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:25:33 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:25:33 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 21:25:33 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:25:33 --> Final output sent to browser
DEBUG - 2013-03-25 21:25:33 --> Total execution time: 0.1368
DEBUG - 2013-03-25 21:25:33 --> Config Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:25:33 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:25:33 --> URI Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Router Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Output Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Security Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Input Class Initialized
DEBUG - 2013-03-25 21:25:33 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:25:33 --> Language Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Loader Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:25:33 --> Session Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:25:33 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Session routines successfully run
DEBUG - 2013-03-25 21:25:33 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Controller Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:33 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:25:33 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:25:38 --> Config Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:25:38 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:25:38 --> URI Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Router Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Output Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Security Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Input Class Initialized
DEBUG - 2013-03-25 21:25:38 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:38 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:38 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:38 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:38 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:25:38 --> Language Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Loader Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:25:38 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:25:38 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:25:38 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:25:38 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:25:38 --> Session Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:25:38 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Session routines successfully run
DEBUG - 2013-03-25 21:25:38 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Controller Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:25:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:38 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:25:38 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Config Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:25:39 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:25:39 --> URI Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Router Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Output Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Security Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Input Class Initialized
DEBUG - 2013-03-25 21:25:39 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:25:39 --> Language Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Loader Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:25:39 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:25:39 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:25:39 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:25:39 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:25:39 --> Session Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:25:39 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Session routines successfully run
DEBUG - 2013-03-25 21:25:39 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Controller Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:25:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:39 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:25:39 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:25:39 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 21:25:39 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:25:39 --> Final output sent to browser
DEBUG - 2013-03-25 21:25:39 --> Total execution time: 0.0443
DEBUG - 2013-03-25 21:25:45 --> Config Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:25:45 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:25:45 --> URI Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Router Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Output Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Security Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Input Class Initialized
DEBUG - 2013-03-25 21:25:45 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:25:45 --> Language Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Loader Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:25:45 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:25:45 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:25:45 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:25:45 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:25:45 --> Session Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:25:45 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Session routines successfully run
DEBUG - 2013-03-25 21:25:45 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Controller Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:25:45 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:45 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:25:45 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:25:45 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:25:45 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 21:25:45 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:25:45 --> Final output sent to browser
DEBUG - 2013-03-25 21:25:45 --> Total execution time: 0.2995
DEBUG - 2013-03-25 21:25:46 --> Config Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:25:46 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:25:46 --> URI Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Router Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Output Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Security Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Input Class Initialized
DEBUG - 2013-03-25 21:25:46 --> XSS Filtering completed
DEBUG - 2013-03-25 21:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:25:46 --> Language Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Loader Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:25:46 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:25:46 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:25:46 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:25:46 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:25:46 --> Session Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:25:46 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Session routines successfully run
DEBUG - 2013-03-25 21:25:46 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Controller Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:25:46 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Model Class Initialized
DEBUG - 2013-03-25 21:25:46 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:25:46 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:26:07 --> Config Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:26:07 --> URI Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Router Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Output Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Security Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Input Class Initialized
DEBUG - 2013-03-25 21:26:07 --> XSS Filtering completed
DEBUG - 2013-03-25 21:26:07 --> XSS Filtering completed
DEBUG - 2013-03-25 21:26:07 --> XSS Filtering completed
DEBUG - 2013-03-25 21:26:07 --> XSS Filtering completed
DEBUG - 2013-03-25 21:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:26:07 --> Language Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Loader Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:26:07 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:26:07 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:26:07 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:26:07 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:26:07 --> Session Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:26:07 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Session routines successfully run
DEBUG - 2013-03-25 21:26:07 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Controller Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:26:07 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:07 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:26:07 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Config Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:26:08 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:26:08 --> URI Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Router Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Output Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Security Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Input Class Initialized
DEBUG - 2013-03-25 21:26:08 --> XSS Filtering completed
DEBUG - 2013-03-25 21:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:26:08 --> Language Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Loader Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:26:08 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:26:08 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:26:08 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:26:08 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:26:08 --> Session Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:26:08 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Session routines successfully run
DEBUG - 2013-03-25 21:26:08 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Controller Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:26:08 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:08 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:26:08 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:26:08 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 21:26:08 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:26:08 --> Final output sent to browser
DEBUG - 2013-03-25 21:26:08 --> Total execution time: 0.0497
DEBUG - 2013-03-25 21:26:11 --> Config Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:26:11 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:26:11 --> URI Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Router Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Output Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Security Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Input Class Initialized
DEBUG - 2013-03-25 21:26:11 --> XSS Filtering completed
DEBUG - 2013-03-25 21:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:26:11 --> Language Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Loader Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:26:11 --> Session Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:26:11 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Session routines successfully run
DEBUG - 2013-03-25 21:26:11 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Controller Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:26:11 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 21:26:11 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:26:11 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 21:26:11 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 21:26:11 --> Final output sent to browser
DEBUG - 2013-03-25 21:26:11 --> Total execution time: 0.2714
DEBUG - 2013-03-25 21:26:11 --> Config Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Hooks Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Utf8 Class Initialized
DEBUG - 2013-03-25 21:26:11 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 21:26:11 --> URI Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Router Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Output Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Security Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Input Class Initialized
DEBUG - 2013-03-25 21:26:11 --> XSS Filtering completed
DEBUG - 2013-03-25 21:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 21:26:11 --> Language Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Loader Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: date_helper
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: form_helper
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: language_helper
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: url_helper
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: html_helper
DEBUG - 2013-03-25 21:26:11 --> Session Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: string_helper
DEBUG - 2013-03-25 21:26:11 --> Encrypt Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Session routines successfully run
DEBUG - 2013-03-25 21:26:11 --> Form Validation Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Controller Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Database Driver Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Helper loaded: file_helper
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Model Class Initialized
DEBUG - 2013-03-25 21:26:11 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 21:26:11 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:07:54 --> Config Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:07:54 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:07:54 --> URI Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Router Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Output Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Security Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Input Class Initialized
DEBUG - 2013-03-25 22:07:54 --> XSS Filtering completed
DEBUG - 2013-03-25 22:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:07:54 --> Language Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Loader Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:07:54 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:07:54 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:07:54 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:07:54 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:07:54 --> Session Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:07:54 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Session routines successfully run
DEBUG - 2013-03-25 22:07:54 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Controller Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:07:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:54 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:07:54 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:07:54 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 22:07:54 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:07:54 --> Final output sent to browser
DEBUG - 2013-03-25 22:07:54 --> Total execution time: 0.0460
DEBUG - 2013-03-25 22:07:55 --> Config Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:07:55 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:07:55 --> URI Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Router Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Output Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Security Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Input Class Initialized
DEBUG - 2013-03-25 22:07:55 --> XSS Filtering completed
DEBUG - 2013-03-25 22:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:07:55 --> Language Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Loader Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:07:55 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:07:55 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:07:55 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:07:55 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:07:55 --> Session Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:07:55 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Session routines successfully run
DEBUG - 2013-03-25 22:07:55 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Controller Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:07:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:55 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:07:55 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:07:55 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:07:56 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 22:07:56 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:07:56 --> Final output sent to browser
DEBUG - 2013-03-25 22:07:56 --> Total execution time: 0.1398
DEBUG - 2013-03-25 22:07:56 --> Config Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:07:56 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:07:56 --> URI Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Router Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Output Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Security Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Input Class Initialized
DEBUG - 2013-03-25 22:07:56 --> XSS Filtering completed
DEBUG - 2013-03-25 22:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:07:56 --> Language Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Loader Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:07:56 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:07:56 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:07:56 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:07:56 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:07:56 --> Session Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:07:56 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Session routines successfully run
DEBUG - 2013-03-25 22:07:56 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Controller Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:07:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:07:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:07:56 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:08:19 --> Config Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:08:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:08:19 --> URI Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Router Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Output Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Security Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Input Class Initialized
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:08:19 --> Language Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Loader Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:08:19 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:08:19 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:08:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:08:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:08:19 --> Session Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:08:19 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Session routines successfully run
DEBUG - 2013-03-25 22:08:19 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Controller Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:08:19 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:08:19 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Config Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:08:38 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:08:38 --> URI Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Router Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Output Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Security Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Input Class Initialized
DEBUG - 2013-03-25 22:08:38 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:08:38 --> Language Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Loader Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:08:38 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:08:38 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:08:38 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:08:38 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:08:38 --> Session Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:08:38 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Session routines successfully run
DEBUG - 2013-03-25 22:08:38 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Controller Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:08:38 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:38 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:08:38 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:08:38 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 22:08:38 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:08:38 --> Final output sent to browser
DEBUG - 2013-03-25 22:08:38 --> Total execution time: 0.0395
DEBUG - 2013-03-25 22:08:41 --> Config Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:08:41 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:08:41 --> URI Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Router Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Output Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Security Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Input Class Initialized
DEBUG - 2013-03-25 22:08:41 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:08:41 --> Language Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Loader Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:08:41 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:08:41 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:08:41 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:08:41 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:08:41 --> Session Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:08:41 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Session routines successfully run
DEBUG - 2013-03-25 22:08:41 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Controller Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:08:41 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:41 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:08:41 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:08:41 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:08:42 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 22:08:42 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:08:42 --> Final output sent to browser
DEBUG - 2013-03-25 22:08:42 --> Total execution time: 1.3327
DEBUG - 2013-03-25 22:08:43 --> Config Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:08:43 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:08:43 --> URI Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Router Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Output Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Security Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Input Class Initialized
DEBUG - 2013-03-25 22:08:43 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:08:43 --> Language Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Loader Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:08:43 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:08:43 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:08:43 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:08:43 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:08:43 --> Session Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:08:43 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Session routines successfully run
DEBUG - 2013-03-25 22:08:43 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Controller Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:08:43 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:43 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:08:43 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:08:56 --> Config Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:08:56 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:08:56 --> URI Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Router Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Output Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Security Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Input Class Initialized
DEBUG - 2013-03-25 22:08:56 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:56 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:56 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:56 --> XSS Filtering completed
DEBUG - 2013-03-25 22:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:08:56 --> Language Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Loader Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:08:56 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:08:56 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:08:56 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:08:56 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:08:56 --> Session Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:08:56 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Session routines successfully run
DEBUG - 2013-03-25 22:08:56 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Controller Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:08:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Model Class Initialized
DEBUG - 2013-03-25 22:08:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:08:56 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Config Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:09:16 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:09:16 --> URI Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Router Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Output Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Security Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Input Class Initialized
DEBUG - 2013-03-25 22:09:16 --> XSS Filtering completed
DEBUG - 2013-03-25 22:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:09:16 --> Language Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Loader Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:09:16 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:09:16 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:09:16 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:09:16 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:09:16 --> Session Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:09:16 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Session routines successfully run
DEBUG - 2013-03-25 22:09:16 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Controller Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Model Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Model Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:09:16 --> Model Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Model Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Model Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Model Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Model Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Model Class Initialized
DEBUG - 2013-03-25 22:09:16 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:09:16 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:09:16 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 22:09:16 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:09:16 --> Final output sent to browser
DEBUG - 2013-03-25 22:09:16 --> Total execution time: 0.0512
DEBUG - 2013-03-25 22:15:28 --> Config Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:15:28 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:15:28 --> URI Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Router Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Output Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Security Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Input Class Initialized
DEBUG - 2013-03-25 22:15:28 --> XSS Filtering completed
DEBUG - 2013-03-25 22:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:15:28 --> Language Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Loader Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:15:28 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:15:28 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:15:28 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:15:28 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:15:28 --> Session Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:15:28 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Session routines successfully run
DEBUG - 2013-03-25 22:15:28 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Controller Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:15:28 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:28 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:15:28 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:15:28 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:15:29 --> File loaded: application/views/content/sharing_view.php
DEBUG - 2013-03-25 22:15:29 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:15:29 --> Final output sent to browser
DEBUG - 2013-03-25 22:15:29 --> Total execution time: 0.2449
DEBUG - 2013-03-25 22:15:29 --> Config Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:15:29 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:15:29 --> URI Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Router Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Output Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Security Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Input Class Initialized
DEBUG - 2013-03-25 22:15:29 --> XSS Filtering completed
DEBUG - 2013-03-25 22:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:15:29 --> Language Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Loader Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:15:29 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:15:29 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:15:29 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:15:29 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:15:29 --> Session Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:15:29 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Session routines successfully run
DEBUG - 2013-03-25 22:15:29 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Controller Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:15:29 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:29 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:15:29 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:15:36 --> Config Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:15:36 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:15:36 --> URI Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Router Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Output Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Security Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Input Class Initialized
DEBUG - 2013-03-25 22:15:36 --> XSS Filtering completed
DEBUG - 2013-03-25 22:15:36 --> XSS Filtering completed
DEBUG - 2013-03-25 22:15:36 --> XSS Filtering completed
DEBUG - 2013-03-25 22:15:36 --> XSS Filtering completed
DEBUG - 2013-03-25 22:15:36 --> XSS Filtering completed
DEBUG - 2013-03-25 22:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:15:36 --> Language Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Loader Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:15:36 --> Session Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:15:36 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Session routines successfully run
DEBUG - 2013-03-25 22:15:36 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Controller Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:15:36 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Config Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:15:36 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:15:36 --> URI Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Router Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Output Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Security Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Input Class Initialized
DEBUG - 2013-03-25 22:15:36 --> XSS Filtering completed
DEBUG - 2013-03-25 22:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:15:36 --> Language Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Loader Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:15:36 --> Session Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:15:36 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Session routines successfully run
DEBUG - 2013-03-25 22:15:36 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Controller Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Model Class Initialized
DEBUG - 2013-03-25 22:15:36 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:15:36 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:15:36 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 22:15:36 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:15:36 --> Final output sent to browser
DEBUG - 2013-03-25 22:15:36 --> Total execution time: 0.0437
DEBUG - 2013-03-25 22:18:19 --> Config Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:18:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:18:19 --> URI Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Router Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Output Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Security Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Input Class Initialized
DEBUG - 2013-03-25 22:18:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:18:19 --> Language Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Loader Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:18:19 --> Session Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:18:19 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Session routines successfully run
DEBUG - 2013-03-25 22:18:19 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Controller Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:18:19 --> Config Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:18:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:18:19 --> URI Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Router Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Output Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Security Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Input Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:18:19 --> Language Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Loader Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:18:19 --> Session Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:18:19 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:18:19 --> A session cookie was not found.
DEBUG - 2013-03-25 22:18:19 --> Session routines successfully run
DEBUG - 2013-03-25 22:18:19 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Controller Class Initialized
DEBUG - 2013-03-25 22:18:19 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:18:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:18:19 --> File loaded: application/views/content/login_view.php
DEBUG - 2013-03-25 22:18:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:18:19 --> Final output sent to browser
DEBUG - 2013-03-25 22:18:19 --> Total execution time: 0.0187
DEBUG - 2013-03-25 22:18:26 --> Config Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:18:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:18:26 --> URI Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Router Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Output Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Security Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Input Class Initialized
DEBUG - 2013-03-25 22:18:26 --> XSS Filtering completed
DEBUG - 2013-03-25 22:18:26 --> XSS Filtering completed
DEBUG - 2013-03-25 22:18:26 --> XSS Filtering completed
DEBUG - 2013-03-25 22:18:26 --> XSS Filtering completed
DEBUG - 2013-03-25 22:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:18:26 --> Language Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Loader Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:18:26 --> Session Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:18:26 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Session routines successfully run
DEBUG - 2013-03-25 22:18:26 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Controller Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:18:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Config Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:18:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:18:26 --> URI Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Router Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Output Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Security Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Input Class Initialized
DEBUG - 2013-03-25 22:18:26 --> XSS Filtering completed
DEBUG - 2013-03-25 22:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:18:26 --> Language Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Loader Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:18:26 --> Session Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:18:26 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Session routines successfully run
DEBUG - 2013-03-25 22:18:26 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Controller Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:18:26 --> Model Class Initialized
ERROR - 2013-03-25 22:18:26 --> Severity: Notice  --> Undefined property: stdClass::$analisis_date /opt/lampp/htdocs/cleverfigures/trunk/application/models/student_model.php 79
ERROR - 2013-03-25 22:18:26 --> Severity: Notice  --> Undefined property: Student::$analisis_model /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/student.php 43
DEBUG - 2013-03-25 22:19:25 --> Config Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:19:25 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:19:25 --> URI Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Router Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Output Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Security Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Input Class Initialized
DEBUG - 2013-03-25 22:19:25 --> XSS Filtering completed
DEBUG - 2013-03-25 22:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:19:25 --> Language Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Loader Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:19:25 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:19:25 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:19:25 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:19:25 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:19:25 --> Session Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:19:25 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Session routines successfully run
DEBUG - 2013-03-25 22:19:25 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Controller Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:19:25 --> Model Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Model Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Model Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Model Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:19:25 --> Model Class Initialized
DEBUG - 2013-03-25 22:19:25 --> Model Class Initialized
ERROR - 2013-03-25 22:19:25 --> Severity: Notice  --> Undefined property: Student::$analisis_model /opt/lampp/htdocs/cleverfigures/trunk/application/controllers/student.php 43
DEBUG - 2013-03-25 22:20:45 --> Config Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:20:45 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:20:45 --> URI Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Router Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Output Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Security Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Input Class Initialized
DEBUG - 2013-03-25 22:20:45 --> XSS Filtering completed
DEBUG - 2013-03-25 22:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:20:45 --> Language Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Loader Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:20:45 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:20:45 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:20:45 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:20:45 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:20:45 --> Session Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:20:45 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Session routines successfully run
DEBUG - 2013-03-25 22:20:45 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Controller Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:20:45 --> Model Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Model Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Model Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Model Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:20:45 --> Model Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Model Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Model Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Model Class Initialized
DEBUG - 2013-03-25 22:20:45 --> Model Class Initialized
DEBUG - 2013-03-25 22:20:45 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:20:45 --> File loaded: application/views/content/student_view.php
DEBUG - 2013-03-25 22:20:45 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:20:45 --> Final output sent to browser
DEBUG - 2013-03-25 22:20:45 --> Total execution time: 0.0559
DEBUG - 2013-03-25 22:29:44 --> Config Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:29:44 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:29:44 --> URI Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Router Class Initialized
DEBUG - 2013-03-25 22:29:44 --> No URI present. Default controller set.
DEBUG - 2013-03-25 22:29:44 --> Output Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Security Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Input Class Initialized
DEBUG - 2013-03-25 22:29:44 --> XSS Filtering completed
DEBUG - 2013-03-25 22:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:29:44 --> Language Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Loader Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:29:44 --> Session Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:29:44 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Session routines successfully run
DEBUG - 2013-03-25 22:29:44 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Controller Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Database Forge Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Database Forge Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Database Utility Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Config Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:29:44 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:29:44 --> URI Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Router Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Output Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Security Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Input Class Initialized
DEBUG - 2013-03-25 22:29:44 --> XSS Filtering completed
DEBUG - 2013-03-25 22:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:29:44 --> Language Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Loader Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:29:44 --> Session Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:29:44 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Session routines successfully run
DEBUG - 2013-03-25 22:29:44 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Controller Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:44 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:29:44 --> File loaded: application/views/content/student_view.php
DEBUG - 2013-03-25 22:29:44 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:29:44 --> Final output sent to browser
DEBUG - 2013-03-25 22:29:44 --> Total execution time: 0.0382
DEBUG - 2013-03-25 22:29:54 --> Config Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:29:54 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:29:54 --> URI Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Router Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Output Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Security Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Input Class Initialized
DEBUG - 2013-03-25 22:29:54 --> XSS Filtering completed
DEBUG - 2013-03-25 22:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:29:54 --> Language Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Loader Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:29:54 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:29:54 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:29:54 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:29:54 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:29:54 --> Session Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:29:54 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Session routines successfully run
DEBUG - 2013-03-25 22:29:54 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Controller Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:29:54 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:29:54 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:29:55 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:29:55 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:30:01 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2013-03-25 22:30:01 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:30:01 --> Final output sent to browser
DEBUG - 2013-03-25 22:30:01 --> Total execution time: 6.9239
DEBUG - 2013-03-25 22:30:02 --> Config Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:30:02 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:30:02 --> URI Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Router Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Output Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Security Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Input Class Initialized
DEBUG - 2013-03-25 22:30:02 --> XSS Filtering completed
DEBUG - 2013-03-25 22:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:30:02 --> Language Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Loader Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:30:02 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:30:02 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:30:02 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:30:02 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:30:02 --> Session Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:30:02 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Session routines successfully run
DEBUG - 2013-03-25 22:30:02 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Controller Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:02 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:30:02 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 40
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 40
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 77
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 77
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 113
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 113
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 143
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 143
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 191
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 191
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 212
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 212
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 233
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 233
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 254
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 254
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 275
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 275
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 440
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 441
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 442
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 443
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 444
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 445
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 446
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 458
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 459
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 460
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 461
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 462
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 463
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 464
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 476
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 477
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 478
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 479
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 480
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 481
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 482
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 494
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 495
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 495
ERROR - 2013-03-25 22:30:02 --> Severity: Notice  --> Undefined index: useredits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-25 22:30:02 --> Severity: Notice  --> Undefined index: pageedits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 589
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 589
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 589
ERROR - 2013-03-25 22:30:02 --> Severity: Notice  --> Undefined index: useredits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 682
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 682
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 682
ERROR - 2013-03-25 22:30:02 --> Severity: Notice  --> Undefined index: pageedits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 691
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 691
ERROR - 2013-03-25 22:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 691
ERROR - 2013-03-25 22:30:02 --> Severity: Notice  --> Undefined index: wikiname /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 764
DEBUG - 2013-03-25 22:30:02 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2013-03-25 22:30:02 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:30:02 --> Final output sent to browser
DEBUG - 2013-03-25 22:30:02 --> Total execution time: 0.0478
DEBUG - 2013-03-25 22:30:05 --> Config Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:30:05 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:30:05 --> URI Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Router Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Output Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Security Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Input Class Initialized
DEBUG - 2013-03-25 22:30:05 --> XSS Filtering completed
DEBUG - 2013-03-25 22:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:30:05 --> Language Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Loader Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:30:05 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:30:05 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:30:05 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:30:05 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:30:05 --> Session Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:30:05 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Session routines successfully run
DEBUG - 2013-03-25 22:30:05 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Controller Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:30:05 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Model Class Initialized
DEBUG - 2013-03-25 22:30:05 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:30:05 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 40
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 40
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 77
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 77
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 113
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 113
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 143
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 143
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 191
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 191
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 212
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 212
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 233
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 233
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 254
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 254
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 275
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 275
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 440
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 441
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 442
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 443
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 444
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 445
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 446
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 458
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 459
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 460
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 461
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 462
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 463
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 464
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 476
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 477
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 478
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 479
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 480
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 481
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 482
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 494
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 495
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 495
ERROR - 2013-03-25 22:30:05 --> Severity: Notice  --> Undefined index: useredits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-25 22:30:05 --> Severity: Notice  --> Undefined index: pageedits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 589
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 589
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 589
ERROR - 2013-03-25 22:30:05 --> Severity: Notice  --> Undefined index: useredits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 682
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 682
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 682
ERROR - 2013-03-25 22:30:05 --> Severity: Notice  --> Undefined index: pageedits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 691
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 691
ERROR - 2013-03-25 22:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 691
ERROR - 2013-03-25 22:30:05 --> Severity: Notice  --> Undefined index: wikiname /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 764
DEBUG - 2013-03-25 22:30:05 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2013-03-25 22:30:05 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:30:05 --> Final output sent to browser
DEBUG - 2013-03-25 22:30:05 --> Total execution time: 0.0427
DEBUG - 2013-03-25 22:47:23 --> Config Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:47:23 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:47:23 --> URI Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Router Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Output Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Security Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Input Class Initialized
DEBUG - 2013-03-25 22:47:23 --> XSS Filtering completed
DEBUG - 2013-03-25 22:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:47:23 --> Language Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Loader Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:47:23 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:47:23 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:47:23 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:47:23 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:47:23 --> Session Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:47:23 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Session routines successfully run
DEBUG - 2013-03-25 22:47:23 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Controller Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:47:23 --> Model Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Model Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Model Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Model Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:47:23 --> Model Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Model Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Model Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Model Class Initialized
DEBUG - 2013-03-25 22:47:23 --> Model Class Initialized
ERROR - 2013-03-25 22:47:23 --> Could not find the language line "voc.i18n_report_list"
DEBUG - 2013-03-25 22:47:23 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:47:23 --> File loaded: application/views/content/student_view.php
DEBUG - 2013-03-25 22:47:23 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:47:23 --> Final output sent to browser
DEBUG - 2013-03-25 22:47:23 --> Total execution time: 0.0406
DEBUG - 2013-03-25 22:50:51 --> Config Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:50:51 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:50:51 --> URI Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Router Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Output Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Security Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Input Class Initialized
DEBUG - 2013-03-25 22:50:51 --> XSS Filtering completed
DEBUG - 2013-03-25 22:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:50:51 --> Language Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Loader Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:50:51 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:50:51 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:50:51 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:50:51 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:50:51 --> Session Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:50:51 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Session routines successfully run
DEBUG - 2013-03-25 22:50:51 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Controller Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:50:51 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:50:51 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:51 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:51 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:50:51 --> File loaded: application/views/content/student_view.php
DEBUG - 2013-03-25 22:50:51 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:50:51 --> Final output sent to browser
DEBUG - 2013-03-25 22:50:51 --> Total execution time: 0.0410
DEBUG - 2013-03-25 22:50:55 --> Config Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:50:55 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:50:55 --> URI Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Router Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Output Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Security Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Input Class Initialized
DEBUG - 2013-03-25 22:50:55 --> XSS Filtering completed
DEBUG - 2013-03-25 22:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:50:55 --> Language Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Loader Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:50:55 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:50:55 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:50:55 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:50:55 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:50:55 --> Session Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:50:55 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Session routines successfully run
DEBUG - 2013-03-25 22:50:55 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Controller Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:50:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:50:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:55 --> Model Class Initialized
DEBUG - 2013-03-25 22:50:55 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:50:55 --> File loaded: application/views/content/student_view.php
DEBUG - 2013-03-25 22:50:55 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:50:55 --> Final output sent to browser
DEBUG - 2013-03-25 22:50:55 --> Total execution time: 0.0451
DEBUG - 2013-03-25 22:51:46 --> Config Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:51:46 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:51:46 --> URI Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Router Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Output Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Security Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Input Class Initialized
DEBUG - 2013-03-25 22:51:46 --> XSS Filtering completed
DEBUG - 2013-03-25 22:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:51:46 --> Language Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Loader Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:51:46 --> Session Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:51:46 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Session routines successfully run
DEBUG - 2013-03-25 22:51:46 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Controller Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:51:46 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: anom1 /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 328
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 328
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 328
DEBUG - 2013-03-25 22:51:46 --> File loaded: application/views/content/useranalisis_view.php
DEBUG - 2013-03-25 22:51:46 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:51:46 --> Final output sent to browser
DEBUG - 2013-03-25 22:51:46 --> Total execution time: 0.2036
DEBUG - 2013-03-25 22:51:46 --> Config Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:51:46 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:51:46 --> URI Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Router Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Output Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Security Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Input Class Initialized
DEBUG - 2013-03-25 22:51:46 --> XSS Filtering completed
DEBUG - 2013-03-25 22:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:51:46 --> Language Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Loader Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:51:46 --> Session Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:51:46 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Session routines successfully run
DEBUG - 2013-03-25 22:51:46 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Controller Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Config Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:51:46 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> URI Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Router Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:51:46 --> Output Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Security Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Input Class Initialized
DEBUG - 2013-03-25 22:51:46 --> XSS Filtering completed
DEBUG - 2013-03-25 22:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:51:46 --> Language Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Loader Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:51:46 --> Session Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:51:46 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Session routines successfully run
DEBUG - 2013-03-25 22:51:46 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Controller Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Model Class Initialized
DEBUG - 2013-03-25 22:51:46 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:51:46 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 27
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 33
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 39
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 45
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 51
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 57
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 63
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 70
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 76
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 84
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 90
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 96
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 104
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 111
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 120
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 130
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 131
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 132
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 133
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 134
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 136
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 136
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 136
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 145
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 145
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 146
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 146
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 154
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 155
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 156
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 157
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 159
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 159
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 159
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 168
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 168
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 169
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 169
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 177
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 180
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 180
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 180
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 189
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 194
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 194
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 195
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 195
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 195
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 198
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 201
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 201
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 201
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 210
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 215
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 215
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 216
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 216
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 216
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 219
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 222
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 222
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 222
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 231
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 236
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 236
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 237
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 237
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 237
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 239
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 242
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 242
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 242
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 251
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 256
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 256
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 257
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 257
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 257
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 259
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 262
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 262
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 262
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 271
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 276
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 276
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 277
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 277
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 277
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 437
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 438
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 439
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 440
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 441
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 442
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 443
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 444
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 445
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 446
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 447
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 447
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 447
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 471
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 471
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 472
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 472
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 494
DEBUG - 2013-03-25 22:51:46 --> File loaded: application/views/content/useranalisis_view.php
DEBUG - 2013-03-25 22:51:46 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:51:46 --> Final output sent to browser
DEBUG - 2013-03-25 22:51:46 --> Total execution time: 0.2064
DEBUG - 2013-03-25 22:51:46 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 27
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 33
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 39
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 45
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 51
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 57
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 63
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 70
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 76
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 84
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 90
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 96
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 104
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 111
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 120
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 130
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 131
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 132
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 133
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 134
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 136
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 136
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 136
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 145
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 145
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 146
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 146
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 154
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 155
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 156
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 157
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 159
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 159
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 159
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 168
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 168
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 169
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 169
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 177
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 180
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 180
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 180
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 189
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 194
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 194
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 195
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 195
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 195
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 198
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 201
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 201
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 201
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 210
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 215
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 215
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 216
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 216
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 216
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 219
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 222
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 222
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 222
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 231
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 236
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 236
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 237
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 237
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 237
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 239
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 242
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 242
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 242
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 251
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 256
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 256
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 257
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 257
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 257
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 259
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 262
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 262
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 262
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 271
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 276
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 276
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 277
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 277
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 277
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 437
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 438
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 439
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 440
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 441
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 442
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 443
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 444
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 445
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 446
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 447
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 447
ERROR - 2013-03-25 22:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 447
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 471
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 471
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 472
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 472
ERROR - 2013-03-25 22:51:46 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 494
DEBUG - 2013-03-25 22:51:46 --> File loaded: application/views/content/useranalisis_view.php
DEBUG - 2013-03-25 22:51:46 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:51:46 --> Final output sent to browser
DEBUG - 2013-03-25 22:51:46 --> Total execution time: 0.2037
DEBUG - 2013-03-25 22:56:58 --> Config Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:56:58 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:56:58 --> URI Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Router Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Output Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Security Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Input Class Initialized
DEBUG - 2013-03-25 22:56:58 --> XSS Filtering completed
DEBUG - 2013-03-25 22:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:56:58 --> Language Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Loader Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:56:58 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:56:58 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:56:58 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:56:58 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:56:58 --> Session Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:56:58 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Session routines successfully run
DEBUG - 2013-03-25 22:56:58 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Controller Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Model Class Initialized
DEBUG - 2013-03-25 22:56:58 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:56:58 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:56:58 --> File loaded: application/views/content/useranalisis_view.php
DEBUG - 2013-03-25 22:56:58 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:56:58 --> Final output sent to browser
DEBUG - 2013-03-25 22:56:58 --> Total execution time: 0.1874
DEBUG - 2013-03-25 22:57:01 --> Config Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:57:01 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:57:01 --> URI Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Router Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Output Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Security Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Input Class Initialized
DEBUG - 2013-03-25 22:57:01 --> XSS Filtering completed
DEBUG - 2013-03-25 22:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:57:01 --> Language Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Loader Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:57:01 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:57:01 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:57:01 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:57:01 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:57:01 --> Session Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:57:01 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Session routines successfully run
DEBUG - 2013-03-25 22:57:01 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Controller Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Model Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Model Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:57:01 --> Model Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Model Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Model Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Model Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Model Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Model Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Model Class Initialized
DEBUG - 2013-03-25 22:57:01 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:57:01 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 27
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 33
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 39
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 45
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 51
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 57
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 63
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 70
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 76
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 84
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 90
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 96
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 104
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 111
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 120
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 130
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 131
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 132
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 133
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 134
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 136
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 136
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 136
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 145
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 145
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 146
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 146
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 154
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 155
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 156
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 157
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 159
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 159
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 159
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 168
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 168
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 169
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 169
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 177
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 180
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 180
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 180
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 189
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 194
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 194
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 195
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 195
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 195
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 198
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 201
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 201
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 201
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 210
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 215
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 215
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 216
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 216
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 216
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 219
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 222
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 222
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 222
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 231
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 236
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 236
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 237
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 237
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 237
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 239
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 242
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 242
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 242
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 251
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 256
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 256
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 257
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 257
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 257
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 259
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 262
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 262
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 262
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 271
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 276
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 276
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 277
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 277
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 277
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 438
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 439
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 440
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 441
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 442
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 443
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 444
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 445
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 446
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 447
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 448
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 448
ERROR - 2013-03-25 22:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 448
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 472
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 472
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 473
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 473
ERROR - 2013-03-25 22:57:01 --> Severity: Notice  --> Undefined index: images /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/useranalisis_view.php 495
DEBUG - 2013-03-25 22:57:01 --> File loaded: application/views/content/useranalisis_view.php
DEBUG - 2013-03-25 22:57:01 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:57:01 --> Final output sent to browser
DEBUG - 2013-03-25 22:57:01 --> Total execution time: 0.2017
DEBUG - 2013-03-25 22:59:19 --> Config Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:59:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:59:19 --> URI Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Router Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Output Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Security Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Input Class Initialized
DEBUG - 2013-03-25 22:59:19 --> XSS Filtering completed
DEBUG - 2013-03-25 22:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:59:19 --> Language Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Loader Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:59:19 --> Session Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:59:19 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Session routines successfully run
DEBUG - 2013-03-25 22:59:19 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Controller Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:59:19 --> Config Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:59:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:59:19 --> URI Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Router Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Output Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Security Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Input Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:59:19 --> Language Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Loader Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:59:19 --> Session Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:59:19 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:59:19 --> A session cookie was not found.
DEBUG - 2013-03-25 22:59:19 --> Session routines successfully run
DEBUG - 2013-03-25 22:59:19 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Controller Class Initialized
DEBUG - 2013-03-25 22:59:19 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:59:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:59:19 --> File loaded: application/views/content/login_view.php
DEBUG - 2013-03-25 22:59:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:59:19 --> Final output sent to browser
DEBUG - 2013-03-25 22:59:19 --> Total execution time: 0.0236
DEBUG - 2013-03-25 22:59:22 --> Config Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:59:22 --> URI Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Router Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Output Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Security Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Input Class Initialized
DEBUG - 2013-03-25 22:59:22 --> XSS Filtering completed
DEBUG - 2013-03-25 22:59:22 --> XSS Filtering completed
DEBUG - 2013-03-25 22:59:22 --> XSS Filtering completed
DEBUG - 2013-03-25 22:59:22 --> XSS Filtering completed
DEBUG - 2013-03-25 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:59:22 --> Language Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Loader Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:59:22 --> Session Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:59:22 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Session routines successfully run
DEBUG - 2013-03-25 22:59:22 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Controller Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Language file loaded: language/spanish/voc_lang.php
DEBUG - 2013-03-25 22:59:22 --> Config Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:59:22 --> URI Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Router Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Output Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Security Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Input Class Initialized
DEBUG - 2013-03-25 22:59:22 --> XSS Filtering completed
DEBUG - 2013-03-25 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:59:22 --> Language Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Loader Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:59:22 --> Session Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:59:22 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Session routines successfully run
DEBUG - 2013-03-25 22:59:22 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Controller Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:59:22 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:59:22 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 22:59:22 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:59:22 --> Final output sent to browser
DEBUG - 2013-03-25 22:59:22 --> Total execution time: 0.0470
DEBUG - 2013-03-25 22:59:26 --> Config Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:59:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:59:26 --> URI Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Router Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Output Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Security Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Input Class Initialized
DEBUG - 2013-03-25 22:59:26 --> XSS Filtering completed
DEBUG - 2013-03-25 22:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:59:26 --> Language Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Loader Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:59:26 --> Session Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:59:26 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Session routines successfully run
DEBUG - 2013-03-25 22:59:26 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Controller Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Language file loaded: language/english/voc_lang.php
ERROR - 2013-03-25 22:59:26 --> Severity: Warning  --> opendir(analisis/1364238605): failed to open dir: No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/system/helpers/file_helper.php 126
ERROR - 2013-03-25 22:59:26 --> Severity: Warning  --> rmdir(analisis/1364238605/): No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/application/models/analisis_model.php 60
DEBUG - 2013-03-25 22:59:26 --> Config Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Hooks Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Utf8 Class Initialized
DEBUG - 2013-03-25 22:59:26 --> UTF-8 Support Enabled
DEBUG - 2013-03-25 22:59:26 --> URI Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Router Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Output Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Security Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Input Class Initialized
DEBUG - 2013-03-25 22:59:26 --> XSS Filtering completed
DEBUG - 2013-03-25 22:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-25 22:59:26 --> Language Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Loader Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: date_helper
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: form_helper
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: language_helper
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: url_helper
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: html_helper
DEBUG - 2013-03-25 22:59:26 --> Session Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: string_helper
DEBUG - 2013-03-25 22:59:26 --> Encrypt Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Session routines successfully run
DEBUG - 2013-03-25 22:59:26 --> Form Validation Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Controller Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Database Driver Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Helper loaded: file_helper
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Model Class Initialized
DEBUG - 2013-03-25 22:59:26 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-25 22:59:27 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-25 22:59:27 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-25 22:59:27 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-25 22:59:27 --> Final output sent to browser
DEBUG - 2013-03-25 22:59:27 --> Total execution time: 0.0429
