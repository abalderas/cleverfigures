<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-03-17 00:00:33 --> Config Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:00:33 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:00:33 --> URI Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Router Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Output Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Security Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Input Class Initialized
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:00:33 --> Language Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Loader Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:00:33 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:00:33 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:00:33 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:00:33 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:00:33 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:00:33 --> Session Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:00:33 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Session routines successfully run
DEBUG - 2013-03-17 00:00:33 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Controller Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Model Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Model Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Model Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Model Class Initialized
DEBUG - 2013-03-17 00:00:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> XSS Filtering completed
DEBUG - 2013-03-17 00:00:33 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:00:33 --> File loaded: application/views/content/add_color_view.php
DEBUG - 2013-03-17 00:00:33 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:00:33 --> Final output sent to browser
DEBUG - 2013-03-17 00:00:33 --> Total execution time: 0.0406
DEBUG - 2013-03-17 00:05:30 --> Config Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:05:30 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:05:30 --> URI Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Router Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Output Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Security Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Input Class Initialized
DEBUG - 2013-03-17 00:05:30 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:30 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:30 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:30 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:30 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:30 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:30 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:05:30 --> Language Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Loader Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:05:30 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:05:30 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:05:30 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:05:30 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:05:30 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:05:30 --> Session Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:05:30 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Session routines successfully run
DEBUG - 2013-03-17 00:05:30 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Controller Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:30 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:31 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:05:31 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:31 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-03-17 00:05:31 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:31 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:31 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:31 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:31 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:05:31 --> File loaded: application/views/content/add_color_view.php
DEBUG - 2013-03-17 00:05:31 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:05:31 --> Final output sent to browser
DEBUG - 2013-03-17 00:05:31 --> Total execution time: 0.0385
DEBUG - 2013-03-17 00:05:34 --> Config Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:05:34 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:05:34 --> URI Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Router Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Output Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Security Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Input Class Initialized
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:05:34 --> Language Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Loader Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:05:34 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:05:34 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:05:34 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:05:34 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:05:34 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:05:34 --> Session Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:05:34 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Session routines successfully run
DEBUG - 2013-03-17 00:05:34 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Controller Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:34 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:05:34 --> File loaded: application/views/content/add_color_view.php
DEBUG - 2013-03-17 00:05:34 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:05:34 --> Final output sent to browser
DEBUG - 2013-03-17 00:05:34 --> Total execution time: 0.0321
DEBUG - 2013-03-17 00:05:52 --> Config Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:05:52 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:05:52 --> URI Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Router Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Output Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Security Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Input Class Initialized
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:05:52 --> Language Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Loader Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:05:52 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:05:52 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:05:52 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:05:52 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:05:52 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:05:52 --> Session Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:05:52 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Session routines successfully run
DEBUG - 2013-03-17 00:05:52 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Controller Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Model Class Initialized
DEBUG - 2013-03-17 00:05:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:05:52 --> XSS Filtering completed
ERROR - 2013-03-17 00:05:52 --> Severity: Notice  --> Undefined variable: wikiname /opt/lampp/htdocs/cleverfigures/trunk/application/models/color_model.php 83
DEBUG - 2013-03-17 00:08:22 --> Config Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:08:22 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:08:22 --> URI Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Router Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Output Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Security Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Input Class Initialized
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:08:22 --> Language Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Loader Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:08:22 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:08:22 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:08:22 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:08:22 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:08:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:08:22 --> Session Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:08:22 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Session routines successfully run
DEBUG - 2013-03-17 00:08:22 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Controller Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:08:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:08:22 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:08:22 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-17 00:08:22 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:08:22 --> Final output sent to browser
DEBUG - 2013-03-17 00:08:22 --> Total execution time: 0.2117
DEBUG - 2013-03-17 00:09:23 --> Config Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:09:23 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:09:23 --> URI Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Router Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Output Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Security Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Input Class Initialized
DEBUG - 2013-03-17 00:09:23 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:23 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:09:23 --> Language Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Loader Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:09:23 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:09:23 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:09:23 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:09:23 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:09:23 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:09:23 --> Session Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:09:23 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Session routines successfully run
DEBUG - 2013-03-17 00:09:23 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Controller Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:09:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:23 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:09:23 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-17 00:09:23 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:09:23 --> Final output sent to browser
DEBUG - 2013-03-17 00:09:23 --> Total execution time: 0.0458
DEBUG - 2013-03-17 00:09:24 --> Config Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:09:24 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:09:24 --> URI Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Router Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Output Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Security Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Input Class Initialized
DEBUG - 2013-03-17 00:09:24 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:24 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:09:24 --> Language Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Loader Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:09:24 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:09:24 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:09:24 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:09:24 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:09:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:09:24 --> Session Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:09:24 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Session routines successfully run
DEBUG - 2013-03-17 00:09:24 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Controller Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:09:24 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-17 00:09:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:09:24 --> Final output sent to browser
DEBUG - 2013-03-17 00:09:24 --> Total execution time: 0.0288
DEBUG - 2013-03-17 00:09:28 --> Config Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:09:28 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:09:28 --> URI Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Router Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Output Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Security Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Input Class Initialized
DEBUG - 2013-03-17 00:09:28 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:28 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:28 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:28 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:28 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:09:28 --> Language Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Loader Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:09:28 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:09:28 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:09:28 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:09:28 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:09:28 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:09:28 --> Session Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:09:28 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Session routines successfully run
DEBUG - 2013-03-17 00:09:28 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Controller Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:09:28 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:28 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:28 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:09:28 --> File loaded: application/views/content/analising_view.php
DEBUG - 2013-03-17 00:09:28 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:09:34 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:09:35 --> Final output sent to browser
DEBUG - 2013-03-17 00:09:35 --> Total execution time: 6.6480
DEBUG - 2013-03-17 00:09:37 --> Config Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:09:37 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:09:37 --> URI Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Router Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Output Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Security Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Input Class Initialized
DEBUG - 2013-03-17 00:09:37 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:37 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:09:37 --> Language Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Loader Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:09:37 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:09:37 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:09:37 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:09:37 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:09:37 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:09:37 --> Session Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:09:37 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Session routines successfully run
DEBUG - 2013-03-17 00:09:37 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Controller Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:09:37 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:37 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:37 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:09:37 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-17 00:09:37 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:09:37 --> Final output sent to browser
DEBUG - 2013-03-17 00:09:37 --> Total execution time: 0.0742
DEBUG - 2013-03-17 00:09:39 --> Config Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:09:39 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:09:39 --> URI Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Router Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Output Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Security Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Input Class Initialized
DEBUG - 2013-03-17 00:09:39 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:39 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:09:39 --> Language Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Loader Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:09:39 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:09:39 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:09:39 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:09:39 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:09:39 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:09:39 --> Session Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:09:39 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Session routines successfully run
DEBUG - 2013-03-17 00:09:39 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Controller Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:09:39 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:39 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:39 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:09:47 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2013-03-17 00:09:47 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:09:47 --> Final output sent to browser
DEBUG - 2013-03-17 00:09:47 --> Total execution time: 8.3612
DEBUG - 2013-03-17 00:09:51 --> Config Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:09:51 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:09:51 --> URI Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Router Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Output Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Security Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Input Class Initialized
DEBUG - 2013-03-17 00:09:51 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:51 --> XSS Filtering completed
DEBUG - 2013-03-17 00:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:09:51 --> Language Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Loader Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:09:51 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:09:51 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:09:51 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:09:51 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:09:51 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:09:51 --> Session Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:09:51 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Session routines successfully run
DEBUG - 2013-03-17 00:09:51 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Controller Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:09:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:09:51 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 40
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 40
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 77
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 77
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 113
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 113
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 143
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 143
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 191
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 191
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 212
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 212
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 233
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 233
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 254
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 254
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 275
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 275
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 440
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 441
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 442
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 443
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 444
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 445
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 446
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 458
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 459
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 460
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 461
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 462
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 463
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 464
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 476
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 477
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 478
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 479
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 480
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 481
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 482
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 494
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 495
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 495
ERROR - 2013-03-17 00:09:51 --> Severity: Notice  --> Undefined index: useredits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-17 00:09:51 --> Severity: Notice  --> Undefined index: pageedits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 592
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 592
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 592
ERROR - 2013-03-17 00:09:51 --> Severity: Notice  --> Undefined index: useredits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 685
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 685
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 685
ERROR - 2013-03-17 00:09:51 --> Severity: Notice  --> Undefined index: pageedits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 694
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 694
ERROR - 2013-03-17 00:09:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 694
ERROR - 2013-03-17 00:09:51 --> Severity: Notice  --> Undefined index: wikiname /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 767
DEBUG - 2013-03-17 00:09:51 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2013-03-17 00:09:51 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:09:51 --> Final output sent to browser
DEBUG - 2013-03-17 00:09:51 --> Total execution time: 0.0496
DEBUG - 2013-03-17 00:12:02 --> Config Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:12:02 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:12:02 --> URI Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Router Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Output Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Security Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Input Class Initialized
DEBUG - 2013-03-17 00:12:02 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:02 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:02 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:02 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:02 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:02 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:12:02 --> Language Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Loader Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:12:02 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:12:02 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:12:02 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:12:02 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:12:02 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:12:02 --> Session Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:12:02 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Session routines successfully run
DEBUG - 2013-03-17 00:12:02 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Controller Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:12:02 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:02 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:02 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:12:02 --> File loaded: application/views/content/pageanalisis_view.php
DEBUG - 2013-03-17 00:12:02 --> File loaded: application/views/content/tabbed_view.php
DEBUG - 2013-03-17 00:12:02 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:12:02 --> Final output sent to browser
DEBUG - 2013-03-17 00:12:02 --> Total execution time: 0.2054
DEBUG - 2013-03-17 00:12:24 --> Config Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:12:24 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:12:24 --> URI Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Router Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Output Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Security Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Input Class Initialized
DEBUG - 2013-03-17 00:12:24 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:24 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:12:24 --> Language Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Loader Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:12:24 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:12:24 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:12:24 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:12:24 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:12:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:12:24 --> Session Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:12:24 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Session routines successfully run
DEBUG - 2013-03-17 00:12:24 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Controller Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:12:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:24 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 40
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 40
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 77
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 77
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 113
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 113
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 143
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 143
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 191
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 191
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 212
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 212
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 233
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 233
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 254
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 254
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 275
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 275
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 440
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 441
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 442
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 443
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 444
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 445
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 446
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 458
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 459
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 460
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 461
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 462
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 463
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 464
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 476
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 477
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 478
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 479
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 480
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 481
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 482
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 494
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 495
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 495
ERROR - 2013-03-17 00:12:24 --> Severity: Notice  --> Undefined index: useredits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-17 00:12:24 --> Severity: Notice  --> Undefined index: pageedits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 592
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 592
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 592
ERROR - 2013-03-17 00:12:24 --> Severity: Notice  --> Undefined index: useredits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 685
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 685
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 685
ERROR - 2013-03-17 00:12:24 --> Severity: Notice  --> Undefined index: pageedits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 694
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 694
ERROR - 2013-03-17 00:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 694
ERROR - 2013-03-17 00:12:24 --> Severity: Notice  --> Undefined index: wikiname /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 767
DEBUG - 2013-03-17 00:12:24 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2013-03-17 00:12:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:12:24 --> Final output sent to browser
DEBUG - 2013-03-17 00:12:24 --> Total execution time: 0.0485
DEBUG - 2013-03-17 00:12:34 --> Config Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:12:34 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:12:34 --> URI Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Router Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Output Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Security Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Input Class Initialized
DEBUG - 2013-03-17 00:12:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:34 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:12:34 --> Language Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Loader Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:12:34 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:12:34 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:12:34 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:12:34 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:12:34 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:12:34 --> Session Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:12:34 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Session routines successfully run
DEBUG - 2013-03-17 00:12:34 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Controller Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:12:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:34 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:34 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:12:34 --> File loaded: application/views/content/pageanalisis_view.php
DEBUG - 2013-03-17 00:12:34 --> File loaded: application/views/content/tabbed_view.php
DEBUG - 2013-03-17 00:12:34 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:12:34 --> Final output sent to browser
DEBUG - 2013-03-17 00:12:34 --> Total execution time: 0.1897
DEBUG - 2013-03-17 00:12:56 --> Config Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:12:56 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:12:56 --> URI Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Router Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Output Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Security Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Input Class Initialized
DEBUG - 2013-03-17 00:12:56 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:56 --> XSS Filtering completed
DEBUG - 2013-03-17 00:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:12:56 --> Language Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Loader Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:12:56 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:12:56 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:12:56 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:12:56 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:12:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:12:56 --> Session Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:12:56 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Session routines successfully run
DEBUG - 2013-03-17 00:12:56 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Controller Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:12:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:12:56 --> File loaded: application/views/templates/header_view.php
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 40
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 40
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 77
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 77
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 113
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 113
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 143
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 143
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 191
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 191
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 212
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 212
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 233
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 233
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 254
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 254
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 275
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 275
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 440
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 441
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 442
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 443
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 444
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 445
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 446
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 458
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 459
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 460
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 461
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 462
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 463
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 464
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 476
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 477
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 478
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 479
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 480
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 481
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 482
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 494
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 495
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> end() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 495
ERROR - 2013-03-17 00:12:56 --> Severity: Notice  --> Undefined index: useredits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 529
ERROR - 2013-03-17 00:12:56 --> Severity: Notice  --> Undefined index: pageedits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 592
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 592
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 592
ERROR - 2013-03-17 00:12:56 --> Severity: Notice  --> Undefined index: useredits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 685
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 685
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 685
ERROR - 2013-03-17 00:12:56 --> Severity: Notice  --> Undefined index: pageedits /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 694
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, null given /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 694
ERROR - 2013-03-17 00:12:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 694
ERROR - 2013-03-17 00:12:56 --> Severity: Notice  --> Undefined index: wikiname /opt/lampp/htdocs/cleverfigures/trunk/application/views/content/check_results_view.php 767
DEBUG - 2013-03-17 00:12:56 --> File loaded: application/views/content/check_results_view.php
DEBUG - 2013-03-17 00:12:56 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:12:56 --> Final output sent to browser
DEBUG - 2013-03-17 00:12:56 --> Total execution time: 0.0478
DEBUG - 2013-03-17 00:13:19 --> Config Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:13:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:13:19 --> URI Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Router Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Output Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Security Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Input Class Initialized
DEBUG - 2013-03-17 00:13:19 --> XSS Filtering completed
DEBUG - 2013-03-17 00:13:19 --> XSS Filtering completed
DEBUG - 2013-03-17 00:13:19 --> XSS Filtering completed
DEBUG - 2013-03-17 00:13:19 --> XSS Filtering completed
DEBUG - 2013-03-17 00:13:19 --> XSS Filtering completed
DEBUG - 2013-03-17 00:13:19 --> XSS Filtering completed
DEBUG - 2013-03-17 00:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:13:19 --> Language Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Loader Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:13:19 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:13:19 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:13:19 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:13:19 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:13:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:13:19 --> Session Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:13:19 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Session routines successfully run
DEBUG - 2013-03-17 00:13:19 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Controller Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:13:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:13:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:13:19 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:13:19 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:13:19 --> File loaded: application/views/content/useranalisis_view.php
DEBUG - 2013-03-17 00:13:19 --> File loaded: application/views/content/tabbed_view.php
DEBUG - 2013-03-17 00:13:19 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:13:19 --> Final output sent to browser
DEBUG - 2013-03-17 00:13:19 --> Total execution time: 0.1932
DEBUG - 2013-03-17 00:14:01 --> Config Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:14:01 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:14:01 --> URI Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Router Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Output Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Security Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Input Class Initialized
DEBUG - 2013-03-17 00:14:01 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:01 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:14:01 --> Language Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Loader Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:14:01 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:14:01 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:14:01 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:14:01 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:14:01 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:14:01 --> Session Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:14:01 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Session routines successfully run
DEBUG - 2013-03-17 00:14:01 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Controller Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:14:01 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:01 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:01 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:14:01 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-17 00:14:01 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:14:01 --> Final output sent to browser
DEBUG - 2013-03-17 00:14:01 --> Total execution time: 0.0340
DEBUG - 2013-03-17 00:14:12 --> Config Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:14:12 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:14:12 --> URI Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Router Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Output Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Security Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Input Class Initialized
DEBUG - 2013-03-17 00:14:12 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:12 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:14:12 --> Language Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Loader Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:14:12 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:14:12 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:14:12 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:14:12 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:14:12 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:14:12 --> Session Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:14:12 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Session routines successfully run
DEBUG - 2013-03-17 00:14:12 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Controller Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:14:12 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:12 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:12 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:14:12 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-17 00:14:12 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:14:12 --> Final output sent to browser
DEBUG - 2013-03-17 00:14:12 --> Total execution time: 0.0594
DEBUG - 2013-03-17 00:14:19 --> Config Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:14:19 --> URI Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Router Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Output Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Security Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Input Class Initialized
DEBUG - 2013-03-17 00:14:19 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:19 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:14:19 --> Language Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Loader Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:14:19 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:14:19 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:14:19 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:14:19 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:14:19 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:14:19 --> Session Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:14:19 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Session routines successfully run
DEBUG - 2013-03-17 00:14:19 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Controller Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:14:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:19 --> Model Class Initialized
ERROR - 2013-03-17 00:14:20 --> Severity: Warning  --> opendir(analisis/1363475368): failed to open dir: No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/system/helpers/file_helper.php 126
ERROR - 2013-03-17 00:14:20 --> Severity: Warning  --> rmdir(analisis/1363475368/): No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/application/models/analisis_model.php 61
DEBUG - 2013-03-17 00:14:20 --> Config Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:14:20 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:14:20 --> URI Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Router Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Output Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Security Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Input Class Initialized
DEBUG - 2013-03-17 00:14:20 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:20 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:14:20 --> Language Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Loader Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:14:20 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:14:20 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:14:20 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:14:20 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:14:20 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:14:20 --> Session Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:14:20 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Session routines successfully run
DEBUG - 2013-03-17 00:14:20 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Controller Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:14:20 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:20 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:20 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:14:20 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-17 00:14:20 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:14:20 --> Final output sent to browser
DEBUG - 2013-03-17 00:14:20 --> Total execution time: 0.0453
DEBUG - 2013-03-17 00:14:22 --> Config Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:14:22 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:14:22 --> URI Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Router Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Output Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Security Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Input Class Initialized
DEBUG - 2013-03-17 00:14:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:14:22 --> Language Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Loader Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:14:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:14:22 --> Session Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:14:22 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Session routines successfully run
DEBUG - 2013-03-17 00:14:22 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Controller Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
ERROR - 2013-03-17 00:14:22 --> Severity: Warning  --> opendir(analisis/1363474106): failed to open dir: No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/system/helpers/file_helper.php 126
ERROR - 2013-03-17 00:14:22 --> Severity: Warning  --> rmdir(analisis/1363474106/): No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/application/models/analisis_model.php 61
DEBUG - 2013-03-17 00:14:22 --> Config Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:14:22 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:14:22 --> URI Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Router Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Output Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Security Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Input Class Initialized
DEBUG - 2013-03-17 00:14:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:22 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:14:22 --> Language Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Loader Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:14:22 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:14:22 --> Session Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:14:22 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Session routines successfully run
DEBUG - 2013-03-17 00:14:22 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Controller Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:22 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:14:22 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-17 00:14:22 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:14:22 --> Final output sent to browser
DEBUG - 2013-03-17 00:14:22 --> Total execution time: 0.0442
DEBUG - 2013-03-17 00:14:23 --> Config Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:14:23 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:14:23 --> URI Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Router Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Output Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Security Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Input Class Initialized
DEBUG - 2013-03-17 00:14:23 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:23 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:14:23 --> Language Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Loader Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:14:23 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:14:23 --> Session Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:14:23 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Session routines successfully run
DEBUG - 2013-03-17 00:14:23 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Controller Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
ERROR - 2013-03-17 00:14:23 --> Severity: Warning  --> opendir(analisis/1363467328): failed to open dir: No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/system/helpers/file_helper.php 126
ERROR - 2013-03-17 00:14:23 --> Severity: Warning  --> rmdir(analisis/1363467328/): No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/application/models/analisis_model.php 61
DEBUG - 2013-03-17 00:14:23 --> Config Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:14:23 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:14:23 --> URI Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Router Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Output Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Security Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Input Class Initialized
DEBUG - 2013-03-17 00:14:23 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:23 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:14:23 --> Language Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Loader Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:14:23 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:14:23 --> Session Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:14:23 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Session routines successfully run
DEBUG - 2013-03-17 00:14:23 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Controller Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:23 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:14:23 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-17 00:14:23 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:14:23 --> Final output sent to browser
DEBUG - 2013-03-17 00:14:23 --> Total execution time: 0.0350
DEBUG - 2013-03-17 00:14:24 --> Config Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:14:24 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:14:24 --> URI Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Router Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Output Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Security Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Input Class Initialized
DEBUG - 2013-03-17 00:14:24 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:24 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:14:24 --> Language Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Loader Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:14:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:14:24 --> Session Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:14:24 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Session routines successfully run
DEBUG - 2013-03-17 00:14:24 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Controller Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
ERROR - 2013-03-17 00:14:24 --> Severity: Warning  --> opendir(analisis/1363462996): failed to open dir: No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/system/helpers/file_helper.php 126
ERROR - 2013-03-17 00:14:24 --> Severity: Warning  --> rmdir(analisis/1363462996/): No such file or directory /opt/lampp/htdocs/cleverfigures/trunk/application/models/analisis_model.php 61
DEBUG - 2013-03-17 00:14:24 --> Config Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:14:24 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:14:24 --> URI Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Router Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Output Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Security Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Input Class Initialized
DEBUG - 2013-03-17 00:14:24 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:24 --> XSS Filtering completed
DEBUG - 2013-03-17 00:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:14:24 --> Language Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Loader Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:14:24 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:14:24 --> Session Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:14:24 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Session routines successfully run
DEBUG - 2013-03-17 00:14:24 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Controller Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> Model Class Initialized
DEBUG - 2013-03-17 00:14:24 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:14:24 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-17 00:14:24 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:14:24 --> Final output sent to browser
DEBUG - 2013-03-17 00:14:24 --> Total execution time: 0.0335
DEBUG - 2013-03-17 00:24:45 --> Config Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:24:45 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:24:45 --> URI Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Router Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Output Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Security Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Input Class Initialized
DEBUG - 2013-03-17 00:24:45 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:45 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:24:45 --> Language Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Loader Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:24:45 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:24:45 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:24:45 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:24:45 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:24:45 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:24:45 --> Session Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:24:45 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Session routines successfully run
DEBUG - 2013-03-17 00:24:45 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Controller Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:24:45 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:45 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:45 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:24:45 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-17 00:24:45 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:24:45 --> Final output sent to browser
DEBUG - 2013-03-17 00:24:45 --> Total execution time: 0.0518
DEBUG - 2013-03-17 00:24:47 --> Config Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:24:47 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:24:47 --> URI Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Router Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Output Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Security Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Input Class Initialized
DEBUG - 2013-03-17 00:24:47 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:47 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:47 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:47 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:24:47 --> Language Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Loader Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:24:47 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:24:47 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:24:47 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:24:47 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:24:47 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:24:47 --> Session Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:24:47 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Session routines successfully run
DEBUG - 2013-03-17 00:24:47 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Controller Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:47 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:47 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:24:47 --> File loaded: application/views/content/add_wiki_view.php
DEBUG - 2013-03-17 00:24:47 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:24:47 --> Final output sent to browser
DEBUG - 2013-03-17 00:24:47 --> Total execution time: 0.0279
DEBUG - 2013-03-17 00:24:52 --> Config Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:24:52 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:24:52 --> URI Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Router Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Output Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Security Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Input Class Initialized
DEBUG - 2013-03-17 00:24:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:52 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:24:52 --> Language Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Loader Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:24:52 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:24:52 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:24:52 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:24:52 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:24:52 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:24:52 --> Session Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:24:52 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Session routines successfully run
DEBUG - 2013-03-17 00:24:52 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Controller Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:52 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:52 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:24:52 --> File loaded: application/views/content/add_color_view.php
DEBUG - 2013-03-17 00:24:52 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:24:52 --> Final output sent to browser
DEBUG - 2013-03-17 00:24:52 --> Total execution time: 0.0367
DEBUG - 2013-03-17 00:24:56 --> Config Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:24:56 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:24:56 --> URI Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Router Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Output Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Security Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Input Class Initialized
DEBUG - 2013-03-17 00:24:56 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:56 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:56 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:56 --> XSS Filtering completed
DEBUG - 2013-03-17 00:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:24:56 --> Language Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Loader Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:24:56 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:24:56 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:24:56 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:24:56 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:24:56 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:24:56 --> Session Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:24:56 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Session routines successfully run
DEBUG - 2013-03-17 00:24:56 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Controller Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:56 --> Model Class Initialized
DEBUG - 2013-03-17 00:24:56 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:24:56 --> File loaded: application/views/content/installation2_view.php
DEBUG - 2013-03-17 00:24:56 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:24:56 --> Final output sent to browser
DEBUG - 2013-03-17 00:24:56 --> Total execution time: 0.0281
DEBUG - 2013-03-17 00:25:51 --> Config Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:25:51 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:25:51 --> URI Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Router Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Output Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Security Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Input Class Initialized
DEBUG - 2013-03-17 00:25:51 --> XSS Filtering completed
DEBUG - 2013-03-17 00:25:51 --> XSS Filtering completed
DEBUG - 2013-03-17 00:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:25:51 --> Language Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Loader Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:25:51 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:25:51 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:25:51 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:25:51 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:25:51 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:25:51 --> Session Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:25:51 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Session routines successfully run
DEBUG - 2013-03-17 00:25:51 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Controller Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:51 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:51 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:25:51 --> File loaded: application/views/content/analise_view.php
DEBUG - 2013-03-17 00:25:51 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:25:51 --> Final output sent to browser
DEBUG - 2013-03-17 00:25:51 --> Total execution time: 0.0431
DEBUG - 2013-03-17 00:25:53 --> Config Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:25:53 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:25:53 --> URI Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Router Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Output Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Security Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Input Class Initialized
DEBUG - 2013-03-17 00:25:53 --> XSS Filtering completed
DEBUG - 2013-03-17 00:25:53 --> XSS Filtering completed
DEBUG - 2013-03-17 00:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:25:53 --> Language Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Loader Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:25:53 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:25:53 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:25:53 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:25:53 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:25:53 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:25:53 --> Session Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:25:53 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Session routines successfully run
DEBUG - 2013-03-17 00:25:53 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Controller Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:25:53 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:53 --> Model Class Initialized
DEBUG - 2013-03-17 00:25:53 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:25:53 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-17 00:25:53 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:25:53 --> Final output sent to browser
DEBUG - 2013-03-17 00:25:53 --> Total execution time: 0.0477
DEBUG - 2013-03-17 00:26:11 --> Config Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:26:11 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:26:11 --> URI Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Router Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Output Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Security Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Input Class Initialized
DEBUG - 2013-03-17 00:26:11 --> XSS Filtering completed
DEBUG - 2013-03-17 00:26:11 --> XSS Filtering completed
DEBUG - 2013-03-17 00:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:26:11 --> Language Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Loader Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:26:11 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:26:11 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:26:11 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:26:11 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:26:11 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:26:11 --> Session Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:26:11 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Session routines successfully run
DEBUG - 2013-03-17 00:26:11 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Controller Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:26:11 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:11 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:11 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:26:11 --> File loaded: application/views/content/configuration_view.php
DEBUG - 2013-03-17 00:26:11 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:26:11 --> Final output sent to browser
DEBUG - 2013-03-17 00:26:11 --> Total execution time: 0.0573
DEBUG - 2013-03-17 00:26:23 --> Config Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Hooks Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Utf8 Class Initialized
DEBUG - 2013-03-17 00:26:23 --> UTF-8 Support Enabled
DEBUG - 2013-03-17 00:26:23 --> URI Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Router Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Output Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Security Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Input Class Initialized
DEBUG - 2013-03-17 00:26:23 --> XSS Filtering completed
DEBUG - 2013-03-17 00:26:23 --> XSS Filtering completed
DEBUG - 2013-03-17 00:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-03-17 00:26:23 --> Language Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Loader Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Helper loaded: date_helper
DEBUG - 2013-03-17 00:26:23 --> Helper loaded: form_helper
DEBUG - 2013-03-17 00:26:23 --> Helper loaded: language_helper
DEBUG - 2013-03-17 00:26:23 --> Helper loaded: url_helper
DEBUG - 2013-03-17 00:26:23 --> Helper loaded: html_helper
DEBUG - 2013-03-17 00:26:23 --> Language file loaded: language/english/voc_lang.php
DEBUG - 2013-03-17 00:26:23 --> Session Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Helper loaded: string_helper
DEBUG - 2013-03-17 00:26:23 --> Encrypt Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Session routines successfully run
DEBUG - 2013-03-17 00:26:23 --> Form Validation Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Controller Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Database Driver Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Helper loaded: file_helper
DEBUG - 2013-03-17 00:26:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:23 --> Model Class Initialized
DEBUG - 2013-03-17 00:26:23 --> File loaded: application/views/templates/header_view.php
DEBUG - 2013-03-17 00:26:23 --> File loaded: application/views/content/teacher_view.php
DEBUG - 2013-03-17 00:26:23 --> File loaded: application/views/templates/footer_view.php
DEBUG - 2013-03-17 00:26:23 --> Final output sent to browser
DEBUG - 2013-03-17 00:26:23 --> Total execution time: 0.0527
